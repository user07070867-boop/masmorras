(async () => {
    const results = [];
    const enemySpriteSheets = [
        goblinAnimationSheet,
        goblinRunnerAnimationSheet,
        spiderAnimationSheet,
        sootSpiderAnimationSheet,
        matriarchSpiderAnimationSheet
    ];
    await Promise.all(enemySpriteSheets.map((spriteSheet) => (
        spriteSheet.complete
            ? Promise.resolve()
            : new Promise((resolve) => {
                spriteSheet.addEventListener('load', resolve, { once: true });
                spriteSheet.addEventListener('error', resolve, { once: true });
            })
    )));
    const originalBestiaryDiscoveries = new Set(discoveredCreatureIds);
    const originalBestiaryStorage = localStorage.getItem(bestiaryDiscoveryStorageKey);
    const originalBestiaryStatus = {
        hidden: bestiaryDiscoveryStatus.hidden,
        text: bestiaryDiscoveryStatus.textContent
    };

    function assert(condition, message) {
        if (!condition) {
            throw new Error(message);
        }
    }

    function runTest(name, callback) {
        try {
            const result = callback();
            results.push({ name, passed: result !== false, skipped: result === false });
        } catch (error) {
            results.push({ name, passed: false, error: error.message });
        }
    }

    runTest('A velocidade das animacoes dos personagens e configuravel', () => {
        assert(Number.isFinite(GAME_BALANCE.visual.actorAnimationSpeedMultiplier)
            && GAME_BALANCE.visual.actorAnimationSpeedMultiplier > 0,
        'O multiplicador visual precisa ser um numero positivo.');
        assert(Math.abs(getActorAnimationDelta(0.1) - 0.16) < 0.0001,
            'O delta visual nao aplicou o multiplicador configurado.');
    });

    runTest('A animacao de ataque do jogador e 20% mais rapida', () => {
        const speedMultiplier = GAME_BALANCE.visual.playerAttackAnimationSpeedMultiplier;
        assert(speedMultiplier === 1.2
            && Math.abs(playerAttackAnimationDuration - 0.14 / speedMultiplier) < 0.0001
            && Math.abs(maleAttackAnimationDuration - 1 / speedMultiplier) < 0.0001,
        'As duracoes da animacao de ataque nao aplicaram o aumento de velocidade de 20%.');
    });

    function getReachableTiles(start) {
        const queue = [start];
        const visited = new Set([`${start.x},${start.y}`]);
        for (let index = 0; index < queue.length; index += 1) {
            const { x, y } = queue[index];
            for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
                const nextX = x + dx;
                const nextY = y + dy;
                const key = `${nextX},${nextY}`;
                if (map[nextY]?.[nextX] === '.' && !visited.has(key)) {
                    visited.add(key);
                    queue.push({ x: nextX, y: nextY });
                }
            }
        }
        return visited;
    }

    runTest('Níveis dão pontos e os atributos melhoram vida, combate e mira', () => {
        const previousProgress = playerProgress;
        const previousPlayer = player;
        const previousFloor = currentFloor;
        const previousGameState = gameState;
        const previousBotMode = botMode;
        try {
            currentFloor = 1;
            botMode = false;
            resetGame();
            gameState = 'playing';
            playerProgress.level = 4;
            playerProgress.xp = 0;
            playerProgress.xpToNext = 100;
            playerProgress.skillPoints = 0;
            playerProgress.attributes = { health: 0, meleeDamage: 0, aim: 0 };
            player.maxHealth = getPlayerMaxHealth();
            player.health = 50;
            player.damage = getPlayerMeleeDamage();
            player.speed = 70;
            const healthBeforeLevel = player.health;
            const maxHealthBeforeLevel = player.maxHealth;
            const damageBeforeLevel = player.damage;
            const speedBeforeLevel = player.speed;

            addExperience(100);
            assert(playerProgress.level === 5 && playerProgress.skillPoints === 2,
                'O nível 5 não concedeu 1 ponto normal e 1 ponto de marco.');
            assert(player.health === healthBeforeLevel
                && player.maxHealth === maxHealthBeforeLevel
                && player.damage === damageBeforeLevel,
            'Subir de nível alterou automaticamente vida ou dano.');
            assert(player.speed === speedBeforeLevel,
                'Subir de nível alterou automaticamente a velocidade.');
            assert(!levelUpgradePanel.hidden && skillPointText.textContent === '2 pontos disponíveis',
                'A HUD não mostrou os dois pontos de atributo disponíveis.');

            const previousMaxHealth = player.maxHealth;
            const previousHealth = player.health;
            assert(investPlayerAttribute('health')
                && player.maxHealth === previousMaxHealth + 10
                && player.health === previousHealth + 10,
            'Investir em Vida não aumentou e curou 10 pontos.');

            const previousDamage = player.damage;
            assert(investPlayerAttribute('meleeDamage')
                && player.damage === previousDamage + 2
                && playerProgress.skillPoints === 0,
            'Investir em Corpo a corpo não aumentou o dano ou consumiu o ponto.');

            playerProgress.skillPoints = 1;
            const previousArrowDamage = getAimedWeaponDamage(GAME_BALANCE.bow.damage);
            assert(investPlayerAttribute('aim')
                && getAimedWeaponDamage(GAME_BALANCE.bow.damage) === previousArrowDamage + 2,
            'Investir em Mira não aumentou o dano à distância ou ocultou o painel sem pontos.');
            map = map.map((row) => row.map(() => '.'));
            bowOwned = true;
            arrowAmmo = GAME_BALANCE.bow.startingAmmo;
            swordEquipped = false;
            for (const enemy of enemies) {
                enemy.health = 0;
                enemy.dying = true;
            }
            const target = enemies[0];
            const playerCenterX = player.x + player.size / 2;
            const playerCenterY = player.y + player.size / 2;
            target.x = playerCenterX + 40;
            target.y = playerCenterY - 8;
            target.size = 16;
            target.collisionWidth = 16;
            target.collisionHeight = 16;
            target.health = 100;
            target.maxHealth = 100;
            target.armorDurability = 0;
            target.shieldDurability = 0;
            target.dodgeCooldown = 2;
            target.defense = 0;
            target.resistances = { physical: 0, arrow: 0 };
            target.facingX = 0;
            target.facingY = 0;
            target.dying = false;
            fireArrow(playerCenterX + 100, playerCenterY);
            updatePlayerArrows(0.15);
            assert(target.health === 86
                && arrowAmmo === GAME_BALANCE.bow.startingAmmo - 1,
            'A flecha não aplicou o dano de Mira ou não consumiu uma munição.');
            assert(levelUpgradePanel.hidden,
                'O painel de atributos permaneceu visível sem pontos disponíveis.');
            const maxHealthBeforeFloor = player.maxHealth;
            const damageBeforeFloor = player.damage;
            resetGame(true);
            assert(player.maxHealth === maxHealthBeforeFloor && player.damage === damageBeforeFloor,
                'Avançar de andar alterou automaticamente vida ou dano.');
            resetGame();
            assert(playerProgress.level === 1
                && playerProgress.attributes.health === 0
                && playerProgress.attributes.meleeDamage === 0
                && playerProgress.attributes.aim === 0,
            'Os atributos investidos não foram reiniciados em uma nova partida.');
        } finally {
            playerProgress = previousProgress;
            player = previousPlayer;
            currentFloor = previousFloor;
            gameState = previousGameState;
            botMode = previousBotMode;
            updateProgressHud();
            updateHealthHud();
        }
    });

    runTest('As 87 receitas validam ingredientes, consomem materiais e exibem os ícones enviados', () => {
        const previousMaterials = collectedMaterials;
        const previousCraftedItems = craftedItemQuantities;
        const informationPanel = document.getElementById('inventoryItemInformation');
        const informationTitle = informationPanel.querySelector('strong');
        const informationDescription = informationPanel.querySelector('span');
        const previousInformationTitle = informationTitle.textContent;
        const previousInformationDescription = informationDescription.textContent;
        const previousInventoryHidden = inventoryPanel.hidden;
        try {
            assert(materialRecipeData.length === 87
                && materialRecipeData.filter((recipe) => recipe.type === 'same').length === 36
                && materialRecipeData.filter((recipe) => recipe.type === 'mix').length === 51,
            'O catálogo não contém as 36 receitas iguais e 51 mistas da planilha.');
            assert(materialRecipeData.every((recipe) => recipe.ingredients.every((ingredient) => (
                creatureMaterialDataById[ingredient.materialId]
                    && Number.isInteger(ingredient.quantity)
                    && ingredient.quantity > 0
            ))), 'Uma receita usa material inexistente ou quantidade inválida.');
            assert(craftingRecipeList.querySelectorAll('.crafting-recipe-button').length === 87,
                'A interface não exibiu todas as receitas.');
            assert([...craftingRecipeList.querySelectorAll('.crafting-recipe-button')].every((button) => (
                button.classList.contains('inventory-slot')
                    && button.getAttribute('aria-label').includes('Receita:')
                    && button.querySelector('.inventory-item-name')
                    && button.querySelector('.inventory-item-detail')
            )), 'Os produtos fabricáveis não usam os slots normais ou não têm receitas acessíveis.');
            assert(craftingRecipeList.querySelectorAll('.crafting-recipe-icon').length === 87
                && [...craftingRecipeList.querySelectorAll('.crafting-recipe-icon')].every((icon) => (
                    icon.src.endsWith(`/assets/crafting-items/${icon.closest('.crafting-recipe-button').dataset.recipeId}.png`)
                    && icon.complete
                    && icon.naturalWidth === 128
                    && icon.naturalHeight === 128
                )),
            'Uma receita não exibiu seu ícone de 128 x 128 px corretamente carregado.');
            assert(!document.querySelector('.crafting-recipe-ingredients')
                && !document.querySelector('.crafting-recipes'),
            'As receitas aparecem permanentemente em vez de somente no tooltip do item.');
            const recipeSlot = craftingRecipeList.querySelector('[data-recipe-id="R001"]');
            inventoryPanel.hidden = false;
            recipeSlot.dispatchEvent(new PointerEvent('pointerover', {
                bubbles: true,
                relatedTarget: null
            }));
            assert(!inventoryTooltip.hidden
                && inventoryTooltip.textContent.includes('Receita:')
                && inventoryTooltip.textContent.includes('Tira de couro × 3'),
            'A receita não aparece ao passar o cursor sobre o item fabricável.');
            const tooltipBounds = inventoryTooltip.getBoundingClientRect();
            assert(tooltipBounds.left >= 0
                && tooltipBounds.right <= window.innerWidth
                && tooltipBounds.top >= 0
                && tooltipBounds.bottom <= window.innerHeight,
            'O tooltip da receita foi cortado pelos limites da tela.');
            assert([...craftingRecipeList.querySelectorAll('.crafting-recipe-button')].every((button) => {
                const iconBounds = button.querySelector('.crafting-recipe-icon').getBoundingClientRect();
                const nameBounds = button.querySelector('.inventory-item-name').getBoundingClientRect();
                return iconBounds.bottom <= nameBounds.top + 0.5;
            }), 'A arte dos itens fabricáveis foi encoberta pelo rótulo do slot.');
            recipeSlot.dispatchEvent(new PointerEvent('pointerout', {
                bubbles: true,
                relatedTarget: document.body
            }));
            assert(inventoryTooltip.hidden, 'O tooltip continuou visível após sair do item.');
            informationDescription.textContent = 'Descrição longa '.repeat(60);
            const informationBounds = informationPanel.getBoundingClientRect();
            assert(informationBounds.width > 0
                && informationPanel.scrollHeight > informationPanel.clientHeight,
            'A descrição longa não pode ser rolada no painel de detalhes.');

            collectedMaterials = { 'leather-strip': 2 };
            craftedItemQuantities = {};
            updateMaterialInventoryHud();
            const firstRecipeButton = craftingRecipeList.querySelector('[data-recipe-id="R001"]');
            assert(firstRecipeButton.getAttribute('aria-disabled') === 'true'
                && !craftMaterialRecipe('R001')
                && collectedMaterials['leather-strip'] === 2,
            'A receita foi habilitada ou consumiu materiais insuficientes.');

            collectedMaterials = { 'leather-strip': 3 };
            updateMaterialInventoryHud();
            const availableRecipeButton = craftingRecipeList.querySelector('[data-recipe-id="R001"]');
            assert(availableRecipeButton.getAttribute('aria-disabled') === 'false',
                'A receita permaneceu desabilitada com ingredientes suficientes.');
            availableRecipeButton.click();
            assert(!collectedMaterials['leather-strip']
                && craftedItemQuantities['tira-trancada-mais-duravel'] === 1,
            'Fabricar não consumiu os ingredientes ou não armazenou o produto.');
            const craftedRecipeSlot = craftingRecipeList.querySelector('[data-recipe-id="R001"]');
            assert(craftedRecipeSlot.querySelector('.inventory-count').textContent === '1'
                && craftedRecipeSlot.querySelector('.crafting-recipe-icon').src.endsWith('/assets/crafting-items/R001.png'),
            'O item fabricado não aparece no slot normal com quantidade e ícone.');
            assert(inventoryItemDescription.textContent.includes('efeito próprio'),
                'Os detalhes do produto fabricado não foram atualizados.');

            collectedMaterials = { 'thermal-gland': 1, 'scale-fragment': 2, 'heat-coating': 1 };
            updateMaterialInventoryHud();
            craftingRecipeList.querySelector('[data-recipe-id="R051"]').click();
            craftingRecipeList.querySelector('[data-recipe-id="R054"]').click();
            assert(craftedItemQuantities['protecao-ignea'] === 2
                && !Object.hasOwn(craftedItemQuantities, 'R051')
                && !Object.hasOwn(craftedItemQuantities, 'R054')
                && craftingRecipeList.querySelector('[data-recipe-id="R051"] .inventory-count').textContent === '2'
                && craftingRecipeList.querySelector('[data-recipe-id="R054"] .inventory-count').textContent === '2',
            'Itens fabricados iguais não foram agrupados em uma única pilha.');

            collectedMaterials = { fiber: 1, 'silk-gland': 1 };
            updateMaterialInventoryHud();
            craftingRecipeList.querySelector('[data-recipe-id="R046"]').click();
            assert(collectedMaterials['silk-thread'] === 1
                && !craftedItemQuantities['silk-thread'],
            'Um resultado que já é material não retornou ao estoque de materiais.');
        } finally {
            collectedMaterials = previousMaterials;
            craftedItemQuantities = previousCraftedItems;
            informationTitle.textContent = previousInformationTitle;
            informationDescription.textContent = previousInformationDescription;
            inventoryPanel.hidden = previousInventoryHidden;
            updateMaterialInventoryHud();
        }
    });

    runTest('O catálogo de materiais tem fontes de drop e usos coerentes', () => {
        const materialIds = creatureMaterialData.map((material) => material.id);
        const materialIdSet = new Set(materialIds);
        const droppedMaterialIds = new Set(creatureData.flatMap((creature) => (
            creature.drops.map((drop) => drop.id).filter((id) => id !== 'coin')
        )));
        const recipeIngredientIds = new Set(materialRecipeData.flatMap((recipe) => (
            recipe.ingredients.map((ingredient) => ingredient.materialId)
        )));
        assert(materialIds.length === materialIdSet.size
            && creatureMaterialData.every((material) => (
                material.name.trim() && material.description.trim()
            )), 'O catálogo tem IDs repetidos ou materiais sem descrição.');
        assert([...droppedMaterialIds].every((id) => materialIdSet.has(id)),
            'Uma tabela de drop aponta para material inexistente.');
        assert([...materialIdSet].every((id) => droppedMaterialIds.has(id)),
            'Há material sem uma fonte de drop cadastrada.');
        assert([...materialIdSet].every((id) => recipeIngredientIds.has(id)),
            'Há material sem uso em receita cadastrada.');
    });

    runTest('O ferreiro forja receitas iguais, mixes, cadeias e preserva itens em falhas', () => {
        const previousMaterials = collectedMaterials;
        const previousCraftedItems = craftedItemQuantities;
        const previousOreBalances = { ...oreCoinBalance };
        const previousActiveNpc = activeFloorNpcInteraction;
        const previousBlacksmithOpen = blacksmithMenuOpen;
        const previousLastInteractionFloor = blacksmithLastInteractionFloor;
        const previousDiscoveredRecipes = new Set(discoveredBlacksmithRecipeIds);
        const previousBlacksmithStorage = localStorage.getItem(blacksmithStateStorageKey);
        const previousPanelHidden = blacksmithPanel.hidden;
        const previousInfo = info.textContent;

        const chooseIngredients = (materialA, quantityA, materialB = '', quantityB = 0) => {
            blacksmithIngredientA.value = materialA;
            blacksmithIngredientB.value = materialB;
            blacksmithQuantityA.value = String(quantityA);
            blacksmithQuantityB.value = String(quantityB);
            blacksmithIngredientA.dispatchEvent(new Event('input', { bubbles: true }));
            blacksmithIngredientB.dispatchEvent(new Event('input', { bubbles: true }));
            blacksmithQuantityA.dispatchEvent(new Event('input', { bubbles: true }));
            blacksmithQuantityB.dispatchEvent(new Event('input', { bubbles: true }));
        };
        const openForge = () => {
            openBlacksmithMenu({ id: 'oren' });
            blacksmithPanel.querySelector('[data-blacksmith-action="forge"]').click();
        };

        try {
            collectedMaterials = { 'leather-strip': 3, 'mine-rivet': 1 };
            craftedItemQuantities = {};
            updateMaterialInventoryHud();
            openForge();
            chooseIngredients('leather-strip', 3);
            assert(!blacksmithForgeButton.disabled,
                'A receita Igual de três tiras de couro não foi habilitada.');
            blacksmithForgeButton.click();
            assert(!collectedMaterials['leather-strip']
                && craftedItemQuantities['tira-trancada-mais-duravel'] === 1,
            'A receita Igual não consumiu as três tiras e entregou o item.');

            collectedMaterials['leather-strip'] = 1;
            updateMaterialInventoryHud();
            refreshBlacksmithIngredientOptions();
            chooseIngredients('mine-rivet', 1, 'leather-strip', 1);
            assert(!blacksmithForgeButton.disabled,
                'A receita Mix não aceitou ingredientes em ordem inversa.');
            blacksmithForgeButton.click();
            assert(!collectedMaterials['mine-rivet']
                && !collectedMaterials['leather-strip']
                && craftedItemQuantities['bracelete-reforcado'] === 1,
            'A receita Mix não consumiu os ingredientes ou não entregou o bracelete.');

            collectedMaterials = { 'leather-strip': 1, 'shield-fragment': 1 };
            updateMaterialInventoryHud();
            refreshBlacksmithIngredientOptions();
            chooseIngredients('leather-strip', 1, 'shield-fragment', 1);
            assert(blacksmithForgeButton.disabled
                && collectedMaterials['leather-strip'] === 1
                && collectedMaterials['shield-fragment'] === 1,
            'Uma combinação inválida foi habilitada ou consumiu materiais.');

            collectedMaterials = { 'leather-strip': 2 };
            updateMaterialInventoryHud();
            refreshBlacksmithIngredientOptions();
            chooseIngredients('leather-strip', 3);
            assert(blacksmithForgeButton.disabled
                && blacksmithFeedback.textContent.includes('Faltam materiais')
                && collectedMaterials['leather-strip'] === 2,
            'Quantidade acima do estoque não foi bloqueada sem consumo.');

            collectedMaterials = { 'scale-fragment': 3, 'heat-coating': 1 };
            craftedItemQuantities = {};
            updateMaterialInventoryHud();
            refreshBlacksmithIngredientOptions();
            chooseIngredients('scale-fragment', 3);
            blacksmithForgeButton.click();
            assert(collectedMaterials['thermal-plate'] === 1,
                'A primeira etapa da cadeia não guardou a Placa térmica como material.');
            refreshBlacksmithIngredientOptions();
            chooseIngredients('heat-coating', 1, 'thermal-plate', 1);
            assert(!blacksmithForgeButton.disabled,
                'A Placa térmica fabricada não pôde ser usada na etapa seguinte.');
            blacksmithForgeButton.click();
            assert(!collectedMaterials['thermal-plate']
                && craftedItemQuantities['armadura-termica-completa'] === 1,
            'A cadeia de fabricação não consumiu a Placa térmica e criou a armadura.');

            collectedMaterials = Object.fromEntries(
                creatureMaterialData.map((material) => [material.id, 99])
            );
            craftedItemQuantities = {
                'inventario-cheio-teste-a': 1,
                'inventario-cheio-teste-b': 1,
                'inventario-cheio-teste-c': 1
            };
            updateMaterialInventoryHud();
            refreshBlacksmithIngredientOptions();
            chooseIngredients('leather-strip', 3);
            assert(blacksmithForgeButton.disabled
                && blacksmithFeedback.textContent.includes('Inventário cheio')
                && collectedMaterials['leather-strip'] === 99,
            'Um inventário cheio não bloqueou a forja antes de consumir materiais.');
        } finally {
            closeBlacksmithMenu(false);
            collectedMaterials = previousMaterials;
            craftedItemQuantities = previousCraftedItems;
            for (const ore of oreTypes) {
                oreCoinBalance[ore.id] = previousOreBalances[ore.id];
            }
            activeFloorNpcInteraction = previousActiveNpc;
            blacksmithMenuOpen = previousBlacksmithOpen;
            blacksmithLastInteractionFloor = previousLastInteractionFloor;
            discoveredBlacksmithRecipeIds = previousDiscoveredRecipes;
            if (previousBlacksmithStorage === null) {
                localStorage.removeItem(blacksmithStateStorageKey);
            } else {
                localStorage.setItem(blacksmithStateStorageKey, previousBlacksmithStorage);
            }
            blacksmithPanel.hidden = previousPanelHidden;
            info.textContent = previousInfo;
            updateMaterialInventoryHud();
            updateOreCoinHud();
        }
    });

    runTest('O monstruário do lobby reúne fichas, resumo e encontros especiais', () => {
        const previousStartScreenHidden = startScreen.hidden;
        try {
            bestiaryOpenButton.click();
            assert(bestiaryOpen && bestiaryPanel.hidden === false && startScreen.hidden,
                'O botão do lobby não abriu o painel do monstruário.');
                assert(bestiaryEntries.length === 16
                    && bestiaryContent.querySelectorAll('.bestiary-entry').length === 16,
                'O monstruário não exibiu todas as 16 fichas.');
                assert(bestiaryContent.querySelectorAll('.bestiary-facts > div').length === 16 * 12,
                'Uma ou mais fichas não têm os 12 campos definidos.');
                assert(bestiaryContent.querySelectorAll('.bestiary-table tbody tr').length === 16
                && bestiaryContent.querySelectorAll('.bestiary-event').length === 3,
            'A tabela-resumo ou os três encontros especiais estão incompletos.');
            assert(bestiaryContent.querySelectorAll('.bestiary-proposal').length === 6
                    && bestiaryNewContentEntries.length === 6
                    && bestiaryContent.textContent.includes('NPCs')
                    && bestiaryContent.textContent.includes('Criaturas extras'),
                'Os três novos mobs e os três NPCs ativos não estão descritos no monstruário.');
            assert(bestiaryContent.querySelectorAll('.bestiary-farm-card').length === 37
                && bestiaryContent.textContent.includes('Materiais e receitas relacionadas')
                && bestiaryContent.textContent.includes('Farm de materiais'),
            'O guia de farm não cobre os 37 materiais nem liga drops às receitas.');
            for (const recipe of materialRecipeData) {
                for (const ingredient of recipe.ingredients) {
                    const material = creatureMaterialDataById[ingredient.materialId];
                    const farmCard = [...bestiaryContent.querySelectorAll('.bestiary-farm-card')]
                        .find((card) => card.querySelector('h4').textContent === material?.name);
                    assert(farmCard && farmCard.textContent.includes(recipe.id),
                        `${recipe.id} não está ligada ao material ${ingredient.materialId} no guia de farm.`);
                }
            }
            for (const entry of bestiaryEntries) {
                const dropText = formatBestiaryDropTable(entry);
                assert(dropText
                    && entry.dropTable === creatureDataByType[entry.creatureType].drops
                    && bestiaryContent.textContent.includes(dropText),
                `${entry.name} não mostra a tabela de drops real com chance e quantidade.`);
            }
            for (const creatureName of [
                'Aranha de fuligem',
                'Cão de fuligem',
                'Sentinela de vitral',
                'Matriarca do Tear',
                'Guardião do Trono',
                'Morcego do veio',
                'Lagarto de basalto',
                'Escriba sem rosto',
                'Lia, cartógrafa das galerias',
                'Oren, ferreiro itinerante',
                'Nara, vigia das lanternas'
            ]) {
                assert(bestiaryContent.textContent.includes(creatureName),
                    `A ficha ou proposta de ${creatureName} não apareceu no monstruário.`);
            }
            assert(!bestiaryContent.textContent.includes('ainda não foi implementado'),
                'Uma criatura jogável está sendo marcada como não implementada.');
            const blacksmithBestiaryEntry = bestiaryNewContentEntries.find(
                (entry) => entry.name === 'Oren, ferreiro itinerante'
            );
            assert(blacksmithBestiaryEntry
                && blacksmithBestiaryEntry.role.includes('Ferreiro experiente')
                && blacksmithBestiaryEntry.mechanic.includes('receitas Iguais')
                && blacksmithBestiaryEntry.mechanic.includes('receitas Mix')
                && !blacksmithBestiaryEntry.mechanic.includes('recuperar até 25 de vida')
                && blacksmithBestiaryEntry.reward.includes('gratuita e instantânea'),
            'A ficha de Oren no Monstruário não descreve a forja atual.');
            assert(bestiaryContent.textContent.includes('Escriba sem rosto')
                && bestiaryContent.textContent.includes('Mecânica:')
                && bestiaryContent.textContent.includes('cartógrafa')
                && document.querySelector('.start-lore')?.textContent.includes('vinte andares'),
            'A lore inicial, as mecânicas ativas ou as fichas de NPC não foram exibidas.');
            const creatureFilter = bestiaryContent.querySelector(
                '[data-bestiary-filter="creatures"]'
            );
            const search = bestiaryContent.querySelector('[data-bestiary-search]');
            creatureFilter.click();
            search.value = 'Matriarca';
            search.dispatchEvent(new Event('input'));
            assert(bestiaryContent.querySelectorAll('.bestiary-entry:not([hidden])').length === 1
                && bestiaryContent.querySelector('.bestiary-entry:not([hidden])')
                    .textContent.includes('Matriarca do Tear'),
            'A busca e o filtro de criaturas não restringiram a lista corretamente.');
            assert(bestiaryContent.querySelector('[data-bestiary-results]').textContent
                .startsWith('1 criatura ·'),
            'O contador não acompanhou o resultado da busca.');
            bestiaryContent.querySelector('[data-bestiary-filter="all"]').click();
            search.value = '';
            search.dispatchEvent(new Event('input'));
            assert(bestiaryContent.querySelectorAll('.bestiary-entry:not([hidden])').length === 16,
                'Limpar os filtros não restaurou todas as fichas.');
            bestiaryContent.querySelector('[data-bestiary-filter="encounters"]').click();
            assert(!bestiaryContent.querySelector('[data-bestiary-section="encounters"]').hidden
                && bestiaryContent.querySelectorAll('.bestiary-event:not([hidden])').length === 3
                && bestiaryContent.querySelector('[data-bestiary-section="creatures"]').hidden,
            'O filtro de encontros não isolou os encontros especiais.');
            bestiaryContent.querySelector('[data-bestiary-filter="allies"]').click();
            assert(!bestiaryContent.querySelector('[data-bestiary-section="allies"]').hidden
                && bestiaryContent.querySelectorAll(
                    '[data-bestiary-section="allies"] .bestiary-proposal:not([hidden])'
                ).length === 3,
            'O filtro de criaturas extras não mostrou somente os três inimigos adicionais.');
            bestiaryContent.querySelector('[data-bestiary-filter="npcs"]').click();
            const npcSection = bestiaryContent.querySelector('[data-bestiary-section="npcs"]');
            assert(!npcSection.hidden
                && npcSection.querySelectorAll('.bestiary-proposal:not([hidden])').length === 3
                && bestiaryContent.querySelector('[data-bestiary-section="allies"]').hidden,
            'A aba de NPCs está misturando as fichas com conteúdo adicional de criaturas.');
            bestiaryContent.querySelector('[data-bestiary-filter="summary"]').click();
            assert(!bestiaryContent.querySelector('[data-bestiary-section="summary"]').hidden
                && bestiaryContent.querySelectorAll('.bestiary-table tbody tr:not([hidden])').length === 16,
            'O filtro de resumo não restaurou a tabela completa.');
            bestiaryContent.querySelector('[data-bestiary-filter="farm"]').click();
            const farmSection = bestiaryContent.querySelector('[data-bestiary-section="farm"]');
            assert(!farmSection.hidden
                && farmSection.querySelectorAll('[data-farm-card]:not([hidden])').length === 37
                && bestiaryContent.querySelector('[data-bestiary-section="npcs"]').hidden
                && bestiaryContent.querySelector('[data-bestiary-section="creatures"]').hidden,
            'O filtro de farm não isolou os 37 materiais e suas rotas.');
        } finally {
            setBestiaryOpen(false);
            startScreen.hidden = previousStartScreenHidden;
        }
    });

    runTest('Encontrar uma criatura registra a entrada persistente do bestiário', () => {
        const previousGameState = gameState;
        const previousDiscoveries = new Set(discoveredCreatureIds);
        const previousStoredDiscoveries = localStorage.getItem(bestiaryDiscoveryStorageKey);
        const previousDiscoveryStatus = {
            hidden: bestiaryDiscoveryStatus.hidden,
            text: bestiaryDiscoveryStatus.textContent
        };
        try {
            discoveredCreatureIds = new Set();
            gameState = 'playing';
            for (const creature of creatureData) {
                assert(discoverBestiaryCreature(creature.creatureType),
                    `A primeira descoberta de ${creature.name} não foi registrada.`);
                assert(!discoverBestiaryCreature(creature.creatureType),
                    `${creature.name} gerou a mesma descoberta mais de uma vez.`);
            }
            const persisted = JSON.parse(localStorage.getItem(bestiaryDiscoveryStorageKey));
            assert(persisted.length === creatureData.length
                && discoveredCreatureIds.size === creatureData.length,
            'As descobertas não foram persistidas para o bestiário durante o jogo.');
            renderBestiary();
            assert(bestiaryContent.querySelectorAll('.bestiary-entry').length === creatureData.length,
                'O painel do bestiário não listou todas as criaturas descobertas.');
        } finally {
            gameState = previousGameState;
            discoveredCreatureIds = previousDiscoveries;
            if (previousStoredDiscoveries === null) {
                localStorage.removeItem(bestiaryDiscoveryStorageKey);
            } else {
                localStorage.setItem(bestiaryDiscoveryStorageKey, previousStoredDiscoveries);
            }
            bestiaryDiscoveryStatus.hidden = previousDiscoveryStatus.hidden;
            bestiaryDiscoveryStatus.textContent = previousDiscoveryStatus.text;
            renderBestiary();
        }
    });

    runTest('Cada ficha do monstruário declara um tipo e um perfil de comportamento únicos', () => {
        const creatureTypes = bestiaryEntries.map((entry) => entry.creatureType);
        assert(creatureTypes.length === 16 && new Set(creatureTypes).size === 16,
            'Há fichas sem tipo próprio ou tipos repetidos no catálogo.');
        assert(bestiaryEntries.every((entry) => entry.behaviorProfile && entry.behavior),
            'Uma ficha não conecta sua descrição de comportamento ao perfil da criatura.');
        const heightByType = Object.fromEntries(
            bestiaryEntries.map((entry) => [entry.creatureType, entry.heightBlocks])
        );
        assert(heightByType.goblin === 1
            && heightByType.goblinRunner === 1
            && heightByType.spider === 1
            && heightByType.sootSpider === 1
            && heightByType.ashHound === 1
            && heightByType.veinBat === 1
            && heightByType.basaltLizard === 1
            && heightByType.matriarch === 2
            && heightByType.troll === 2
            && heightByType.ogre === 2
            && heightByType.stainedSentinel === 2,
        'As criaturas comuns não declaram a altura visual de um ou dois blocos.');
        assert(heightByType.facelessScribe === 2,
            'O Escriba sem rosto não declara sua altura visual de dois blocos.');
        assert(bestiaryEntries.every((entry) => (
            ['goblin', 'goblinRunner', 'spider', 'sootSpider', 'dragon', 'lavaGolem',
                'troll', 'ogre', 'ashHound', 'stainedSentinel', 'grimReaper', 'matriarch',
                'throneGuardian', 'veinBat', 'basaltLizard', 'facelessScribe'].includes(entry.creatureType)
        )), 'Uma ficha aponta para um tipo sem suporte no jogo.');
        assert(bestiaryEvents.length === 3 && bestiaryEvents.every((event) => (
            event.id && Number.isInteger(event.floor)
            && event.spawnTypes.length > 0
            && event.title
            && event.summary
            && event.participantIndexes.every((index) => event.spawnTypes[index])
        )), 'Um encontro especial não tem piso, composição ou participantes válidos.');
        assert(bestiaryEvents.some((event) => event.rewardScroll === 'conquista'),
            'O encontro do vitral não concede a recompensa secreta descrita.');
        assert(devCreatureSelect.options.length === 16
            && creatureData.every((creature) => (
                creatureDataByType[creature.creatureType] === creature
                && creature.stats.health > 0
                && creature.stats.damage > 0
                && creature.stats.speed > 0
                && creature.stats.range > 0
                && creature.colors.primary
                && creature.colors.secondary
                && creature.colors.accent
                && creature.sound.frequency > 0
                && Array.isArray(creature.attacks)
                && creature.attacks.length > 0
                && creature.attacks.filter((attack) => attack.cooldown > 0).every((attack) => (
                    attack.warning > 0 && attack.execution > 0 && attack.recovery > 0
                ))
                && creature.attacks.every((attack) => (
                    getCreatureAttackData(
                        { creatureType: creature.creatureType },
                        attack.id
                    ) === attack
                ))
                && creature.drops.every((drop) => (
                    drop.chance >= 0 && drop.chance <= 1
                    && drop.min > 0 && drop.max >= drop.min
                    && (drop.id === 'coin' || creatureMaterialDataById[drop.id])
                ))
            )),
        'O catálogo mecânico ou a lista do modo Dev não contém as 16 fichas completas.');
    });

    runTest('Os novos mobs e NPCs têm mecânicas e andares de aparição ativos', () => {
        const newCreatures = [
            ['veinBat', 'veinEchoHunter', 'echo-wave', 1, 4],
            ['basaltLizard', 'basaltBulwark', 'tail-sweep', 5, 9],
            ['facelessScribe', 'facelessGlyphcaster', 'ground-glyph', 10, 14]
        ];
        for (const [type, profile, attackId, firstFloor, lastFloor] of newCreatures) {
            const creature = creatureDataByType[type];
            const entry = bestiaryEntries.find((candidate) => candidate.creatureType === type);
            assert(creature && entry?.behaviorProfile === profile
                && creature.attacks.some((attack) => attack.id === attackId)
                && isCreatureSpawnAllowed(creature, firstFloor)
                && isCreatureSpawnAllowed(creature, lastFloor)
                && !isCreatureSpawnAllowed(creature, firstFloor - 1)
                && !isCreatureSpawnAllowed(creature, lastFloor + 1),
            `${type} não tem perfil, ataque ou faixa de aparição coerente.`);
        }
        const npcFloors = Object.fromEntries(
            floorNpcSchedule.map((npc) => [npc.id, npc.floors.join(',')])
        );
        assert(npcFloors.lia === '3,8,13'
            && npcFloors.oren === '6,11,16'
            && npcFloors.nara === '9,15'
            && typeof interactWithFloorNpc === 'function'
            && typeof chooseFloorNpcOption === 'function',
        'Os três NPCs não têm agenda ou interação utilizável.');
        const previousMap = map;
        const previousExit = exitPosition;
        try {
            map = Array.from({ length: rows }, () => Array(cols).fill('#'));
            map[5][5] = '.';
            map[5][6] = '.';
            map[5][7] = '.';
            exitPosition = { x: 7, y: 5 };
            const npc = {
                x: 5 * tileSize + tileSize / 2 - 7,
                y: 5 * tileSize + tileSize / 2 - 12,
                size: 14
            };
            assert(getPortalDirectionClue(npc) === 'leste',
                'A pista de Lia não aponta para a saída no corredor aberto.');
            map[5][6] = '#';
            map[6][5] = '.';
            map[7][5] = '.';
            map[7][6] = '.';
            map[7][7] = '.';
            exitPosition = { x: 7, y: 7 };
            assert(getPortalDirectionClue(npc) === 'sul',
                'A pista de Lia não segue uma rota acessível quando há um bloqueio direto.');
        } finally {
            map = previousMap;
            exitPosition = previousExit;
        }
    });

    runTest('Sprites pequenos reduzem em escala uniforme e não são esticados', () => {
        const smallSpiderScale = getEnemySpriteScale(
            creatureDataByType.spider,
            28
        );
        const smallHoundScale = getEnemySpriteScale(
            creatureDataByType.ashHound,
            14
        );
        const goblinScale = getEnemySpriteScale(
            creatureDataByType.goblin,
            18
        );
        const enlargedGoblinScale = getGoblinSpriteScale(creatureDataByType.goblin);
        const tallTrollScale = getEnemySpriteScale(
            creatureDataByType.troll,
            25
        );
        assert(smallSpiderScale === Math.min(1, tileSize / 28)
            && smallSpiderScale < 1
            && smallHoundScale === 1
            && goblinScale === Math.min(1, tileSize / 18)
            && enlargedGoblinScale === getEnemySpriteScale(creatureDataByType.goblin, 100) * 1.15 * 1.15
            && tallTrollScale === (tileSize * 2) / 25,
        'A escala não reduz sprites pequenos proporcionalmente, não aplica o aumento dos goblins ou altera os de dois blocos.');
    });

    runTest('As 16 fichas fornecem atributos carregados e faixas de spawn corretas', () => {
        const previousFloor = currentFloor;
        const previousCreatureBatch = enemyCreatureBatch;
        const previousEquipmentBatch = enemyEquipmentBatch;
        const previousEnemies = enemies;
        try {
            for (const creature of creatureData) {
                for (let floor = 1; floor <= finalFloor; floor += 1) {
                    const expected = creature.spawn.floors.some((range) => (
                        Array.isArray(range)
                            ? floor >= range[0] && floor <= range[1]
                            : floor === range
                    ));
                    assert(isCreatureSpawnAllowed(creature, floor) === expected,
                        `${creature.name} tem faixa de spawn incorreta no andar ${floor}.`);
                }
                currentFloor = creature.floors.min;
                enemyCreatureBatch = [];
                enemyEquipmentBatch = [];
                const enemy = isBossCreatureType(creature.creatureType)
                    ? createBoss(4, 4, creature.creatureType)
                    : createEnemy(4, 4, oreTypes[0], creature.creatureType);
                assert(enemy.creatureType === creature.creatureType
                    && enemy.resistances === creature.resistances
                    && enemy.attackProfiles === creature.attacks
                    && enemy.health > 0
                    && enemy.speed > 0
                    && enemy.meleeRange === creature.stats.range,
                `${creature.name} não carregou seus dados de combate.`);
                if (!enemy.isBoss) {
                    assert(enemy.maxHealth === getCreatureScaledStat(
                        creature.creatureType,
                        'health',
                        currentFloor
                    ) && enemy.damage === getCreatureScaledStat(
                        creature.creatureType,
                        'damage',
                        currentFloor
                    ), `${creature.name} não recebeu os atributos escalados de sua ficha.`);
                }
            }
        } finally {
            currentFloor = previousFloor;
            enemyCreatureBatch = previousCreatureBatch;
            enemyEquipmentBatch = previousEquipmentBatch;
            enemies = previousEnemies;
        }
    });

    runTest('Os spawns comuns respeitam pesos, tamanhos de grupo e composição', () => {
        const previousFloor = currentFloor;
        try {
            for (let floor = 1; floor <= finalFloor; floor += 1) {
                currentFloor = floor;
                const groups = getFloorCreatureSpawnGroups(12);
                assert(groups.reduce((total, group) => total + group.size, 0) === 12,
                    `Os grupos do andar ${floor} não preencheram as vagas de inimigos.`);
                groups.forEach((group, index) => {
                    const creature = creatureDataByType[group.creatureType];
                    const [minimum, maximum] = creature.spawn.group;
                    assert(group.size <= maximum
                        && (index === groups.length - 1 || group.size >= minimum),
                    `${creature.name} ignorou o tamanho de grupo configurado.`);
                    assert(isCreatureSpawnAllowed(creature, floor),
                        `${creature.name} surgiu fora de seus andares permitidos.`);
                });
                const tiles = Array.from({ length: 12 }, (_, index) => ({
                    x: index % 4,
                    y: Math.floor(index / 4)
                }));
                const clusteredSpawns = clusterFloorSpawnGroups(groups, tiles);
                assert(clusteredSpawns.length === 12
                    && groups.every((group) => (
                        clusteredSpawns.filter((spawn) => (
                            spawn.creatureType === group.creatureType
                        )).length >= group.size
                    )),
                `Os grupos do andar ${floor} não foram associados às posições do mapa.`);
            }
        } finally {
            currentFloor = previousFloor;
        }
    });

    runTest('As criaturas especiais e os novos mobs inicializam seus arquétipos', () => {
        const previousFloor = currentFloor;
        const previousCreatureBatch = enemyCreatureBatch;
        const previousEquipmentBatch = enemyEquipmentBatch;
        try {
            currentFloor = 5;
            enemyCreatureBatch = [];
            const sootSpider = createEnemy(4, 4, chooseOreDrop(), 'sootSpider');
            assert(sootSpider.creatureType === 'sootSpider'
                && sootSpider.speed > 27.5
                && sootSpider.heightBlocks === 1
                && sootSpider.collisionWidth === 12
                && sootSpider.collisionHeight === 10,
                'A Aranha de fuligem não tem seu arquétipo veloz.');

            currentFloor = 12;
            enemyCreatureBatch = [];
            const ashHound = createEnemy(4, 4, chooseOreDrop(), 'ashHound');
            const sentinel = createEnemy(5, 5, chooseOreDrop(), 'stainedSentinel');
            assert(ashHound.creatureType === 'ashHound' && ashHound.dogPounceCooldown > 0,
                'O Cão de fuligem não inicializa sua investida.');
            assert(sentinel.creatureType === 'stainedSentinel'
                && sentinel.sentinelBeamCooldown > 0
                && sentinel.heightBlocks === 2
                && sentinel.collisionWidth === 12
                && sentinel.collisionHeight === 12,
            'A Sentinela de vitral não inicializa seu disparo anunciado.');
            const troll = createEnemy(6, 6, chooseOreDrop(), 'troll');
            const ogre = createEnemy(7, 7, chooseOreDrop(), 'ogre');
            assert(troll.heightBlocks === 2 && ogre.heightBlocks === 2,
                'Troll e ogro não recebem a altura visual de dois blocos.');

            currentFloor = 8;
            enemyCreatureBatch = [];
            const matriarch = createEnemy(4, 4, chooseOreDrop(), 'matriarch');
            assert(matriarch.isMiniBoss
                && matriarch.maxHealth === 180
                && matriarch.heightBlocks === 2,
            'A Matriarca do Tear não está configurada como minichefe de dois blocos.');

            currentFloor = 1;
            enemyCreatureBatch = [];
            const veinBat = createEnemy(4, 4, chooseOreDrop(), 'veinBat');
            assert(veinBat.behaviorProfile === 'veinEchoHunter'
                && veinBat.echoWaveCooldown > 0
                && veinBat.collisionWidth === 12,
            'O Morcego do veio não inicializa sua onda de eco.');
            currentFloor = 5;
            enemyCreatureBatch = [];
            const basaltLizard = createEnemy(4, 4, chooseOreDrop(), 'basaltLizard');
            assert(basaltLizard.behaviorProfile === 'basaltBulwark'
                && basaltLizard.tailSweepCooldown > 0
                && basaltLizard.resistances.frontalPhysical === 0.65,
            'O Lagarto de basalto não inicializa a defesa e a varrida de cauda.');
            currentFloor = 10;
            enemyCreatureBatch = [];
            const facelessScribe = createEnemy(4, 4, chooseOreDrop(), 'facelessScribe');
            assert(facelessScribe.behaviorProfile === 'facelessGlyphcaster'
                && facelessScribe.glyphCooldown > 0
                && facelessScribe.heightBlocks === 2,
            'O Escriba sem rosto não inicializa seu glifo de dois blocos.');

            currentFloor = finalFloor;
            enemyCreatureBatch = [];
            const guardian = createBoss(5, 5, 'throneGuardian');
            assert(guardian.isBoss && guardian.bossType === 'throneGuardian'
                && guardian.veinPulseCooldown > 0,
            'O Guardião do Trono não está configurado como chefe final.');

            currentFloor = 3;
            enemyCreatureBatch = [];
            enemyEquipmentBatch = [];
            const runner = createEnemy(4, 4, chooseOreDrop(), 'goblinRunner');
            assert(runner.creatureType === 'goblinRunner'
                && runner.behaviorProfile === 'courierSkirmisher'
                && runner.archetype === 'runner'
                && runner.speed >= 45
                && runner.damage <= createEnemy(4, 4, chooseOreDrop(), 'goblin').damage
                && runner.equipment === null
                && runner.armorDurability === 0
                && runner.shieldDurability === 0,
            'O corredor não foi separado do goblin ou perdeu seu perfil veloz e sem escudo.');

            currentFloor = 8;
            enemyCreatureBatch = [];
            enemyEquipmentBatch = [];
            const devMatriarch = createDevEnemy(4, 4, 'matriarch');
            assert(devMatriarch.creatureType === 'matriarch'
                && devMatriarch.isMiniBoss
                && !devMatriarch.isBoss
                && devMatriarch.bossType === undefined
                && !isBossCreatureType('matriarch'),
            'O modo Dev está tratando a Matriarca como chefe e desenhando outro boss no lugar dela.');
            const devLavaGolem = createDevEnemy(5, 5, 'lavaGolem');
            assert(devLavaGolem.isBoss
                && devLavaGolem.bossType === 'lavaGolem'
                && isBossCreatureType('lavaGolem'),
            'A seleção de chefe do modo Dev não inicializou corretamente o golem de lava.');
        } finally {
            currentFloor = previousFloor;
            enemyCreatureBatch = previousCreatureBatch;
            enemyEquipmentBatch = previousEquipmentBatch;
        }
    });

    runTest('Os 16 tipos do modo Dev renderizam sem confundir a Matriarca com um chefe', () => {
        const previousFloor = currentFloor;
        const previousCreatureBatch = enemyCreatureBatch;
        const previousEquipmentBatch = enemyEquipmentBatch;
        const previousContext = ctx;
        const galleryCanvas = document.createElement('canvas');
        galleryCanvas.width = 1200;
        galleryCanvas.height = 800;
        try {
            currentFloor = 8;
            enemyCreatureBatch = [];
            enemyEquipmentBatch = [];
            ctx = galleryCanvas.getContext('2d');
            ctx.imageSmoothingEnabled = false;
            ctx.setTransform(renderPixelScale, 0, 0, renderPixelScale, 0, 0);
            for (const [index, creature] of creatureData.entries()) {
                const enemy = createDevEnemy(1, 1, creature.creatureType);
                enemy.x = 35 + (index % 4) * 85;
                enemy.y = 35 + Math.floor(index / 4) * 56;
                enemy.moving = false;
                enemy.animTime = 0.1;
                assert(enemy.creatureType === creature.creatureType,
                    `${creature.name} foi inicializada como outro tipo.`);
                assert(Boolean(enemy.isBoss) === isBossCreatureType(creature.creatureType),
                    `${creature.name} foi classificada incorretamente como chefe.`);
                if (creature.creatureType === 'matriarch') {
                    assert(enemy.isMiniBoss && enemy.bossType === undefined,
                        'A Matriarca não manteve o sprite e o estado de minichefe próprios.');
                }
                drawEnemy(enemy);
            }
        } finally {
            ctx = previousContext;
            currentFloor = previousFloor;
            enemyCreatureBatch = previousCreatureBatch;
            enemyEquipmentBatch = previousEquipmentBatch;
        }
    });

    runTest('Lia, Oren e Nara renderizam seus detalhes procedurais em pixel art', () => {
        const previousContext = ctx;
        const npcCanvas = document.createElement('canvas');
        npcCanvas.width = 160;
        npcCanvas.height = 120;
        try {
            ctx = npcCanvas.getContext('2d');
            ctx.imageSmoothingEnabled = false;
            ctx.setTransform(renderPixelScale, 0, 0, renderPixelScale, 0, 0);
            for (const [index, id] of ['lia', 'oren', 'nara'].entries()) {
                drawFloorNpc({
                    id,
                    name: id,
                    color: '#ffffff',
                    x: 16 + index * 24,
                    y: 16,
                    size: 16
                });
            }
        } finally {
            ctx = previousContext;
        }
    });

    runTest('As 16 criaturas geram todos os materiais previstos nos drops', () => {
        const previousEnemies = enemies;
        const previousItemDrops = itemDrops;
        const previousOreDrops = oreDrops;
        const previousProgress = playerProgress;
        const previousPlayer = player;
        const previousPlayerState = {
            ...player,
            specialAbilityCharges: { ...player.specialAbilityCharges },
            specialAbilityCooldowns: { ...player.specialAbilityCooldowns }
        };
        const previousBotMode = botMode;
        const previousFloorKillCount = floorKillCount;
        const previousPortalUnlocked = portalUnlocked;
        const previousBossDefeated = bossDefeatedThisFloor;
        const previousEncounterId = activeFloorEncounterId;
        const previousRaceWar = raceWarActive;
        const previousRandom = Math.random;
        try {
            enemies = [];
            itemDrops = [];
            oreDrops = [];
            playerProgress = { ...playerProgress, attributes: { ...playerProgress.attributes } };
            botMode = false;
            floorKillCount = 0;
            portalUnlocked = false;
            bossDefeatedThisFloor = false;
            activeFloorEncounterId = null;
            raceWarActive = false;
            Math.random = () => 0;
            for (const creature of creatureData) {
                const target = {
                    creatureType: creature.creatureType,
                    x: 80,
                    y: 80,
                    size: 16,
                    health: 0,
                    maxHealth: creature.stats.health,
                    dropOre: oreTypes[0],
                    isBoss: false,
                    isMiniBoss: creature.creatureType === 'matriarch',
                    defeatResolved: false
                };
                const itemDropCount = itemDrops.length;
                const coinDropCount = oreDrops.length;
                resolveEnemyDefeat(target);
                for (const drop of creature.drops) {
                    if (drop.id === 'coin') {
                        assert(oreDrops.length > coinDropCount,
                            `${creature.name} não gerou as moedas previstas.`);
                    } else {
                        assert(itemDrops.slice(itemDropCount).some((item) => item.materialId === drop.id),
                            `${creature.name} não gerou o material ${drop.id}.`);
                    }
                }
            }
        } finally {
            Math.random = previousRandom;
            enemies = previousEnemies;
            itemDrops = previousItemDrops;
            oreDrops = previousOreDrops;
            playerProgress = previousProgress;
            player = previousPlayer;
            Object.assign(player, previousPlayerState);
            botMode = previousBotMode;
            floorKillCount = previousFloorKillCount;
            portalUnlocked = previousPortalUnlocked;
            bossDefeatedThisFloor = previousBossDefeated;
            activeFloorEncounterId = previousEncounterId;
            raceWarActive = previousRaceWar;
            updateProgressHud();
        }
    });

    runTest('Os 37 ícones de materiais usam recortes transparentes pelas bordas', () => {
        const previousMaterials = collectedMaterials;
        try {
            collectedMaterials = Object.fromEntries(
                creatureMaterialData.map((material) => [material.id, 1])
            );
            updateMaterialInventoryHud();
            const icons = Array.from(materialInventoryItems.querySelectorAll('.material-pixel-icon'));
            assert(creatureMaterialIconSprites.size === creatureMaterialData.length
                && icons.length === creatureMaterialData.length
                && creatureMaterialData.every((material, index) => {
                    const sprite = creatureMaterialIconSprites.get(material.id);
                    return sprite
                        && sprite.complete
                        && sprite.naturalWidth > 0
                        && sprite.naturalWidth <= 128
                        && sprite.naturalHeight > 0
                        && sprite.naturalHeight <= 128
                        && icons[index].tagName === 'IMG'
                        && icons[index].src === sprite.src;
                }), 'O inventário não carregou todos os PNGs individuais, recortados e limitados a 128 px.');
            assert(icons.every((icon) => (
                getComputedStyle(icon).objectFit === 'contain'
                    && getComputedStyle(icon).imageRendering === 'pixelated'
                    && icon.getAttribute('aria-hidden') === 'true'
            )), 'Os recortes não preservam a proporção ou o estilo pixel-art no inventário.');
            const leatherStripSlot = Array.from(
                materialInventoryItems.querySelectorAll('.material-slot')
            ).find((slot) => slot.getAttribute('aria-label').startsWith('Tira de couro.'));
            assert(leatherStripSlot
                && leatherStripSlot.getAttribute('aria-label').includes(
                    'Goblin das galerias (28%; 1 por drop)'
                )
                && leatherStripSlot.title.includes('Pode cair de:'),
            'O inventário não informa a origem e a chance real dos materiais.');
            const alphaCanvas = document.createElement('canvas');
            alphaCanvas.width = 128;
            alphaCanvas.height = 128;
            const alphaContext = alphaCanvas.getContext('2d', { willReadFrequently: true });
            assert(icons.every((icon) => {
                alphaContext.clearRect(0, 0, 128, 128);
                alphaContext.drawImage(icon, 0, 0);
                const pixels = alphaContext.getImageData(0, 0, 128, 128).data;
                return pixels[3] === 0
                    && pixels[(127 * 128) * 4 + 3] === 0
                    && pixels[(127 * 128 + 127) * 4 + 3] === 0
                    && pixels[(127) * 4 + 3] === 0;
            }), 'Um ícone não mantém transparência nas bordas do recorte.');
            const previousDrops = itemDrops;
            const previousDrawImage = ctx.drawImage;
            const drawnSprites = [];
            try {
                itemDrops = creatureMaterialData.map((material) => ({
                    type: 'material',
                    materialId: material.id,
                    x: 32,
                    y: 32,
                    animTime: 0
                }));
                ctx.save();
                ctx.drawImage = (...args) => drawnSprites.push(args);
                drawItemDrops();
            } finally {
                ctx.drawImage = previousDrawImage;
                ctx.restore();
                itemDrops = previousDrops;
            }
            assert(drawnSprites.length === creatureMaterialData.length
                && drawnSprites.every((args, index) => {
                    const sprite = creatureMaterialIconSprites.get(creatureMaterialData[index].id);
                    const scale = 16 / Math.max(sprite.naturalWidth, sprite.naturalHeight);
                    const width = sprite.naturalWidth * scale;
                    const height = sprite.naturalHeight * scale;
                    return args.length === 5
                        && args[0] === sprite
                        && args[1] === 32 - width / 2
                        && args[2] === 32 - height / 2
                        && args[3] === width
                        && args[4] === height;
                }), 'Os drops usam os PNGs individuais e mantêm a proporção dentro do tamanho original de 16 px.');
        } finally {
            collectedMaterials = previousMaterials;
            updateMaterialInventoryHud();
        }
    });

    runTest('Todos os itens do inventário usam recortes transparentes e arte pixelada', () => {
        const previousMaterials = collectedMaterials;
        const previousHealingPotions = healingPotions;
        try {
            collectedMaterials = Object.fromEntries(
                creatureMaterialData.map((material) => [material.id, 1])
            );
            updateMaterialInventoryHud();
            const equipmentIcons = Array.from(
                inventoryItems.querySelectorAll('.equipment-icon')
            );
            const scrollIcons = Array.from(
                inventoryItems.querySelectorAll('.inventory-scroll-slot img')
            );
            const materialIcons = Array.from(
                materialInventoryItems.querySelectorAll('.material-pixel-icon')
            );
            const currencyIcons = Array.from(
                inventoryPanel.querySelectorAll('.ore-currency-icon')
            );
            const visibleItemNames = Array.from(
                inventoryPanel.querySelectorAll(
                    '.inventory-slot .inventory-item-name, .inventory-scroll-slot .inventory-item-name'
                )
            );
            const slotStyle = getComputedStyle(swordSlot);
            const expectedEquipmentFiles = [
                'sword.png',
                'spear.png',
                'bow.png',
                'potion-common.png',
                'shield.png',
                'armor.png'
            ];
            assert(equipmentIcons.length === expectedEquipmentFiles.length
                && equipmentIcons.every((icon, index) => (
                    icon.tagName === 'IMG'
                    && icon.src.endsWith(`/assets/inventory-items/${expectedEquipmentFiles[index]}`)
                    && icon.complete
                    && icon.naturalWidth > 0
                    && icon.naturalWidth <= 128
                    && icon.naturalHeight > 0
                    && icon.naturalHeight <= 128
                )), 'Os equipamentos não carregam seus recortes individuais com até 128 px.');
            assert(equipmentIcons.every((icon) => (
                getComputedStyle(icon).objectFit === 'contain'
                    && icon.getAttribute('aria-hidden') === 'true'
            )), 'Os itens não preservam a proporção ou a semântica decorativa.');
            const craftingIcons = Array.from(
                craftingRecipeList.querySelectorAll('.crafting-recipe-icon')
            );
            assert([...equipmentIcons, ...scrollIcons, ...materialIcons, ...currencyIcons, ...craftingIcons]
                .every((icon) => getComputedStyle(icon).imageRendering === 'pixelated'),
            'Alguns itens não preservam a renderização pixelada.');
            const iconAlphaCanvas = document.createElement('canvas');
            iconAlphaCanvas.width = 128;
            iconAlphaCanvas.height = 128;
            const iconAlphaContext = iconAlphaCanvas.getContext('2d', { willReadFrequently: true });
            assert([...equipmentIcons, ...craftingIcons].every((icon) => {
                iconAlphaContext.clearRect(0, 0, 128, 128);
                iconAlphaContext.drawImage(icon, 0, 0);
                const pixels = iconAlphaContext.getImageData(0, 0, 128, 128).data;
                return pixels[3] === 0
                    && pixels[(127 * 128) * 4 + 3] === 0
                    && pixels[(127 * 128 + 127) * 4 + 3] === 0
                    && pixels[(127) * 4 + 3] === 0;
            }), 'Um ícone de equipamento, receita ou poção perdeu a transparência ao ser recortado.');
            healingPotions = itemRarities.map((rarity) => ({ type: 'potion', rarity }));
            updatePotionHud();
            const potionSlotIcon = potionSlot.querySelector('.potion-inventory-icon');
            assert(potionSlotIcon.src.endsWith('/assets/inventory-items/potion-legendary.png')
                && itemRarities.every((rarity) => {
                    healingPotions = [{ type: 'potion', rarity }];
                    updatePotionHud();
                    const icon = potionSlot.querySelector('.potion-inventory-icon');
                    return icon.src.endsWith(`/assets/inventory-items/potion-${rarity.id}.png`)
                        && icon.complete
                        && icon.naturalWidth > 0;
                }), 'O inventário não mostra a poção de maior raridade disponível.');
            assert(visibleItemNames.length === 6 + scrollTypes.length
                + creatureMaterialData.length + materialRecipeData.length
                && visibleItemNames.every((name) => (
                    getComputedStyle(name).position === 'absolute'
                    && getComputedStyle(name).clipPath === 'none'
                    && name.textContent.trim().length > 0
                )),
            'Os ícones não exibem nomes legíveis para identificar os itens.');
            assert(slotStyle.backgroundColor === 'rgb(57, 53, 45)'
                && getComputedStyle(inventoryPanel).borderColor === 'rgb(36, 29, 21)'
                && getComputedStyle(document.querySelector('.game-scene')).borderRadius === '0px'
                && getComputedStyle(document.querySelector('.start-card')).backgroundImage === 'none'
                && getComputedStyle(document.querySelector('.health-fill')).backgroundImage === 'none',
            'Os elementos de interface sem sprite não usam o acabamento pixel-art da paleta escura.');
        } finally {
            collectedMaterials = previousMaterials;
            healingPotions = previousHealingPotions;
            updateMaterialInventoryHud();
            updatePotionHud();
        }
    });

    runTest('Flechas e poções caídas usam seus ícones individuais', () => {
        const previousDrops = itemDrops;
        const previousDrawImage = ctx.drawImage;
        const drawnSprites = [];
        try {
            itemDrops = [
                { type: 'arrows', x: 32, y: 32, animTime: 0 },
                ...itemRarities.map((rarity) => ({
                    type: 'potion',
                    rarity,
                    x: 32,
                    y: 32,
                    animTime: 0
                }))
            ];
            ctx.save();
            ctx.drawImage = (...args) => drawnSprites.push(args);
            drawItemDrops();
        } finally {
            ctx.drawImage = previousDrawImage;
            ctx.restore();
            itemDrops = previousDrops;
        }
        const expectedSprites = [
            equipmentDropSprites.arrows,
            ...itemRarities.map((rarity) => potionIconSprites.get(rarity.id))
        ];
        assert(expectedSprites.every((sprite) => (
            sprite && sprite.complete && sprite.naturalWidth > 0 && sprite.naturalHeight > 0
        )), 'Um ícone de flechas ou de poção não terminou de carregar.');
        assert(drawnSprites.length === expectedSprites.length
            && drawnSprites.every((args, index) => {
                const sprite = expectedSprites[index];
                const scale = 16 / Math.max(sprite.naturalWidth, sprite.naturalHeight);
                const width = sprite.naturalWidth * scale;
                const height = sprite.naturalHeight * scale;
                return args.length === 5
                    && args[0] === sprite
                    && args[1] === 32 - width / 2
                    && args[2] === 32 - height / 2
                    && args[3] === width
                    && args[4] === height;
            }), 'Os ícones no chão não mantêm a imagem correta e o limite visual de 16 px.');
    });

    runTest('O inventário Dev inclui todos os drops de criaturas e itens de teste', () => {
        const previous = {
            gearUpgrades: { ...gearUpgrades },
            spearOwned,
            bowOwned,
            arrowAmmo,
            dashUpgradeOwned,
            gearOwned: { ...gearOwned },
            gearDurability: { ...gearDurability },
            shieldBlocking,
            healingPotions: healingPotions.slice(),
            collectedMaterials: { ...collectedMaterials },
            scrollInventory: { ...scrollInventory },
            oreCoinBalance: { ...oreCoinBalance },
            player: {
                damage: player.damage,
                defense: player.defense,
                health: player.health,
                poisonTimer: player.poisonTimer,
                poisonTickTimer: player.poisonTickTimer,
                poisonDamageRemaining: player.poisonDamageRemaining,
                burnTimer: player.burnTimer,
                burnTickTimer: player.burnTickTimer,
                burnDamageRemaining: player.burnDamageRemaining
            }
        };
        try {
            initializeDevLoadout();
            const expectedMaterials = new Set(
                creatureData.flatMap((creature) => creature.drops.map((drop) => drop.id))
                    .filter((dropId) => dropId !== 'coin')
            );
            assert(Object.keys(collectedMaterials).length === expectedMaterials.size
                && [...expectedMaterials].every((materialId) => (
                    collectedMaterials[materialId] === 99
                )),
            'O inventário Dev não recebeu todos os materiais únicos dos drops de criaturas.');
            assert(oreTypes.every((ore) => oreCoinBalance[ore.id] === 99)
                && Object.keys(scrollInventory).every((scrollId) => scrollInventory[scrollId] === 1)
                && healingPotions.length === itemRarities.length
                && arrowAmmo === GAME_BALANCE.bow.maxAmmo,
            'O inventário Dev não disponibilizou moedas, pergaminhos, poções e flechas.');
        } finally {
            gearUpgrades = previous.gearUpgrades;
            spearOwned = previous.spearOwned;
            bowOwned = previous.bowOwned;
            arrowAmmo = previous.arrowAmmo;
            dashUpgradeOwned = previous.dashUpgradeOwned;
            gearOwned = previous.gearOwned;
            gearDurability = previous.gearDurability;
            shieldBlocking = previous.shieldBlocking;
            healingPotions = previous.healingPotions;
            collectedMaterials = previous.collectedMaterials;
            for (const [scrollId, quantity] of Object.entries(previous.scrollInventory)) {
                scrollInventory[scrollId] = quantity;
            }
            for (const [oreId, quantity] of Object.entries(previous.oreCoinBalance)) {
                oreCoinBalance[oreId] = quantity;
            }
            Object.assign(player, previous.player);
            updateHealthHud();
            updateSwordHud();
            updateSpearHud();
            updateBowHud();
            updatePotionHud();
            updateEquipmentHud();
            updateScrollInventoryHud();
            updateMaterialInventoryHud();
            updateOreCoinHud();
        }
    });

    runTest('O golpe corpo a corpo comum respeita aviso antes de causar dano', () => {
        const previousEnemies = enemies;
        const previousHealth = player.health;
        const previousCooldown = player.damageCooldown;
        const previousGameState = gameState;
        const previousDevMode = devMode;
        const previousFloor = currentFloor;
        const previousRandom = Math.random;
        try {
            currentFloor = 1;
            devMode = false;
            gameState = 'playing';
            player.health = 50;
            player.damageCooldown = 0;
            Math.random = () => 0.99;
            const goblin = createEnemy(4, 4, oreTypes[0], 'goblin');
            goblin.x = player.x;
            goblin.y = player.y;
            goblin.attackCooldown = 0;
            goblin.attackWarningTimer = 0;
            goblin.attackReady = false;
            enemies = [goblin];
            moveEnemy(goblin, 0.016);
            assert(goblin.attackWarningTimer > 0 && player.health === 50,
                'O goblin causou dano sem completar a sinalização de ataque.');
            const attack = getCreatureAttackData(goblin, 'scrap-slash');
            moveEnemy(goblin, attack.warning + attack.execution + 0.01);
            checkCollision();
            assert(player.health < 50,
                'O golpe anunciado do goblin não causou dano após o tempo de aviso.');
        } finally {
            Math.random = previousRandom;
            enemies = previousEnemies;
            player.health = previousHealth;
            player.damageCooldown = previousCooldown;
            gameState = previousGameState;
            devMode = previousDevMode;
            currentFloor = previousFloor;
            updateHealthHud();
        }
    });

    runTest('Cada goblin usa sua propria folha de animacoes', () => {
        const expectedAnimations = [
            'idle', 'walk', 'run', 'bladeAttack', 'shieldAttack', 'defend',
            'takeDamage', 'death', 'jump', 'crouch', 'interact', 'carryItem', 'useItem'
        ];
        const frames = Object.values(goblinAnimationFrameMap)
            .flatMap((animation) => animation.frames);
        const runnerFrames = Object.values(goblinRunnerAnimationFrameMap)
            .flatMap((animation) => animation.frames);
        const getCroppedFrames = (spriteSheet, frameMap) => Object.entries(frameMap)
            .flatMap(([name, animation]) => animation.frames.map((frame, index) => ({
                frame,
                crop: getAnimationFrameCrop(spriteSheet, frameMap, name, index)
            })));
        const croppedFrames = getCroppedFrames(goblinAnimationSheet, goblinAnimationFrameMap);
        const croppedRunnerFrames = getCroppedFrames(
            goblinRunnerAnimationSheet,
            goblinRunnerAnimationFrameMap
        );
        const cropsStayInsideTheirFrames = (cropped) => cropped.every(({ frame, crop }) => (
            crop.x >= frame[0]
            && crop.y >= frame[1]
            && crop.x + crop.width <= frame[0] + frame[2]
            && crop.y + crop.height <= frame[1] + frame[3]
            && crop.offsetX === crop.x - frame[0]
            && crop.offsetY === crop.y - frame[1]
        ));
        assert(expectedAnimations.every((name) => goblinAnimationFrameMap[name])
            && Object.keys(goblinAnimationFrameMap).length === expectedAnimations.length
            && frames.length === 62
            && frames.every(([x, y, width, height]) => (
                x >= 0 && y >= 0 && width > 0 && height > 0
                && x + width <= 1152 && y + height <= 768
            ))
            && goblinAnimationSheet.src.endsWith('/assets/goblin-animations.png'),
        'A folha do goblin das galerias ou seu mapeamento esta incompleto.');
        assert(expectedAnimations.every((name) => goblinRunnerAnimationFrameMap[name])
            && Object.keys(goblinRunnerAnimationFrameMap).length === expectedAnimations.length
            && runnerFrames.length === 68
            && runnerFrames.every(([x, y, width, height]) => (
                x >= 0 && y >= 0 && width > 0 && height > 0
                && x + width <= 1151 && y + height <= 768
            ))
            && cropsStayInsideTheirFrames(croppedFrames)
            && cropsStayInsideTheirFrames(croppedRunnerFrames)
            && croppedFrames.some(({ frame, crop }) => (
                crop.width < frame[2] || crop.height < frame[3]
            ))
            && croppedRunnerFrames.some(({ frame, crop }) => (
                crop.width < frame[2] || crop.height < frame[3]
            ))
            && goblinRunnerAnimationSheet.src.endsWith('/assets/goblin-runner-animations.png'),
        'A folha do goblin corredor ou seu mapeamento esta incompleto.');
        const goblin = createEnemy(4, 4, oreTypes[0], 'goblin');
        const goblinRunner = createEnemy(4, 4, oreTypes[0], 'goblinRunner');
        const getAnimation = (overrides) => {
            Object.assign(goblin, overrides);
            return getGoblinAnimationState(goblin).name;
        };
        const getRunnerAnimation = (overrides) => {
            Object.assign(goblinRunner, overrides);
            return getGoblinAnimationState(goblinRunner).name;
        };
        const getFirstFrameIndex = (frameMap, name, progress) => Math.floor(
            progress * goblinAnimationSpeedMultiplier * frameMap[name].frames.length
        );
        const getFinalFrameIndex = (frameMap, name) => getGoblinAnimationFrameIndex(
            frameMap[name],
            { name, progress: 1 }
        );
        assert(usesGoblinAnimation(goblin)
            && usesGoblinAnimation(goblinRunner)
            && goblinAnimationSpeedMultiplier === 0.672
            && getGoblinAnimationAssets(goblin).spriteSheet === goblinAnimationSheet
            && getGoblinAnimationAssets(goblin).frameMap === goblinAnimationFrameMap
            && getGoblinAnimationAssets(goblinRunner).spriteSheet === goblinRunnerAnimationSheet
            && getGoblinAnimationAssets(goblinRunner).frameMap === goblinRunnerAnimationFrameMap
            && getFirstFrameIndex(goblinAnimationFrameMap, 'walk', 0.5) === 2
            && getFirstFrameIndex(goblinRunnerAnimationFrameMap, 'walk', 0.5) === 2
            && goblinDeathAnimationDuration === 0.6
            && getFinalFrameIndex(goblinAnimationFrameMap, 'death')
                === goblinAnimationFrameMap.death.frames.length - 1
            && getFinalFrameIndex(goblinRunnerAnimationFrameMap, 'death')
                === goblinRunnerAnimationFrameMap.death.frames.length - 1
            && hasGoblinSpriteAttackAnimation(goblin)
            && hasGoblinSpriteAttackAnimation(goblinRunner)
            && !hasGoblinSpriteAttackAnimation(createEnemy(4, 4, oreTypes[0], 'spider'))
            && getAnimation({ moving: false, attackTimer: 1, shieldDurability: 0 }) === 'bladeAttack'
            && getRunnerAnimation({ moving: false, attackTimer: 1, shieldDurability: 0 }) === 'bladeAttack'
            && getAnimation({ moving: false, attackTimer: 0 }) === 'idle'
            && getAnimation({ moving: true }) === 'walk'
            && getAnimation({ creatureType: 'goblinRunner' }) === 'run'
            && getAnimation({ moving: false, attackTimer: 1 }) === 'bladeAttack'
            && getAnimation({ shieldDurability: 1 }) === 'shieldAttack'
            && getAnimation({ attackTimer: 0, defendTimer: 0.35 }) === 'defend'
            && getAnimation({ defendTimer: 0, painTimer: 0.2 }) === 'takeDamage'
            && getAnimation({ painTimer: 0, jumpTimer: 0.36 }) === 'jump'
            && getAnimation({ jumpTimer: 0, dodgeTimer: 0.36 }) === 'crouch'
            && getAnimation({
                dodgeTimer: 0,
                dying: true,
                deathTimer: goblinDeathAnimationDuration,
                deathAnimationDuration: goblinDeathAnimationDuration
            }) === 'death',
        'Um estado de movimento, ataque, defesa, dano, pulo, esquiva ou morte nao escolheu sua animacao.');
    });

    runTest('A aranha usa os quadros corretos e recortados de cada animacao', () => {
        const frames = Object.values(spiderAnimationFrameMap)
            .flatMap((animation) => animation.frames);
        const croppedFrames = Object.entries(spiderAnimationFrameMap)
            .flatMap(([name, animation]) => animation.frames.map((frame, index) => ({
                frame,
                crop: getAnimationFrameCrop(
                    spiderAnimationSheet,
                    spiderAnimationFrameMap,
                    name,
                    index
                )
            })));
        const cropsStayInsideTheirFrames = croppedFrames.every(({ frame, crop }) => (
            crop.x >= frame[0]
            && crop.y >= frame[1]
            && crop.x + crop.width <= frame[0] + frame[2]
            && crop.y + crop.height <= frame[1] + frame[3]
            && crop.offsetX === crop.x - frame[0]
            && crop.offsetY === crop.y - frame[1]
        )) && croppedFrames.every(({ crop }) => crop.frameWidth > 0 && crop.frameHeight > 0);
        const spider = createEnemy(4, 4, oreTypes[0], 'spider');
        const backgroundCanvas = document.createElement('canvas');
        backgroundCanvas.width = 1;
        backgroundCanvas.height = 1;
        const backgroundContext = backgroundCanvas.getContext('2d');
        backgroundContext.drawImage(spiderAnimationSheet, 0, 0);
        const backgroundIsTransparent = backgroundContext.getImageData(0, 0, 1, 1).data[3] === 0;
        spider.moving = true;
        const walkRightState = getSpiderAnimationState(spider);
        spider.spriteFacingX = -1;
        const walkLeftState = getSpiderAnimationState(spider);
        spider.moving = false;
        spider.spriteFacingX = 1;
        spider.attackTimer = 0.24;
        const jumpState = getSpiderAnimationState(spider);
        spider.attackTimer = 0;
        spider.spiderLeapTimer = 0.46;
        const preparationState = getSpiderAnimationState(spider);
        spider.spiderLeapTimer = 0;
        spider.spiderWebTimer = 0.72;
        const webState = getSpiderAnimationState(spider);
        spider.spiderWebTimer = 0;
        spider.painTimer = 0.2;
        const damageState = getSpiderAnimationState(spider);
        spider.painTimer = 0;
        spider.dying = true;
        spider.deathTimer = spiderDeathAnimationDuration;
        spider.deathAnimationDuration = spiderDeathAnimationDuration;
        const deathState = getSpiderAnimationState(spider);
        spider.deathTimer = spiderDeathAnimationDuration * 0.1;
        const explosionState = getSpiderAnimationState(spider);
        const expectedFrameCounts = {
            walkRight: 6,
            walkLeft: 6,
            idle: 5,
            prepareJump: 5,
            jump: 5,
            webAttack: 4,
            takeDamage: 5,
            dying: 6,
            deathExplosion: 6,
            webEffects: 5,
            webProjectile: 1,
            webImpact: 1
        };
        const frameCountsMatch = Object.entries(expectedFrameCounts).every(([name, count]) => (
            spiderAnimationFrameMap[name].frames.length === count
        ));

        assert(spiderAnimationSheet.complete
            && spiderAnimationSheet.naturalWidth === 1152
            && spiderAnimationSheet.naturalHeight === 768
            && spiderAnimationSheet.src.endsWith('/assets/spider-animations.png')
            && backgroundIsTransparent
            && frameCountsMatch
            && frames.every(([x, y, width, height]) => (
                x >= 0 && y >= 0 && width > 0 && height > 0
                && x + width <= 1152 && y + height <= 768
            ))
            && cropsStayInsideTheirFrames
            && spiderAnimationFrameMap.walkRight.frames[0][1] === 42
            && spiderAnimationFrameMap.walkLeft.frames[0][0] === 600
            && spiderAnimationFrameMap.idle.frames[0][1] === 184
            && spiderAnimationFrameMap.prepareJump.frames[0][0] === 600
            && spiderAnimationFrameMap.webEffects.frames[0][1] === 624,
        'A folha da aranha ou seus recortes por linha estao incompletos.');
        assert(usesSpiderAnimation(spider)
            && usesSpiderAnimation(createEnemy(4, 4, oreTypes[0], 'sootSpider'))
            && usesSpiderAnimation(createEnemy(4, 4, oreTypes[0], 'matriarch'))
            && walkRightState.name === 'walkRight'
            && walkLeftState.name === 'walkLeft'
            && jumpState.name === 'jump'
            && preparationState.name === 'prepareJump'
            && webState.name === 'webAttack'
            && damageState.name === 'takeDamage'
            && deathState.name === 'dying'
            && explosionState.name === 'deathExplosion'
            && spiderAnimationSpeedMultiplier > 0,
        'Uma animacao de movimento, ataque, dano, morte ou teia nao foi selecionada corretamente.');
    });

    runTest('A aranha de fuligem usa seu sprite proprio sem o fundo quadriculado', () => {
        const frames = Object.values(sootSpiderAnimationFrameMap)
            .flatMap((animation) => animation.frames);
        const croppedFrames = Object.entries(sootSpiderAnimationFrameMap)
            .flatMap(([name, animation]) => animation.frames.map((frame, index) => ({
                frame,
                crop: getAnimationFrameCrop(
                    sootSpiderAnimationSheet,
                    sootSpiderAnimationFrameMap,
                    name,
                    index
                )
            })));
        const cropsStayInsideTheirFrames = croppedFrames.every(({ frame, crop }) => (
            crop.x >= frame[0]
            && crop.x + crop.width <= frame[0] + frame[2]
            && crop.y >= Math.max(0, frame[1] - 12)
            && crop.y + crop.height <= Math.min(
                sootSpiderAnimationSheet.naturalHeight,
                frame[1] + frame[3] + 12
            )
            && crop.offsetX === crop.x - frame[0]
            && crop.offsetY === crop.y - frame[1]
        ));
        const cropsExpandVertically = croppedFrames.some(({ frame, crop }) => (
            crop.y < frame[1] || crop.y + crop.height > frame[1] + frame[3]
        ));
        const eachCellHasItsOwnCrop = Object.entries(matriarchSpiderAnimationFrameMap)
            .every(([name, animation]) => {
                const cellCrops = animation.frames.map((_, index) => {
                    const crop = getAnimationFrameCrop(
                        matriarchSpiderAnimationSheet,
                        matriarchSpiderAnimationFrameMap,
                        name,
                        index
                    );
                    return `${crop.x},${crop.y},${crop.width},${crop.height}`;
                });
                return new Set(cellCrops).size === animation.frames.length;
            });
        const backgroundCanvas = document.createElement('canvas');
        backgroundCanvas.width = 1;
        backgroundCanvas.height = 1;
        const backgroundContext = backgroundCanvas.getContext('2d');
        backgroundContext.drawImage(sootSpiderAnimationSheet, 0, 0);
        const backgroundIsTransparent = backgroundContext.getImageData(0, 0, 1, 1).data[3] <= 16;
        const sootSpider = createEnemy(4, 4, oreTypes[0], 'sootSpider');
        const regularSpider = createEnemy(4, 4, oreTypes[0], 'spider');
        sootSpider.moving = true;
        sootSpider.x = player.x + tileSize * 5;
        sootSpider.y = player.y;
        const runState = getSpiderAnimationState(sootSpider);
        sootSpider.x = player.x;
        const walkState = getSpiderAnimationState(sootSpider);
        sootSpider.moving = false;
        sootSpider.dying = true;
        sootSpider.deathTimer = spiderDeathAnimationDuration;
        sootSpider.deathAnimationDuration = spiderDeathAnimationDuration;
        const deathState = getSpiderAnimationState(sootSpider);
        sootSpider.dying = false;
        sootSpider.spiderWebTimer = 0.01;
        const finalWebFrame = getSpiderAnimationFrameIndex(
            sootSpiderAnimationFrameMap.spitWeb,
            getSpiderAnimationState(sootSpider)
        );

        assert(sootSpiderAnimationSheet.complete
            && sootSpiderAnimationSheet.naturalWidth === 1152
            && sootSpiderAnimationSheet.naturalHeight === 768
            && sootSpiderAnimationSheet.src.endsWith('/assets/soot-spider-animations.png')
            && backgroundIsTransparent
            && sootSpiderAnimationFrameMap.walk.frames.length === 9
            && sootSpiderAnimationFrameMap.run.frames.length === 7
            && sootSpiderAnimationFrameMap.attack.frames.length === 8
            && sootSpiderAnimationFrameMap.jump.frames.length === 8
            && sootSpiderAnimationFrameMap.spitWeb.frames.length === 5
            && sootSpiderAnimationFrameMap.death.frames.length === 8
            && sootSpiderAnimationFrameMap.idle.frames.length === 9
            && sootSpiderAnimationFrameMap.webEffects.frames.length === 3
            && frames.every(([x, y, width, height]) => (
                x >= 0 && y >= 0 && width > 0 && height > 0
                && x + width <= 1152 && y + height <= 768
            ))
            && cropsStayInsideTheirFrames
            && cropsExpandVertically
            && eachCellHasItsOwnCrop
            && matriarchSpiderAnimationFrameMap.webProjectile.frames[0].join(',')
                !== matriarchSpiderAnimationFrameMap.webImpact.frames[0].join(','),
        'A folha da aranha de fuligem ou seus recortes estao incompletos.');
        assert(runState.name === 'run'
            && walkState.name === 'walk'
            && deathState.name === 'death'
            && getSpiderAnimationState(sootSpider).name === 'spitWeb'
            && getSpiderAnimationAssets(sootSpider).spriteSheet === sootSpiderAnimationSheet
            && getSpiderAnimationAssets(sootSpider).frameMap === sootSpiderAnimationFrameMap
            && getSpiderAnimationAssets(regularSpider).spriteSheet === spiderAnimationSheet
            && getSpiderAnimationAssets(regularSpider).frameMap === spiderAnimationFrameMap
            && finalWebFrame === sootSpiderAnimationFrameMap.spitWeb.frames.length - 1,
        'A variante de fuligem nao usa seu sprite ou nao alcança o efeito final da teia.');
    });

    runTest('A Matriarca usa o spritesheet novo sem incluir a arte de referencia', () => {
        const frames = Object.values(matriarchSpiderAnimationFrameMap)
            .flatMap((animation) => animation.frames);
        const croppedFrames = Object.entries(matriarchSpiderAnimationFrameMap)
            .flatMap(([name, animation]) => animation.frames.map((frame, index) => ({
                frame,
                crop: getAnimationFrameCrop(
                    matriarchSpiderAnimationSheet,
                    matriarchSpiderAnimationFrameMap,
                    name,
                    index
                )
            })));
        const cropsStayInsideTheirFrames = croppedFrames.every(({ frame, crop }) => (
            crop.x >= frame[0]
            && crop.x + crop.width <= frame[0] + frame[2]
            && crop.y >= Math.max(0, frame[1] - 12)
            && crop.y + crop.height <= Math.min(
                matriarchSpiderAnimationSheet.naturalHeight,
                frame[1] + frame[3] + 12
            )
        ));
        const cropsExpandVertically = croppedFrames.some(({ frame, crop }) => (
            crop.y < frame[1] || crop.y + crop.height > frame[1] + frame[3]
        ));
        const matriarch = createEnemy(4, 4, oreTypes[0], 'matriarch');
        matriarch.moving = true;
        const walkRight = getSpiderAnimationState(matriarch);
        matriarch.spriteFacingX = -1;
        const walkLeft = getSpiderAnimationState(matriarch);
        matriarch.moving = false;
        matriarch.spiderLeapTimer = 0.6;
        const preparation = getSpiderAnimationState(matriarch);
        matriarch.spiderLeapTimer = 0;
        matriarch.spiderWebTimer = 0.8;
        const webAttack = getSpiderAnimationState(matriarch);
        matriarch.spiderWebTimer = 0;
        matriarch.painTimer = 0.2;
        const damage = getSpiderAnimationState(matriarch);
        matriarch.painTimer = 0;
        matriarch.dying = true;
        matriarch.deathTimer = spiderDeathAnimationDuration;
        matriarch.deathAnimationDuration = spiderDeathAnimationDuration;
        const death = getSpiderAnimationState(matriarch);
        const expectedFrameCounts = {
            walkRight: 5,
            walkLeft: 5,
            idle: 5,
            prepareJump: 5,
            jump: 5,
            webAttack: 4,
            webProjectile: 1,
            webImpact: 1,
            takeDamage: 5,
            dying: 6,
            deathExplosion: 6,
            webEffects: 6
        };
        assert(matriarchSpiderAnimationSheet.complete
            && matriarchSpiderAnimationSheet.naturalWidth === 1152
            && matriarchSpiderAnimationSheet.naturalHeight === 768
            && matriarchSpiderAnimationSheet.src.endsWith('/assets/matriarch-spider-animations.png')
            && frames.every(([x, y, width, height]) => (
                x >= 0 && y >= 0 && width > 0 && height > 0
                && x + width <= 1152 && y + height <= 768
            ))
            && Object.entries(expectedFrameCounts).every(([name, count]) => (
                matriarchSpiderAnimationFrameMap[name].frames.length === count
            ))
            && cropsStayInsideTheirFrames
            && cropsExpandVertically,
        'O spritesheet da Matriarca ou seus recortes por linha estao incompletos.');
        assert(getSpiderAnimationAssets(matriarch).spriteSheet === matriarchSpiderAnimationSheet
            && getSpiderAnimationAssets(matriarch).frameMap === matriarchSpiderAnimationFrameMap
            && walkRight.name === 'walkRight'
            && walkLeft.name === 'walkLeft'
            && preparation.name === 'prepareJump'
            && webAttack.name === 'webAttack'
            && damage.name === 'takeDamage'
            && death.name === 'dying',
        'A Matriarca nao selecionou corretamente seus estados de animacao.');
    });

    runTest('O goblin pode esquivar com agachamento e cooldown', () => {
        const previousRandom = Math.random;
        const previousSusano = player.susanoActive;
        try {
            player.susanoActive = false;
            Math.random = () => 0.1;
            const goblin = createEnemy(4, 4, oreTypes[0], 'goblin');
            goblin.armorDurability = 0;
            goblin.shieldDurability = 0;
            goblin.facingX = -1;
            goblin.facingY = 0;
            const healthBeforeHit = goblin.health;
            const result = damageEnemy(
                goblin,
                5,
                goblin.x + goblin.size / 2 - 5,
                goblin.y + goblin.size / 2,
                true,
                'sword'
            );
            assert(result.dodged && result.blocked
                && goblin.health === healthBeforeHit
                && goblin.dodgeTimer > 0
                && goblin.dodgeCooldown === 1.5
                && getGoblinAnimationState(goblin).name === 'crouch',
            'A esquiva do goblin nao foi sinalizada, protegida ou animada.');
        } finally {
            Math.random = previousRandom;
            player.susanoActive = previousSusano;
        }
    });

    runTest('Goblin ferido busca e consome uma pocao do chao', () => {
        const previousDrops = itemDrops;
        try {
            const goblin = createEnemy(4, 4, oreTypes[0], 'goblin');
            goblin.maxHealth = 100;
            goblin.health = 20;
            const potion = {
                x: goblin.x + goblin.size / 2,
                y: goblin.y + goblin.size / 2,
                type: 'potion',
                rarity: { potionHeal: 35 }
            };
            itemDrops = [potion];
            assert(moveGoblinTowardPotion(goblin, 0.016)
                && goblin.potionAction === 'interact'
                && getGoblinAnimationState(goblin).name === 'interact'
                && itemDrops.length === 0,
            'O goblin ferido nao pegou a pocao proxima para iniciar o uso.');
            advanceGoblinPotionAction(goblin, 0.28);
            assert(getGoblinAnimationState(goblin).name === 'carryItem',
                'O goblin nao exibiu a animacao de carregar a pocao.');
            advanceGoblinPotionAction(goblin, 0.28);
            assert(getGoblinAnimationState(goblin).name === 'useItem',
                'O goblin nao exibiu a animacao de beber a pocao.');
            advanceGoblinPotionAction(goblin, 0.72);
            assert(goblin.health === 55
                && goblin.potionAction === null
                && getGoblinAnimationState(goblin).name === 'idle',
            'O goblin nao concluiu as animacoes de interacao, carregar e beber a pocao.');
        } finally {
            itemDrops = previousDrops;
        }
    });

    runTest('A queimadura configurada pelo monstruário causa dano gradual', () => {
        const previousEnemies = enemies;
        const previousHealth = player.health;
        const previousDamageCooldown = player.damageCooldown;
        const previousGameState = gameState;
        const previousDevMode = devMode;
        const previousBotMode = botMode;
        const previousRandom = Math.random;
        const previousBurn = {
            timer: player.burnTimer,
            tick: player.burnTickTimer,
            remaining: player.burnDamageRemaining
        };
        try {
            enemies = [];
            devMode = false;
            botMode = false;
            gameState = 'playing';
            player.health = 50;
            player.damageCooldown = 0;
            Math.random = () => 0.99;
            applyCreatureStatus(getCreatureAttackData(
                { creatureType: 'dragon' },
                'fireball'
            ).status);
            assert(player.burnDamageRemaining === 4 && player.burnTimer === 2,
                'A ficha de fogo não aplicou o efeito de queimadura configurado.');
            update(0.5);
            assert(player.health === 49 && player.burnDamageRemaining === 3,
                'A queimadura não causou seu primeiro ponto de dano gradual.');
        } finally {
            Math.random = previousRandom;
            enemies = previousEnemies;
            player.health = previousHealth;
            player.damageCooldown = previousDamageCooldown;
            player.burnTimer = previousBurn.timer;
            player.burnTickTimer = previousBurn.tick;
            player.burnDamageRemaining = previousBurn.remaining;
            gameState = previousGameState;
            devMode = previousDevMode;
            botMode = previousBotMode;
            updateHealthHud();
        }
    });

    runTest('Mordidas tóxicas e fios das aranhas aplicam seus efeitos anunciados', () => {
        const previous = {
            enemies,
            map,
            currentFloor,
            gameState,
            devMode,
            botMode,
            health: player.health,
            damageCooldown: player.damageCooldown,
            poisonTimer: player.poisonTimer,
            poisonTickTimer: player.poisonTickTimer,
            poisonDamageRemaining: player.poisonDamageRemaining,
            webbedTimer: player.webbedTimer,
            random: Math.random,
            creatureBatch: enemyCreatureBatch,
            equipmentBatch: enemyEquipmentBatch
        };
        try {
            Math.random = () => 0.99;
            devMode = false;
            botMode = false;
            gameState = 'playing';
            map = map.map((row) => row.map(() => '.'));
            player.health = 100;
            player.damageCooldown = 0;
            currentFloor = 12;
            const troll = createEnemy(4, 4, oreTypes[0], 'troll');
            troll.x = player.x;
            troll.y = player.y;
            troll.toxicBiteWarning = 0.01;
            enemies = [troll];
            moveEnemy(troll, 0.02);
            assert(player.health < 100 && player.poisonDamageRemaining > 0,
                'A mordida anunciada do troll não causou dano e veneno gradual.');

            for (const [creatureType, floor] of [
                ['spider', 1],
                ['sootSpider', 5],
                ['matriarch', 8]
            ]) {
                currentFloor = floor;
                const spider = createEnemy(4, 4, oreTypes[0], creatureType);
                spider.spiderWebTimer = 0.01;
                spider.spiderWebTarget = {
                    entity: player,
                    x: player.x,
                    y: player.y,
                    size: player.size
                };
                enemies = [spider];
                moveEnemy(spider, 0.02);
                assert(player.webbedTimer > 0,
                    `${creatureDataByType[creatureType].name} não prendeu o alvo com sua teia.`);
            }
        } finally {
            Math.random = previous.random;
            enemies = previous.enemies;
            map = previous.map;
            currentFloor = previous.currentFloor;
            gameState = previous.gameState;
            devMode = previous.devMode;
            botMode = previous.botMode;
            player.health = previous.health;
            player.damageCooldown = previous.damageCooldown;
            player.poisonTimer = previous.poisonTimer;
            player.poisonTickTimer = previous.poisonTickTimer;
            player.poisonDamageRemaining = previous.poisonDamageRemaining;
            player.webbedTimer = previous.webbedTimer;
            enemyCreatureBatch = previous.creatureBatch;
            enemyEquipmentBatch = previous.equipmentBatch;
            updateHealthHud();
        }
    });

    runTest('Os ataques de elite e chefes executam dano, investida e status', () => {
        const previous = {
            enemies,
            map,
            ambientDecorations,
            currentFloor,
            gameState,
            devMode,
            botMode,
            x: player.x,
            y: player.y,
            health: player.health,
            damageCooldown: player.damageCooldown,
            poisonTimer: player.poisonTimer,
            poisonTickTimer: player.poisonTickTimer,
            poisonDamageRemaining: player.poisonDamageRemaining,
            burnTimer: player.burnTimer,
            burnTickTimer: player.burnTickTimer,
            burnDamageRemaining: player.burnDamageRemaining,
            webbedTimer: player.webbedTimer,
            random: Math.random
        };
        try {
            Math.random = () => 0.99;
            devMode = false;
            botMode = false;
            gameState = 'playing';
            map = map.map((row) => row.map(() => '.'));
            ambientDecorations = [];
            player.x = 160;
            player.y = 160;
            const resetTarget = () => {
                player.health = 100;
                player.damageCooldown = 0;
                player.poisonTimer = 0;
                player.poisonTickTimer = 0;
                player.poisonDamageRemaining = 0;
                player.burnTimer = 0;
                player.burnTickTimer = 0;
                player.burnDamageRemaining = 0;
                player.webbedTimer = 0;
            };
            const createFixture = (creatureType, floor, offsetX = 0) => {
                currentFloor = floor;
                const creature = creatureDataByType[creatureType];
                const enemy = isBossCreatureType(creatureType)
                    ? createBoss(4, 4, creatureType)
                    : createEnemy(4, 4, oreTypes[0], creatureType);
                enemy.x = player.x + offsetX;
                enemy.y = player.y;
                enemies = [enemy];
                return enemy;
            };

            resetTarget();
            let enemy = createFixture('goblinRunner', 3, -40);
            enemy.runnerLungeWarning = 0.01;
            enemy.runnerLungeX = 1;
            enemy.runnerLungeY = 0;
            moveEnemy(enemy, 0.02);
            assert(player.health < 100,
                'A investida do goblin corredor não causou dano ao atingir o jogador.');

            for (const [creatureType, floor] of [
                ['spider', 1],
                ['sootSpider', 5],
                ['matriarch', 8]
            ]) {
                resetTarget();
                enemy = createFixture(creatureType, floor);
                enemy.spiderLeapTimer = 0.01;
                enemy.spiderLeapX = 30;
                enemy.spiderLeapY = 0;
                enemy.x = player.x - 35;
                moveEnemy(enemy, 0.02);
                assert(player.health < 100,
                    `${creatureDataByType[creatureType].name} não causou dano com o salto anunciado.`);
            }

            resetTarget();
            enemy = createFixture('ashHound', 12, -40);
            enemy.dogPounceWarning = 0.01;
            enemy.dogPounceX = 1;
            enemy.dogPounceY = 0;
            moveEnemy(enemy, 0.02);
            assert(player.health < 100, 'O salto do Cão de fuligem não causou dano.');

            resetTarget();
            enemy = createFixture('stainedSentinel', 14, -80);
            enemy.sentinelBeamWarning = 0.01;
            enemy.sentinelBeamDirectionX = 1;
            enemy.sentinelBeamDirectionY = 0;
            moveEnemy(enemy, 0.02);
            assert(player.health < 100, 'A lança de luz da Sentinela não causou dano.');

            resetTarget();
            enemy = createFixture('ogre', 12, -40);
            enemy.shoulderBashWarning = 0.01;
            moveEnemy(enemy, 0.02);
            assert(player.health < 100, 'O empurrão de ombro do ogro não atingiu o jogador.');

            resetTarget();
            enemy = createFixture('throneGuardian', 20);
            enemy.veinPulseWarning = 0.01;
            moveEnemy(enemy, 0.02);
            assert(player.health < 100, 'O pulso do Guardião do Trono não atingiu sua área.');

            resetTarget();
            enemy = createFixture('dragon', 5, -60);
            enemy.fireballCooldown = 0;
            updateBossFireballs(0.01);
            for (let frame = 0; frame < 30 && player.burnDamageRemaining === 0; frame += 1) {
                updateBossFireballs(0.1);
            }
            assert(player.health < 100 && player.burnDamageRemaining > 0,
                'A bola de fogo do dragão não atingiu nem incendiou o jogador.');

            resetTarget();
            enemy = createFixture('lavaGolem', 5, -60);
            enemy.phaseTwo = true;
            enemy.lavaCooldown = 5;
            enemy.rockCooldown = 5;
            enemy.eruptionCooldown = 0;
            for (let frame = 0; frame < 20 && player.burnDamageRemaining === 0; frame += 1) {
                updateLavaGolemAttacks(enemy, 0.1);
            }
            assert(player.health < 100 && player.burnDamageRemaining > 0,
                'A erupção da fase II do golem não atingiu nem queimou o jogador.');

            resetTarget();
            enemy = createFixture('grimReaper', 15, -60);
            enemy.scytheCooldown = 0;
            updateGrimReaperAttacks(enemy, 0.01);
            const scytheWarning = enemy.scytheAttack?.timer || 0;
            updateGrimReaperAttacks(enemy, scytheWarning + 0.01);
            updateGrimReaperAttacks(enemy, 0.21);
            assert(player.health < 100, 'A foice do Ceifador não causou dano na área anunciada.');
        } finally {
            Math.random = previous.random;
            enemies = previous.enemies;
            map = previous.map;
            ambientDecorations = previous.ambientDecorations;
            currentFloor = previous.currentFloor;
            gameState = previous.gameState;
            devMode = previous.devMode;
            botMode = previous.botMode;
            player.x = previous.x;
            player.y = previous.y;
            player.health = previous.health;
            player.damageCooldown = previous.damageCooldown;
            player.poisonTimer = previous.poisonTimer;
            player.poisonTickTimer = previous.poisonTickTimer;
            player.poisonDamageRemaining = previous.poisonDamageRemaining;
            player.burnTimer = previous.burnTimer;
            player.burnTickTimer = previous.burnTickTimer;
            player.burnDamageRemaining = previous.burnDamageRemaining;
            player.webbedTimer = previous.webbedTimer;
            updateHealthHud();
        }
    });

    runTest('A pré-geração preserva estado, aleatoriedade e limita o cache a cinco andares', () => {
        const previousFloor = currentFloor;
        const previousMap = map;
        const previousState = captureGeneratedMapState();
        const previousRandom = Math.random;
        const previousCache = new Map(floorMapPrefetchCache);
        const previousScheduled = floorMapPrefetchScheduled;
        const previousGeneration = floorMapPrefetchGeneration;
        try {
            currentFloor = 1;
            floorMapPrefetchCache.clear();
            const randomBeforeGeneration = Math.random;
            assert(preGenerateFloorMap(2), 'O mapa futuro não foi gerado.');
            assert(Math.random === randomBeforeGeneration,
                'A pré-geração substituiu o gerador aleatório do jogo.');
            assert(currentFloor === 1 && map === previousMap
                && Object.keys(previousState).every((key) => (
                    captureGeneratedMapState()[key] === previousState[key]
                )),
            'A pré-geração alterou o estado do andar ativo.');

            const prefetched = floorMapPrefetchCache.get(2);
            assert(prefetched?.map.length === rows
                && prefetched.map.every((row) => row.length === cols),
            'O mapa em cache tem dimensões inválidas.');
            currentFloor = 2;
            map = createMapForCurrentFloor();
            assert(map === prefetched.map
                && doors === prefetched.doors
                && dungeonRooms === prefetched.dungeonRooms
                && startPosition === prefetched.startPosition
                && exitPosition === prefetched.exitPosition
                && ambientShadowZones === prefetched.ambientShadowZones
                && castleColumns === prefetched.castleColumns
                && castleDecorations === prefetched.castleDecorations
                && ambientDecorations === prefetched.ambientDecorations
                && bossArenaBounds === prefetched.bossArenaBounds
                && torches === prefetched.torches
                && sewers === prefetched.sewers
                && barrels === prefetched.barrels
                && chests === prefetched.chests,
            'Consumir o cache não restaurou os metadados completos do mapa.');
            assert(!floorMapPrefetchCache.has(2),
                'O mapa consumido permaneceu no cache.');

            for (let floor = 1; floor <= 10; floor += 1) {
                floorMapPrefetchCache.set(floor, {});
            }
            pruneFloorMapPrefetchCache();
            assert(floorMapPrefetchCache.size === 5
                && [...floorMapPrefetchCache.keys()].every((floor) => floor >= 3 && floor <= 7),
            'O cache não foi podado para os cinco próximos andares.');
        } finally {
            currentFloor = previousFloor;
            map = previousMap;
            restoreGeneratedMapState(previousState);
            Math.random = previousRandom;
            floorMapPrefetchCache.clear();
            for (const [floor, prefetched] of previousCache) {
                floorMapPrefetchCache.set(floor, prefetched);
            }
            floorMapPrefetchScheduled = previousScheduled;
            floorMapPrefetchGeneration = previousGeneration;
        }
    });

    runTest('O cache visual pré-renderizado é adotado ao entrar no próximo andar', () => {
        const previousFloor = currentFloor;
        const previousMap = map;
        const previousState = captureGeneratedMapState();
        const previousCache = new Map(floorMapPrefetchCache);
        const previousBaseCanvas = mapBaseCanvas;
        const previousBaseCanvasMap = mapBaseCanvasMap;
        const previousBaseCanvasFloor = mapBaseCanvasFloor;
        const previousPrefetchedCanvas = prefetchedMapBaseCanvas;
        const previousPrefetchedMap = prefetchedMapBaseMap;
        const previousPrefetchedFloor = prefetchedMapBaseFloor;
        try {
            currentFloor = 1;
            floorMapPrefetchCache.clear();
            assert(preGenerateFloorMap(2),
                'Não foi possível gerar o mapa para preparar o cache visual.');
            assert(renderPrefetchedFloorBase(2),
                'O cache visual do próximo andar não foi renderizado.');
            const preparedCanvas = prefetchedMapBaseCanvas;
            const preparedMap = floorMapPrefetchCache.get(2).map;
            assert(preparedCanvas?.width === gridWidth * renderPixelScale
                && preparedCanvas.height === gridHeight * renderPixelScale,
            'O cache visual foi criado com dimensões inválidas.');

            currentFloor = 2;
            map = createMapForCurrentFloor();
            ensureMapBaseCanvas();
            assert(map === preparedMap && mapBaseCanvas === preparedCanvas
                && mapBaseCanvasMap === preparedMap && mapBaseCanvasFloor === 2,
            'O andar entrou sem adotar o canvas que já estava preparado.');
        } finally {
            if (mapBaseCanvas && mapBaseCanvas !== previousBaseCanvas) {
                mapBaseCanvas.width = 0;
                mapBaseCanvas.height = 0;
            }
            if (prefetchedMapBaseCanvas
                && prefetchedMapBaseCanvas !== previousPrefetchedCanvas) {
                prefetchedMapBaseCanvas.width = 0;
                prefetchedMapBaseCanvas.height = 0;
            }
            currentFloor = previousFloor;
            map = previousMap;
            restoreGeneratedMapState(previousState);
            floorMapPrefetchCache.clear();
            for (const [floor, prefetched] of previousCache) {
                floorMapPrefetchCache.set(floor, prefetched);
            }
            mapBaseCanvas = previousBaseCanvas;
            mapBaseCanvasMap = previousBaseCanvasMap;
            mapBaseCanvasFloor = previousBaseCanvasFloor;
            prefetchedMapBaseCanvas = previousPrefetchedCanvas;
            prefetchedMapBaseMap = previousPrefetchedMap;
            prefetchedMapBaseFloor = previousPrefetchedFloor;
        }
    });

    runTest('A busca de rota inimiga usa BFS sem efeitos colaterais em vizinhos bloqueados', () => {
        const previousMap = map;
        const previousBarrels = barrels;
        const previousChests = chests;
        const previousSound = playCreatureSound;
        let warningSounds = 0;
        try {
            map = Array.from({ length: rows }, () => Array(cols).fill('#'));
            for (let col = 2; col <= 10; col += 1) map[2][col] = '.';
            for (let row = 2; row <= 10; row += 1) map[row][10] = '.';
            barrels = [];
            chests = [];
            window.playCreatureSound = () => {
                warningSounds += 1;
            };
            const direction = findEnemyPathDirection(
                { x: 2 * tileSize, y: 2 * tileSize, size: tileSize },
                10.5 * tileSize,
                10.5 * tileSize
            );
            assert(direction.x === 1 && direction.y === 0,
                'A busca não escolheu a primeira célula livre do caminho.');
            assert(warningSounds === 0,
                'A busca de rota tocou sons por avaliar vizinhos bloqueados.');
        } finally {
            map = previousMap;
            barrels = previousBarrels;
            chests = previousChests;
            window.playCreatureSound = previousSound;
        }
    });

    runTest('Os 20 perfis visuais acompanham os títulos sem alterar o mapa', () => {
        const previousFloor = currentFloor;
        const mapBefore = map.map((row) => row.join('')).join('\n');
        const doorPositionsBefore = doors.map((door) => `${door.x},${door.y}`).join('|');
        const pointsBefore = `${startPosition.x},${startPosition.y};${exitPosition.x},${exitPosition.y}`;
        const floorTints = new Set();
        try {
            for (let floor = 1; floor <= finalFloor; floor += 1) {
                currentFloor = floor;
                const environment = getFloorVisualEnvironment();
                const expectedRegion = floor <= 4 ? 'mine'
                    : floor <= 9 ? 'cistern'
                        : floor <= 14 ? 'castle'
                            : floor <= 17 ? 'arcane' : 'corrupted';
                assert(environment.floor === floorVisualTitles[floor - 1]
                    && environment.region === expectedRegion
                    && environment.floorTint !== environment.wallTint
                    && environment.torchRadius > 0
                    && environment.waterShades.length === 3,
                `O perfil visual do andar ${floor} não corresponde à sua faixa temática.`);
                floorTints.add(environment.floorTint);
            }
            assert(floorTints.size === finalFloor,
                'Dois andares receberam a mesma tonalidade de piso.');
            assert(map.map((row) => row.join('')).join('\n') === mapBefore
                && doors.map((door) => `${door.x},${door.y}`).join('|') === doorPositionsBefore
                && `${startPosition.x},${startPosition.y};${exitPosition.x},${exitPosition.y}` === pointsBefore,
            'A seleção de temas visuais alterou o layout ou objetos de gameplay.');
        } finally {
            currentFloor = previousFloor;
        }
    });

    runTest('Os props das minas usam sprites transparentes com escala adequada', () => {
        const expectedSprites = {
            mineSupport: 'mine-support.png',
            mineCart: 'mine-cart.png',
            minePickaxe: 'mine-pickaxe.png',
            mineShovel: 'mine-shovel.png',
            mineLantern: 'mine-lantern.png',
            minePuddle: 'mine-puddle.png',
            mineRubble: 'mine-rubble.png',
            mineWeb: 'mine-web.png'
        };
        assert(Object.keys(expectedSprites).every((type) => (
            ambientDecorationSprites.has(type)
        )),
            'A coleção de sprites das minas está incompleta.');
        for (const [type, fileName] of Object.entries(expectedSprites)) {
            const sprite = ambientDecorationSprites.get(type);
            const footprint = getAmbientDecorationFootprint(type);
            assert(sprite?.src.endsWith(`/assets/environmental/${fileName}`)
                && footprint.width >= 1 && footprint.width <= 3
                && footprint.height >= 1 && footprint.height <= 3,
            `O sprite ou a escala em blocos de ${type} está incorreto.`);
        }
        assert(getAmbientDecorationFootprint('mineLantern').width === 1
            && getAmbientDecorationFootprint('mineLantern').height === 1,
        'A lanterna da mina deve ocupar exatamente um bloco.');
        const generatedMineTypes = getAmbientDecorationTypes(1).slice().sort();
        const expectedMineTypes = Object.keys(expectedSprites).sort();
        assert(generatedMineTypes.length === expectedMineTypes.length
            && expectedMineTypes.every((type, index) => type === generatedMineTypes[index]),
        'A lista de props das minas contém tipos ausentes ou inesperados.');
    });

    runTest('Os props das cisternas usam sprites transparentes com escala adequada', () => {
        const expectedSprites = {
            cisternPipe: 'cistern-pipe.png',
            cisternGrate: 'cistern-grate.png',
            cisternVent: 'cistern-vent.png',
            cisternSoot: 'cistern-soot.png'
        };
        for (const [type, fileName] of Object.entries(expectedSprites)) {
            const sprite = ambientDecorationSprites.get(type);
            const footprint = getAmbientDecorationFootprint(type);
            assert(sprite?.src.endsWith(`/assets/environmental/${fileName}`)
                && footprint.width >= 1 && footprint.width <= 3
                && footprint.height >= 1 && footprint.height <= 3,
            `O sprite ou a escala em blocos de ${type} está incorreto.`);
        }
        assert(getAmbientDecorationTypes(5).length === Object.keys(expectedSprites).length
            && !getAmbientDecorationTypes(5).includes('cisternCrack')
            && !ambientDecorationSprites.has('cisternCrack'),
        'A rachadura de lava ainda está registrada como prop ambiental.');
        let floorCrackFound = false;
        for (let row = 0; row < 100 && !floorCrackFound; row++) {
            for (let col = 0; col < 100; col++) {
                if (shouldDrawBrokenLavaFloorTile(col, row, 5)) {
                    floorCrackFound = true;
                    assert(shouldDrawBrokenLavaFloorTile(col, row, 5)
                        && !shouldDrawBrokenLavaFloorTile(col, row, 4)
                        && !shouldDrawBrokenLavaFloorTile(col, row, 10),
                    'O detalhe de tijolo rachado não é determinístico ou saiu da região das cisternas.');
                    break;
                }
            }
        }
        assert(floorCrackFound,
            'Nenhuma variação de piso rachado com lava foi selecionada para as cisternas.');
    });

    runTest('Props colidem com paredes e itens; só os carrinhos bloqueiam o jogador', () => {
        const previousFloor = currentFloor;
        const previousMap = map;
        const previousState = captureGeneratedMapState();
        const previousPlayerPosition = { x: player.x, y: player.y };
        const previousDevMode = devMode;
        try {
            currentFloor = 5;
            map = Array.from({ length: rows }, () => Array(cols).fill('.'));
            doors = [];
            torches = [];
            sewers = [];
            barrels = [];
            chests = [];
            castleColumns = [];
            castleDecorations = [];
            const solidTypes = new Set([
                'mineSupport', 'mineCart', 'minePickaxe', 'mineShovel',
                'mineLantern', 'mineRubble', 'cisternPipe', 'cisternVent'
            ]);
            for (const decoration of ambientDecorations) {
                const boxes = getAmbientDecorationCollisionBoxes(decoration);
                assert(solidTypes.has(decoration.type)
                    ? boxes.length > 0
                    : boxes.length === 0,
                `A hitbox de ${decoration.type} não corresponde à sua função física.`);
                const isolatedDecoration = [decoration];
                ambientDecorations = isolatedDecoration;
                for (const bounds of boxes) {
                    const sampleX = (bounds.left + bounds.right) / 2;
                    const sampleY = (bounds.top + bounds.bottom) / 2;
                    assert(ambientDecorationBlocksBounds(sampleX - 1, sampleY - 1, 2, 2),
                        `A hitbox de ${decoration.type} não bloqueia sobre a silhueta sólida.`);
                }
                ambientDecorations = [];
            }
            const support = {
                type: 'mineSupport',
                x: 10,
                y: 10,
                wallSide: 0,
                widthBlocks: 2,
                heightBlocks: 3
            };
            const supportBox = getAmbientDecorationFootprintBounds(support);
            assert(ambientDecorationPlacementIsClear(support, map),
                'Uma escora isolada não pode ocupar um local livre.');
            const wallColumn = Math.floor(supportBox.left / tileSize);
            const wallRow = Math.floor(supportBox.top / tileSize);
            map[wallRow][wallColumn] = '#';
            assert(!ambientDecorationPlacementIsClear(support, map),
                'A escora foi colocada atravessando uma parede.');
            map[wallRow][wallColumn] = '.';
            ambientDecorations = [{ ...support, x: support.x + 1 }];
            assert(!ambientDecorationPlacementIsClear(support, map),
                'A escora foi colocada sobre outro prop.');
            ambientDecorations = [];
            barrels = [{
                x: Math.floor((supportBox.left + supportBox.right) / 2 / tileSize),
                y: Math.floor((supportBox.top + supportBox.bottom) / 2 / tileSize),
                health: 1
            }];
            assert(!ambientDecorationPlacementIsClear(support, map),
                'A escora foi colocada sobre um barril.');
            barrels = [];
            chests = [{
                x: Math.floor((supportBox.left + supportBox.right) / 2 / tileSize),
                y: Math.floor((supportBox.top + supportBox.bottom) / 2 / tileSize),
                health: 1
            }];
            assert(!ambientDecorationPlacementIsClear(support, map),
                'A escora foi colocada sobre um baú.');
            chests = [];
            barrels = [];
            devMode = false;
            ambientDecorations = [support];
            const [leftPost, rightPost, crossbeam] =
                getAmbientDecorationCollisionBoxes(support);
            const originX = (support.x + 0.5 - support.widthBlocks / 2) * tileSize;
            const originY = support.y * tileSize + 3;
            assert(leftPost.left >= originX
                && leftPost.right <= originX + 0.16 * 2 * tileSize
                && rightPost.left >= originX + 0.84 * 2 * tileSize
                && rightPost.right <= originX + 2 * tileSize
                && crossbeam.left >= originX
                && crossbeam.right <= originX + 2 * tileSize
                && crossbeam.top >= originY + 0.12 * 3 * tileSize
                && crossbeam.bottom <= originY + 0.24 * 3 * tileSize,
            'A hitbox da escora não acompanha os postes e a travessa do sprite.');
            assert(!ambientDecorationBlocksBounds(
                (leftPost.right + rightPost.left) / 2 - 1,
                (leftPost.top + leftPost.bottom) / 2 - 1,
                2,
                2
            ), 'O vão entre os postes da escora ficou bloqueado.');
            const playerX = (leftPost.left + leftPost.right) / 2 - player.size / 2;
            const playerY = (leftPost.top + leftPost.bottom) / 2 - player.size / 2;
            assert(canEntityMoveTo(player, playerX, playerY),
                'A hitbox da escora bloqueou o jogador.');
            assert(!canEntityMoveTo(
                { size: player.size },
                playerX,
                playerY
            ), 'A hitbox da escora deixou passar uma entidade não-jogadora.');
            const mineCart = {
                type: 'mineCart',
                x: 10,
                y: 10,
                orientation: 'horizontal',
                widthBlocks: 2,
                heightBlocks: 2
            };
            const cartBounds = getAmbientDecorationFootprintBounds(mineCart);
            ambientDecorations = [mineCart];
            assert(!canEntityMoveTo(
                player,
                cartBounds.left + 4,
                cartBounds.top + 4
            ), 'O jogador atravessou a hitbox do carrinho de mina.');
        } finally {
            currentFloor = previousFloor;
            map = previousMap;
            restoreGeneratedMapState(previousState);
            player.x = previousPlayerPosition.x;
            player.y = previousPlayerPosition.y;
            devMode = previousDevMode;
        }
    });

    runTest('Atacar carrinhos de mina os destrói e deixa fuligem mineral', () => {
        const previousFloor = currentFloor;
        const previousState = captureGeneratedMapState();
        const previousMap = map;
        const previousGameState = gameState;
        const previousShopOpen = shopOpen;
        const previousSwordEquipped = swordEquipped;
        const previousSpearOwned = spearOwned;
        const previousEnemies = enemies;
        const previousItemDrops = itemDrops;
        const previousCollectedMaterials = collectedMaterials;
        const previousPlayer = { ...player };
        const previousSoot = collectedMaterials.soot || 0;
        try {
            currentFloor = 1;
            gameState = 'playing';
            shopOpen = false;
            swordEquipped = true;
            spearOwned = true;
            map = Array.from({ length: rows }, () => Array(cols).fill('.'));
            doors = [];
            barrels = [];
            chests = [];
            enemies = [];
            itemDrops = [];
            collectedMaterials = { ...collectedMaterials };

            for (const weapon of ['sword', 'spear']) {
                const cart = {
                    type: 'mineCart',
                    x: 10,
                    y: 10,
                    orientation: 'horizontal',
                    widthBlocks: 2,
                    heightBlocks: 2
                };
                ambientDecorations = [cart];
                player.x = 143;
                player.y = 170;
                player.facingX = 1;
                player.facingY = 0;
                player.attackCooldown = 0;
                player.spearCooldown = 0;
                player.dashActive = false;
                itemDrops = [];

                if (weapon === 'sword') attackWithSword();
                else attackWithSpear();

                assert(!ambientDecorations.includes(cart)
                    && itemDrops.length === 1
                    && itemDrops[0].type === 'material'
                    && itemDrops[0].materialId === 'soot'
                    && itemDrops[0].quantity === 1,
                `O ataque com ${weapon} não destruiu o carrinho e deixou fuligem mineral.`);
                player.x = 170;
                player.y = 170;
                collectItemDrops();
                assert(collectedMaterials.soot === previousSoot + (weapon === 'sword' ? 1 : 2),
                    `A fuligem mineral do carrinho não foi coletada após o ataque com ${weapon}.`);
            }
        } finally {
            currentFloor = previousFloor;
            restoreGeneratedMapState(previousState);
            map = previousMap;
            gameState = previousGameState;
            shopOpen = previousShopOpen;
            swordEquipped = previousSwordEquipped;
            spearOwned = previousSpearOwned;
            enemies = previousEnemies;
            itemDrops = previousItemDrops;
            collectedMaterials = previousCollectedMaterials;
            Object.assign(player, previousPlayer);
            updateMaterialInventoryHud();
        }
    });

    runTest('Os layouts do castelo são repetíveis, conectados e não repetem arquétipos', () => {
        const seeds = [1, 12345, 'castelo-exemplo'];
        const expectedArchetypes = new Set([
            'horizontal', 'vertical', 'lShape', 'centralHall'
        ]);
        const isConnected = (layout) => {
            const queue = [layout.start];
            const visited = new Set([`${layout.start.x},${layout.start.y}`]);
            for (let index = 0; index < queue.length; index += 1) {
                const point = queue[index];
                for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
                    const x = point.x + dx;
                    const y = point.y + dy;
                    const key = `${x},${y}`;
                    if (layout.grid[y]?.[x] === '.' && !visited.has(key)) {
                        visited.add(key);
                        queue.push({ x, y });
                    }
                }
            }
            return visited.has(`${layout.exit.x},${layout.exit.y}`);
        };
        for (const seed of seeds) {
            const layouts = Array.from({ length: 11 }, (_, index) => (
                generateCastleFloor(index + 10, seed)
            ));
            assert(layouts.every((layout, index) => (
                layout.grid.length === rows
                && layout.grid.every((row) => row.length === cols)
                && layout.rooms.length > 0
                && layout.doors.length > 0
                && layout.layers.floor.length === rows
                && layout.layers.walls.length === rows
                && layout.start && layout.exit
                && isConnected(layout)
                && (index === 0 || layout.archetype !== layouts[index - 1].archetype)
            )), `Uma seed gerou layout inválido ou arquétipos repetidos (${seed}).`);
            assert(layouts[layouts.length - 1].archetype === 'centralHall'
                && [10, 15, 20].every((floor) => (
                    layouts[floor - 10].archetype === 'centralHall'
                    && layouts[floor - 10].arena
                )),
            `Um andar de chefe não usou o grande salão central (${seed}).`);
            assert(layouts.every((layout) => (
                Number.isInteger(layout.corridorWidth)
                && layout.corridorWidth >= 3 && layout.corridorWidth <= 5
                && layout.rooms.every((room) => (
                    room.x >= 0 && room.y >= 0
                    && room.x + room.width <= cols
                    && room.y + room.height <= rows
                ))
                && layout.rooms
                    .filter((room) => !room.isStair && room.role !== 'hall')
                    .every((room) => room.width >= 13 && room.width * room.height >= 100)
                && (layout.archetype === 'centralHall'
                    ? layout.rooms.some((room) => (
                        room.role === 'hall' && room.width >= 24 && room.height >= 15
                    ))
                    : layout.rooms
                        .filter((room) => !room.isStair && room.role !== 'hall')
                        .every((room) => room.width * room.height >= 145))
            )), `Uma sala ou corredor excedeu os limites configurados (${seed}).`);
            assert(JSON.stringify(generateCastleFloor(12, seed))
                === JSON.stringify(generateCastleFloor(12, seed)),
            `A mesma seed não reproduziu o andar 12 (${seed}).`);
            assert(layouts.some((layout) => layout.spawns.some((spawn) => (
                spawn.profile === 'corridor-ambush'
                    || spawn.profile === 'hall-group'
                    || spawn.profile === 'room-guard'
            ))), `Os layouts não reservaram posições de surgimento (${seed}).`);
        }
        assert(Object.keys(castleLayoutConfig.archetypeWeights).length
            === expectedArchetypes.size
            && expectedArchetypes.has('centralHall')
            && castleLayoutConfig.roomWidth[0] >= 13
            && castleLayoutConfig.roomHeight[0] >= 11
            && castleLayoutConfig.hallWidth[0] >= 24
            && castleLayoutConfig.hallHeight[0] >= 15,
        'Os pesos dos quatro arquétipos não estão configurados.');
    });

    runTest('Os 20 mapas têm saída e inimigos alcançáveis', () => {
        for (let floor = 1; floor <= finalFloor; floor += 1) {
            currentFloor = floor;
            resetGame();
            assert(map.length === rows && map.every((row) => row.length === cols),
                `Dimensões inválidas no andar ${floor}.`);
            assert(ambientDecorations
                .filter((decoration) => decoration.type === 'mineCart')
                .every((decoration) => getAmbientDecorationRoomAt(
                    decoration.x,
                    decoration.y
                )),
            `Um carrinho de mina bloqueou um corredor no andar ${floor}.`);
            if (activeFloorEncounterId) {
                const participants = enemies.filter((enemy) => (
                    enemy.encounterId === activeFloorEncounterId
                ));
                const anchor = participants[0];
                assert(participants.every((enemy) => (
                    Math.hypot(
                        enemy.x + enemy.size / 2 - (anchor.x + anchor.size / 2),
                        enemy.y + enemy.size / 2 - (anchor.y + anchor.size / 2)
                    ) <= tileSize * 3
                )), `Os participantes do encontro do andar ${floor} não surgiram juntos.`);
            }
            if (floor >= 10 && !activeFloorEncounterId) {
                const ordinaryEnemies = enemies.filter((enemy) => !enemy.isBoss);
                for (let first = 0; first < ordinaryEnemies.length; first += 1) {
                    for (let second = first + 1; second < ordinaryEnemies.length; second += 1) {
                        const firstX = Math.floor(
                            (ordinaryEnemies[first].x + ordinaryEnemies[first].size / 2)
                            / tileSize
                        );
                        const firstY = Math.floor(
                            (ordinaryEnemies[first].y + ordinaryEnemies[first].size / 2)
                            / tileSize
                        );
                        const secondX = Math.floor(
                            (ordinaryEnemies[second].x + ordinaryEnemies[second].size / 2)
                            / tileSize
                        );
                        const secondY = Math.floor(
                            (ordinaryEnemies[second].y + ordinaryEnemies[second].size / 2)
                            / tileSize
                        );
                        const distance = Math.abs(
                            firstX - secondX
                        ) + Math.abs(firstY - secondY);
                        assert(distance >= 4,
                            `Inimigos comuns ficaram amontoados no andar ${floor}.`);
                    }
                }
            }
            if (floor === 3) {
                const encounterEnemies = enemies.filter((enemy) => (
                    enemy.encounterId === activeFloorEncounterId
                ));
                assert(activeFloorEncounterId === 'crossed-hunt'
                    && !activeFloorEncounterStarted
                    && !raceWarActive
                    && activeFloorEncounterBounds
                    && encounterEnemies.map((enemy) => enemy.creatureType).join(',')
                        === 'goblin,goblinRunner,spider,spider,spider'
                    && enemies.length === floorKillGoal,
                'A caçada atravessada não iniciou com a composição prevista.');
                const outsideRoom = findOpenTiles().find((tile) => (
                    tile.x < activeFloorEncounterBounds.left
                    || tile.x > activeFloorEncounterBounds.right
                    || tile.y < activeFloorEncounterBounds.top
                    || tile.y > activeFloorEncounterBounds.bottom
                ));
                const previousPlayerPosition = { x: player.x, y: player.y };
                const previousNotification = {
                    hidden: floorEventNotification.hidden,
                    title: floorEventNotificationTitle.textContent,
                    summary: floorEventNotificationSummary.textContent
                };
                try {
                    player.x = outsideRoom.x * tileSize + (tileSize - player.size) / 2;
                    player.y = outsideRoom.y * tileSize + (tileSize - player.size) / 2;
                    assert(!isPlayerInsideFloorEncounterRoom()
                        && !tryActivateFloorEncounter()
                        && !raceWarActive,
                    'O encontro iniciou antes de o jogador entrar na sala.');
                    player.x = activeFloorEncounterBounds.left * tileSize
                        + (tileSize - player.size) / 2;
                    player.y = activeFloorEncounterBounds.top * tileSize
                        + (tileSize - player.size) / 2;
                    assert(tryActivateFloorEncounter()
                        && activeFloorEncounterStarted
                        && raceWarActive
                        && !floorEventNotification.hidden
                        && floorEventNotificationTitle.textContent === bestiaryEvents[0].title
                        && floorEventNotificationSummary.textContent === bestiaryEvents[0].summary,
                    'Entrar na sala não iniciou o evento e sua notificação.');
                } finally {
                    player.x = previousPlayerPosition.x;
                    player.y = previousPlayerPosition.y;
                    activeFloorEncounterStarted = false;
                    raceWarActive = false;
                    clearTimeout(floorEventNotificationTimer);
                    floorEventNotification.hidden = previousNotification.hidden;
                    floorEventNotificationTitle.textContent = previousNotification.title;
                    floorEventNotificationSummary.textContent = previousNotification.summary;
                }
            }
            if (floor === 8) {
                const nestBounds = matriarchArena?.bounds;
                const secret = secretRooms.find((room) => room.id === 'matriarch-old-nest');
                const reachable = getReachableFloorTileKeys();
                const playerTile = {
                    x: Math.floor((player.x + player.size / 2) / tileSize),
                    y: Math.floor((player.y + player.size / 2) / tileSize)
                };
                assert(enemies.filter((enemy) => !enemy.isMiniBoss).length === floorKillGoal
                    && enemies.filter((enemy) => enemy.isMiniBoss).length === 1
                    && nestBounds?.width === 18
                    && nestBounds.height === 12
                    && matriarchArena.tunnels.length >= 2
                    && matriarchArena.pillars.length >= 4
                    && matriarchArena.campfire
                    && floorNpcs.some((npc) => npc.id === 'lia')
                    && secret
                    && secret.definition.bounds.width === 10
                    && secret.definition.bounds.height === 8
                    && secret.definition.trigger.type === 'destroy-object'
                    && secret.state.opened === false
                    && map[secret.definition.gate.y][secret.definition.gate.x] === '#'
                    && (playerTile.x < nestBounds.x
                        || playerTile.x >= nestBounds.x + nestBounds.width
                        || playerTile.y < nestBounds.y
                        || playerTile.y >= nestBounds.y + nestBounds.height)
                    && (playerTile.x < secret.definition.bounds.x
                        || playerTile.x >= secret.definition.bounds.x + secret.definition.bounds.width
                        || playerTile.y < secret.definition.bounds.y
                        || playerTile.y >= secret.definition.bounds.y + secret.definition.bounds.height)
                    && !reachable.has(`${secret.definition.chest.x},${secret.definition.chest.y}`)
                    && reachable.has(`${matriarchArena.bossTile.x},${matriarchArena.bossTile.y}`)
                    && enemies.filter((enemy) => enemy.creatureType !== 'matriarch').every((enemy) => {
                        const x = Math.floor((enemy.x + enemy.size / 2) / tileSize);
                        const y = Math.floor((enemy.y + enemy.size / 2) / tileSize);
                        return x < nestBounds.x || x >= nestBounds.x + nestBounds.width
                            || y < nestBounds.y || y >= nestBounds.y + nestBounds.height;
                    }),
                'A Matriarca não está disponível como encontro opcional fora da meta.');
            }
            if (floor === 12) {
                assert(activeFloorEncounterId === 'cold-kitchen'
                    && !activeFloorEncounterStarted
                    && !raceWarActive
                    && enemies.filter((enemy) => enemy.encounterId === activeFloorEncounterId)
                        .map((enemy) => enemy.creatureType).join(',')
                        === 'ashHound,troll',
                'A cozinha sem fogo não iniciou o confronto entre cão e troll.');
            }
            if (floor === 16) {
                assert(activeFloorEncounterId === 'pointing-stained-glass'
                    && !activeFloorEncounterStarted
                    && !raceWarActive
                    && enemies.filter((enemy) => enemy.encounterId === activeFloorEncounterId)
                        .map((enemy) => enemy.creatureType).join(',')
                        === 'stainedSentinel,ogre,troll',
                'O encontro do vitral não iniciou com sentinela, ogro e troll.');
                const hiddenRoomReachable = getReachableTiles(startPosition);
                const hiddenGuard = secretMatriarchChamber?.guard;
                assert(hiddenGuard
                    && !secretMatriarchChamber.open
                    && map[secretMatriarchChamber.entrance.y][secretMatriarchChamber.entrance.x] === '#'
                    && !hiddenRoomReachable.has(`${Math.floor((hiddenGuard.x + hiddenGuard.size / 2) / tileSize)},${Math.floor((hiddenGuard.y + hiddenGuard.size / 2) / tileSize)}`),
                'A câmara da Matriarca não começa oculta e inacessível.');
                activeFloorEncounterStarted = true;
                raceWarActive = true;
                for (const enemy of enemies) {
                    if (
                        enemy.encounterId === activeFloorEncounterId
                        && ['ogre', 'troll'].includes(enemy.creatureType)
                    ) {
                        enemy.health = 0;
                    }
                }
                updateRaceWarStatus();
                assert(activeFloorEncounterId === null
                    && itemDrops.some((drop) => (
                        drop.type === 'scroll' && drop.scroll.id === 'conquista'
                    ))
                    && secretMatriarchChamber?.open
                    && map[secretMatriarchChamber.entrance.y][secretMatriarchChamber.entrance.x] === '.'
                    && enemies.includes(secretMatriarchChamber.guard),
                'Concluir a guarda do vitral não revelou a câmara da Matriarca e o Pergaminho da Conquista.');
                const chamberBounds = {
                    left: (secretMatriarchChamber.entrance.x - 2) * tileSize,
                    top: secretMatriarchChamber.entrance.y * tileSize,
                    right: (secretMatriarchChamber.entrance.x + 3) * tileSize,
                    bottom: (secretMatriarchChamber.entrance.y + 5) * tileSize
                };
                assert(ambientDecorations.every((decoration) => {
                    const bounds = getAmbientDecorationFootprintBounds(decoration);
                    return bounds.left >= chamberBounds.right
                        || bounds.right <= chamberBounds.left
                        || bounds.top >= chamberBounds.bottom
                        || bounds.bottom <= chamberBounds.top;
                }), 'A câmara secreta do andar 16 sobrepôs uma decoração ambiental.');
            }
            const reachable = getReachableTiles(startPosition);
            assert(reachable.has(`${exitPosition.x},${exitPosition.y}`),
                `Saída inacessível no andar ${floor}.`);
            const collisionReachable = getReachableFloorTileKeys();
            assert(collisionReachable.has(`${exitPosition.x},${exitPosition.y}`)
                && enemies.every((enemy) => (
                    enemy.secretChamberGuard && !secretMatriarchChamber?.open
                        ? true
                        : collisionReachable.has(
                            `${Math.floor((enemy.x + enemy.size / 2) / tileSize)},${Math.floor((enemy.y + enemy.size / 2) / tileSize)}`
                        )
                )),
            `As hitboxes ambientais bloquearam a rota ou o acesso a um inimigo no andar ${floor}.`);
            assert(ambientDecorations.length > 0
                && ambientDecorations.every((decoration) => (
                    (() => {
                        const wallOffsets = [[0, -1], [1, 0], [0, 1], [-1, 0]];
                        const offset = wallOffsets[decoration.wallSide];
                        const profile = getAmbientDecorationPlacementProfile(decoration.type);
                        const footprint = getAmbientDecorationFootprint(
                            decoration.type,
                            decoration.orientation
                        );
                        const expectedFootprint = decoration.type === 'mineSupport'
                            && decoration.corridorAxis === 'horizontal'
                            ? { width: 1, height: 2 }
                            : footprint;
                        const room = getAmbientDecorationRoomAt(decoration.x, decoration.y);
                        const expectedOrientation = profile.location === 'path'
                            ? getAmbientDecorationPathOrientation(
                                map,
                                decoration.x,
                                decoration.y,
                                room
                            )
                            : 'horizontal';
                        const hasValidAnchor = profile.location === 'wall'
                            ? offset !== undefined
                                && map[decoration.y + offset[1]]?.[decoration.x + offset[0]] === '#'
                            : profile.location === 'corner'
                                ? Boolean(room)
                                    && decoration.wallSide === -1
                                    && Math.min(
                                        Math.abs(decoration.x - (room.x + 2))
                                            + Math.abs(decoration.y - (room.y + 2)),
                                        Math.abs(decoration.x - (room.x + room.width - 3))
                                            + Math.abs(decoration.y - (room.y + 2)),
                                        Math.abs(decoration.x - (room.x + 2))
                                            + Math.abs(decoration.y - (room.y + room.height - 3)),
                                        Math.abs(decoration.x - (room.x + room.width - 3))
                                            + Math.abs(decoration.y - (room.y + room.height - 3))
                                    ) <= 2
                                : profile.location === 'path'
                                    ? decoration.wallSide === -1
                                        && decoration.orientation === expectedOrientation
                                    : decoration.wallSide === -1;
                        const roomRoleIsValid = profile.roomRoles.length === 0
                            || !dungeonRooms.some((entry) => entry.role)
                            || profile.roomRoles.includes(decoration.roomRole);
                        return map[decoration.y]?.[decoration.x] === '.'
                            && ['horizontal', 'vertical'].includes(decoration.orientation)
                            && hasValidAnchor
                            && roomRoleIsValid
                            && decoration.widthBlocks === expectedFootprint.width
                            && decoration.heightBlocks === expectedFootprint.height
                            && decoration.widthBlocks >= 1
                            && decoration.widthBlocks <= 3
                            && decoration.heightBlocks >= 1
                            && decoration.heightBlocks <= 3;
                    })()
                )),
            `As decorações temáticas do andar ${floor} estão ausentes ou fora do piso transitável.`);
            if (floor <= 4) {
                const lanterns = ambientDecorations.filter((decoration) => (
                    decoration.type === 'mineLantern'
                ));
                assert(lanterns.length === 2
                    && new Set(lanterns.map((lantern) => lantern.replacedTorchIndex)).size === 2
                    && lanterns.every((lantern) => lantern.replacedTorch
                        && !torches.some((torch) => (
                            torch.x === lantern.replacedTorch.x
                            && torch.y === lantern.replacedTorch.y
                        ))
                        && map[lantern.replacedTorch.y]?.[lantern.replacedTorch.x] === '#'),
                `As lanternas do andar ${floor} não substituíram duas tochas de parede.`);
                const supports = ambientDecorations.filter((decoration) => (
                    decoration.type === 'mineSupport'
                ));
                const corridors = getAmbientDecorationCorridorCenters(map);
                const supportFitsCorridor = (support, corridor) => {
                    if (
                        support.orientation !== 'horizontal'
                        || support.corridorAxis !== corridor.axis
                        || support.corridorLength !== corridor.length
                        || support.corridorStart !== corridor.start
                        || support.corridorEnd !== corridor.end
                        || support.placementAnchor !== 'corridor'
                    ) return false;
                    const bounds = getAmbientDecorationFootprintBounds(support);
                    if (corridor.axis === 'horizontal') {
                        const firstCol = Math.floor(bounds.left / tileSize);
                        const lastCol = Math.ceil(bounds.right / tileSize) - 1;
                        const topRow = Math.floor(bounds.top / tileSize);
                        const bottomRow = Math.ceil(bounds.bottom / tileSize);
                        const expectedX = support.corridorSupportIndex === 0
                            ? corridor.start
                            : corridor.end;
                        return support.corridorSupportIndex <= 1
                            && support.x === expectedX
                            && support.y === corridor.y
                            && support.widthBlocks === 1
                            && support.heightBlocks === 2
                            && bounds.left === expectedX * tileSize
                            && bounds.right === (expectedX + 1) * tileSize
                            && bounds.top === corridor.y * tileSize
                            && bounds.bottom === (corridor.y + 2) * tileSize
                            && Array.from(
                                { length: lastCol - firstCol + 1 },
                                (_, index) => (
                                    map[topRow - 1]?.[firstCol + index] === '#'
                                    && map[bottomRow]?.[firstCol + index] === '#'
                                )
                            ).every(Boolean);
                    }
                    const firstRow = Math.floor(bounds.top / tileSize);
                    const lastRow = Math.ceil(bounds.bottom / tileSize) - 1;
                    const leftCol = Math.floor(bounds.left / tileSize);
                    const rightCol = Math.ceil(bounds.right / tileSize);
                    return support.corridorSupportIndex === 0
                        && support.x === corridor.x
                        && support.y === corridor.y
                        && support.widthBlocks === 2
                        && support.heightBlocks === 3
                        && bounds.left === support.x * tileSize
                        && bounds.right === (support.x + 2) * tileSize
                        && bounds.top === (support.y - 1) * tileSize
                        && bounds.bottom === (support.y + 2) * tileSize
                        && Array.from(
                            { length: lastRow - firstRow + 1 },
                            (_, index) => (
                                map[firstRow + index]?.[leftCol - 1] === '#'
                                && map[firstRow + index]?.[rightCol] === '#'
                            )
                        ).every(Boolean);
                };
                assert(corridors.length > 0
                    && supports.length === corridors.reduce(
                        (total, corridor) => total + (corridor.axis === 'horizontal' ? 2 : 1),
                        0
                    )
                    && corridors.every((corridor) => {
                        const expectedCount = corridor.axis === 'horizontal' ? 2 : 1;
                        return supports.filter((support) => (
                            supportFitsCorridor(support, corridor)
                        )).length === expectedCount;
                    }),
                `As escoras do andar ${floor} não correspondem à orientação e à quantidade esperadas por corredor.`);
            }
            const propsPerRoom = new Map();
            for (const decoration of ambientDecorations) {
                if (decoration.roomKey === 'corridor') continue;
                propsPerRoom.set(
                    decoration.roomKey,
                    (propsPerRoom.get(decoration.roomKey) || 0) + 1
                );
            }
            assert(Array.from(propsPerRoom.values()).every((count) => count <= 2),
                `Mais de dois props foram distribuídos em uma mesma sala do andar ${floor}.`);
            assert(getAmbientDecorationTypes(floor).every((type) => (
                ambientDecorations.some((decoration) => decoration.type === type)
            )), `Um prop temático do andar ${floor} não encontrou um local adequado.`);
            assert(ambientDecorations.every((decoration) => (
                getAmbientDecorationCollisionBoxes(decoration).every((bounds) => (
                    bounds.left < bounds.right && bounds.top < bounds.bottom
                    && bounds.left >= 0 && bounds.top >= 0
                    && bounds.right <= gridWidth && bounds.bottom <= gridHeight
                ))
            )), `Uma hitbox ambiental do andar ${floor} excedeu os limites do mapa.`);
            assert(ambientDecorations.every((decoration) => (
                ambientDecorationPlacementIsClear(decoration, map)
            )), `Um prop do andar ${floor} sobrepôs parede ou outro item.`);
            const existingDecorations = ambientDecorations;
            const existingTorches = torches;
            ambientDecorations = [];
            torches = [...existingTorches];
            for (const lantern of existingDecorations
                .filter((decoration) => decoration.type === 'mineLantern')
                .sort((first, second) => first.replacedTorchIndex - second.replacedTorchIndex)) {
                torches.splice(lantern.replacedTorchIndex, 0, lantern.replacedTorch);
            }
            const regeneratedDecorations = createAmbientDecorations(map);
            assert(JSON.stringify(regeneratedDecorations) === JSON.stringify(existingDecorations),
                `A geração dos props do andar ${floor} não é determinística.`);
            ambientDecorations = existingDecorations;
            torches = existingTorches;
            for (const enemy of enemies) {
                const col = Math.floor((enemy.x + enemy.size / 2) / tileSize);
                const row = Math.floor((enemy.y + enemy.size / 2) / tileSize);
                const hiddenMatriarch = enemy.secretChamberGuard && !secretMatriarchChamber?.open;
                assert(hiddenMatriarch
                    ? map[secretMatriarchChamber.entrance.y][secretMatriarchChamber.entrance.x] === '#'
                        && !reachable.has(`${col},${row}`)
                    : reachable.has(`${col},${row}`),
                    `Inimigo inacessível no andar ${floor}.`);
            }
            assert(enemies.filter((enemy) => enemy.isBoss).length === (floor % 5 === 0 ? 1 : 0),
                `Quantidade de chefes incorreta no andar ${floor}.`);
        }
    });

    runTest('O jogador inicia cada andar em uma posição aleatória e livre', () => {
        for (let floor = 1; floor <= finalFloor; floor += 1) {
            currentFloor = floor;
            resetGame();
            const col = Math.floor((player.x + player.size / 2) / tileSize);
            const row = Math.floor((player.y + player.size / 2) / tileSize);
            assert(map[row]?.[col] !== '#' && map[row]?.[col] !== 'S',
                `O jogador apareceu em uma parede ou no ponto fixo do andar ${floor}.`);
            assert(canEntityMoveTo(player, player.x, player.y),
                `A posição do jogador está bloqueada no andar ${floor}.`);
            assert(enemies.every((enemy) => (
                enemy.health <= 0
                || enemy.dying
                || !collisionBoundsOverlap(player, enemy)
            )), `O jogador apareceu sobre um inimigo no andar ${floor}.`);
        }
    });

    runTest('A barra de vida visível do jogador acompanha a vida atual', () => {
        const previousHealth = player.health;
        const previousMaxHealth = player.maxHealth;
        try {
            player.maxHealth = 100;
            player.health = 75;
            assert(getPlayerHealthBarRatio() === 0.75,
                'A barra não representa corretamente 75% de vida.');
            player.health = 0;
            assert(getPlayerHealthBarRatio() === 0,
                'A barra não esvazia quando a vida chega a zero.');
            player.health = 125;
            assert(getPlayerHealthBarRatio() === 1,
                'A barra ultrapassa a vida máxima.');
        } finally {
            player.health = previousHealth;
            player.maxHealth = previousMaxHealth;
        }
    });

    runTest('Selecionar itens exibe detalhes no inventário e na loja', () => {
        const previousInventoryTitle = inventoryItemTitle.textContent;
        const previousInventoryDescription = inventoryItemDescription.textContent;
        const previousShopTitle = shopItemTitle.textContent;
        const previousShopDescription = shopItemDescription.textContent;
        try {
            showInventoryItemInformation(swordSlot);
            assert(inventoryItemTitle.textContent === 'Espada'
                && inventoryItemDescription.textContent.includes('dano'),
            'Selecionar a espada não mostrou seus detalhes no inventário.');
            showShopItemInformation('potion');
            assert(shopItemTitle.textContent.includes('Poção')
                && shopItemDescription.textContent.includes('35 pontos de vida')
                && shopItemDescription.textContent.includes('Preço'),
            'Selecionar a poção não mostrou efeito e preço na loja.');
        } finally {
            inventoryItemTitle.textContent = previousInventoryTitle;
            inventoryItemDescription.textContent = previousInventoryDescription;
            shopItemTitle.textContent = previousShopTitle;
            shopItemDescription.textContent = previousShopDescription;
        }
    });

    runTest('Todos os chefes recuperam a vida e aceleram os ataques na fase II', () => {
        const cooldowns = {
            dragon: { fireball: 0.55, warning: 0.4 },
            lavaGolem: { lava: 0.8, rock: 0.8, poolWarning: 0.45, rockWarning: 0.4 },
            grimReaper: { scythe: 0.65, warning: 0.78 }
        };
        for (const bossType of Object.keys(cooldowns)) {
            const boss = {
                isBoss: true,
                bossType,
                phaseTwo: false,
                health: 50,
                maxHealth: 100,
                displayHealth: 45,
                attackCooldown: 2,
                fireballCooldown: 2,
                fireballTarget: { x: 0, y: 0 },
                fireballWarning: 0.55,
                lavaCooldown: 4.2,
                rockCooldown: 3.2,
                lavaPools: [{ warning: 0.65 }],
                thrownRocks: [{ phase: 'warning', warning: 0.55 }],
                scytheCooldown: 2.8,
                scytheAttack: { phase: 'warning', timer: 0.78 },
                attackTimer: 0.78
            };
            assert(!enterBossPhaseTwo(boss) && boss.health === 50,
                `${bossType} entrou na fase II antes de morrer na fase I.`);
            boss.health = 0;
            resolveEnemyDefeat(boss);
            assert(boss.phaseTwo && boss.health === boss.maxHealth
                && boss.displayHealth === boss.maxHealth
                && !boss.defeatResolved,
            `${bossType} não restaurou a vida ao morrer na fase I.`);
            assert(boss.attackCooldown <= 0.65,
                `${bossType} não encurtou o intervalo de ataque comum.`);
            if (bossType === 'dragon') {
                assert(boss.fireballCooldown <= cooldowns.dragon.fireball
                    && boss.fireballWarning <= cooldowns.dragon.warning,
                'O dragão não acelerou a bola de fogo e seu aviso.');
            } else if (bossType === 'lavaGolem') {
                assert(boss.lavaCooldown <= cooldowns.lavaGolem.lava
                    && boss.rockCooldown <= cooldowns.lavaGolem.rock
                    && boss.lavaPools[0].warning <= cooldowns.lavaGolem.poolWarning
                    && boss.thrownRocks[0].warning <= cooldowns.lavaGolem.rockWarning,
                'O golem não acelerou os intervalos e avisos dos ataques.');
            } else {
                assert(boss.scytheCooldown <= cooldowns.grimReaper.scythe
                    && boss.scytheAttack.timer <= cooldowns.grimReaper.warning
                    && boss.attackTimer <= cooldowns.grimReaper.warning
                    && boss.scytheAttack.timer >= creatureDataByType.grimReaper.attacks[0].warning
                        * GAME_BALANCE.bosses.reaperPhaseTwoWarningMultiplier,
                'O Ceifador acelerou a foice sem preservar um aviso visual suficiente.');
            }
            boss.health = 40;
            assert(!enterBossPhaseTwo(boss) && boss.health === 40,
                `${bossType} restaurou a vida mais de uma vez.`);
        }
    });

    runTest('Inimigos que testemunham ataques perseguem ou tentam se esconder', () => {
        const previousMap = map;
        const previousEnemies = enemies;
        const previousBarrels = barrels;
        const previousChests = chests;
        const previousPlayerPosition = { x: player.x, y: player.y };
        const previousRandom = Math.random;
        const target = {
            x: tileSize * 5,
            y: tileSize * 4,
            size: 12,
            collisionWidth: 10,
            collisionHeight: 10,
            health: 20,
            dying: false
        };
        const witness = {
            x: tileSize * 4,
            y: tileSize * 6,
            size: 12,
            collisionWidth: 10,
            collisionHeight: 10,
            health: 20,
            dying: false,
            attackCooldown: 2,
            combatAlertTimer: 0,
            fleeHideTarget: null,
            fleeHideTimer: 0,
            fleeHideCooldown: 0,
            alertedTarget: null,
            alertTimer: 0
        };

        try {
            map = Array.from({ length: rows }, () => '.'.repeat(cols));
            player.x = tileSize * 4;
            player.y = tileSize * 4;
            enemies = [target, witness];
            barrels = [{ x: 6, y: 6, health: 20 }];
            chests = [];

            Math.random = () => 0.5;
            alertEnemiesToPlayerAttack(target);
            assert(witness.combatAlertTimer === 8
                && witness.alertedTarget.x === player.x + player.size / 2
                && witness.attackCooldown === 0.3,
            'A testemunha não ficou mais agressiva nem passou a perseguir o jogador.');

            witness.combatAlertTimer = 0;
            witness.alertTimer = 0;
            witness.alertedTarget = null;
            witness.attackCooldown = 2;
            Math.random = () => 0;
            alertEnemiesToPlayerAttack(target);
            const hideDirection = witness.fleeHideTarget
                ? findEnemyPathDirection(
                    witness,
                    witness.fleeHideTarget.x,
                    witness.fleeHideTarget.y
                )
                : { x: 0, y: 0 };
            assert(witness.fleeHideTarget && Math.hypot(hideDirection.x, hideDirection.y) > 0,
            'A testemunha não escolheu um esconderijo alcançável ao lado de um barril.');
        } finally {
            Math.random = previousRandom;
            map = previousMap;
            enemies = previousEnemies;
            barrels = previousBarrels;
            chests = previousChests;
            player.x = previousPlayerPosition.x;
            player.y = previousPlayerPosition.y;
        }
    });

    runTest('A pose inicial parada do ataque fica maior que os demais quadros', () => {
        assert(Math.abs(getPlayerAttackSpriteScale('man', 0) - 1.3225) < 0.0001
            && Math.abs(getPlayerAttackSpriteScale('woman', 0) - 1.3225) < 0.0001,
        'A pose inicial parada não recebeu o aumento adicional.');
        assert(Math.abs(getPlayerAttackSpriteScale('man', 3) - 1.15) < 0.0001
            && Math.abs(getPlayerAttackSpriteScale('woman', 1) - 1.15) < 0.0001,
        'Os demais quadros não mantiveram apenas o aumento-base de 15%.');
    });

    runTest('O relatório mede dificuldade por vida proporcional e não esconde andares críticos', () => {
        const ratios = { 8: 0.82, 10: 0.22, 17: 0.01, 20: 0.30 };
        assert(Math.abs(getBotAverageFloorDamagePercent(ratios, finalFloor) - 6.75) < 0.001,
            'A média não usou a proporção de vida perdida em cada andar.');
        assert(getBotHighDamageFloors(ratios).join(',') === '8,20',
            'Os andares com dano alto não foram identificados para preparação.');
        assert(getBotHighDamageFloorAdvice(ratios)
            === 'Reforce poções, armadura e escudo antes dos andares 8, 20, onde o dano proporcional foi alto.',
        'A recomendação não incluiu todos os andares de dano alto.');
        assert(getBotDifficultyRating(6.75, 0.82) === 'Muito alta',
            'A avaliação ocultou o dano crítico concentrado em um andar.');
    });

    runTest('A exploração escolhe a sala não visitada mais próxima', () => {
        const originalRooms = dungeonRooms;
        try {
            dungeonRooms = [
                { x: 0, y: 0, width: 2, height: 2 },
                { x: 20, y: 20, width: 2, height: 2 },
                { x: 4, y: 0, width: 2, height: 2 }
            ];
            assert(getNearestBotRoomIndex([1, 2], 2 * tileSize, tileSize) === 2,
                'O Bot não priorizou a sala não visitada mais próxima.');
        } finally {
            dungeonRooms = originalRooms;
        }
    });

    runTest('A interface de jogo cabe na altura disponível em desktop', () => {
        if (window.innerWidth <= 760 || window.innerHeight < 700) {
            return false;
        }
        const actionsWereHidden = gameActions.hidden;
        try {
            document.body.dataset.gameScreen = 'playing';
            document.querySelector('.game-scene').getAnimations().forEach(animation => animation.finish());
            gameActions.hidden = false;
            const actionsBottom = document.getElementById('gameActions').getBoundingClientRect().bottom;
            assert(actionsBottom <= window.innerHeight + 1,
                'Os controles principais ficaram abaixo da área visível.');
        } finally {
            document.body.dataset.gameScreen = 'menu';
            gameActions.hidden = actionsWereHidden;
        }
    });

    runTest('A memória pode ser transferida antes de iniciar o Bot', () => {
        try {
            selectGameMode('bot');
            assert(!botMemoryActions.hidden, 'Os controles de memória não apareceram ao escolher Bot.');
        } finally {
            selectGameMode('human');
        }
        assert(botMemoryActions.hidden, 'Os controles de memória ficaram visíveis no modo manual.');
    });

    runTest('A memória do Bot valida e normaliza formatos suportados', () => {
        const { memory } = normalizeBotMemory(createEmptyBotMemory());
        assert(memory.version === 3, 'A versão da memória não foi normalizada.');
        assert(Object.keys(memory.enemyStrategies).length === creatureData.length
            && creatureData.every((creature) => (
                memory.enemyStrategies[creature.creatureType]
                && memory.enemyStrategies[creature.creatureType].weapons.bow
                && memory.enemyStrategies[creature.creatureType].tactics.flank
            )), 'A memória não inicializou armas e táticas para todo o monstruário.');
        let rejectedInvalidMemory = false;
        try {
            normalizeBotMemory({ version: 99, matches: 0, victories: 0, bestFloor: 0, maps: {} });
        } catch {
            rejectedInvalidMemory = true;
        }
        assert(rejectedInvalidMemory, 'Um formato inválido de memória foi aceito.');
    });

    runTest('A migração v2 preserva o histórico e remove mapas dependentes do layout', () => {
        const run = { floor: 20, performanceScore: 82, damageTaken: 100, result: 'victory' };
        const systemReport = {
            floor: 20,
            opportunities: 20,
            review: 'Revisão preservada',
            advice: 'Dica preservada'
        };
        const legacy = {
            version: 2,
            matches: 12,
            victories: 4,
            bestFloor: 20,
            maps: { 'layout-aleatorio': { floor: 20, visits: 1 } },
            runs: [run],
            latestSystemReport: systemReport,
            systemReports: [systemReport]
        };
        const { memory, migrated } = normalizeBotMemory(legacy);
        assert(migrated && memory.version === 3
            && memory.matches === 12
            && memory.victories === 4
            && memory.bestFloor === 20
            && memory.runs[0].result === 'victory'
            && memory.systemReports[0].advice === 'Dica preservada'
            && memory.latestSystemReport.review === 'Revisão preservada',
        'A migração não preservou contadores e históricos v2.');
        assert(!Object.prototype.hasOwnProperty.call(memory, 'maps')
            && Object.keys(memory.floorStats).length === 0
            && Object.keys(memory.roomStats).length === 0,
        'A migração manteve mapas específicos do layout ou inventou estatísticas.');
    });

    runTest('A importação valida campos obrigatórios e limita o tamanho', () => {
        const original = exportBotMemory();
        let rejectedMissingField = false;
        try {
            importBotMemory(JSON.stringify({ ...createEmptyBotMemory(), bestFloor: undefined }));
        } catch (error) {
            rejectedMissingField = error.message.includes('bestFloor');
        }
        let rejectedOversized = false;
        try {
            importBotMemory(' '.repeat(botMemoryMaxBytes + 1));
        } catch (error) {
            rejectedOversized = error.message.includes('512 KiB');
        }
        assert(rejectedMissingField && rejectedOversized,
            'A importação aceitou campo obrigatório ausente ou arquivo acima do limite.');
        assert(exportBotMemory() === original,
            'Uma importação inválida alterou a memória que já estava carregada.');
    });

    runTest('As rotas contam passos e revisitas sem gravar mapas gerados', () => {
        const previous = {
            botMode,
            botLearning,
            currentFloor,
            playerX: player.x,
            playerY: player.y
        };
        try {
            currentFloor = 1;
            botMode = true;
            botLearning = {
                routeSteps: 0,
                routeRevisits: 0,
                lastRouteTile: null,
                routeUniqueTiles: new Set(),
                routeTileVisits: {},
                routeRiskTiles: {},
                currentFloorObservation: {
                    floor: 1,
                    startedAt: performance.now(),
                    damageReceived: 0,
                    rooms: {},
                    finalized: false
                },
                roomVisitCounts: {},
                currentRoomObservation: null,
                visitedRooms: new Set(),
                seenEnemies: new Set(),
                explorationTargetRoom: null,
                explorationFloor: 1,
                lastPerceptionDelta: 0
            };
            player.x = startPosition.x * tileSize;
            player.y = startPosition.y * tileSize;
            recordBotRouteStep();
            player.x += tileSize;
            recordBotRouteStep();
            player.x -= tileSize;
            recordBotRouteStep();
            assert(botLearning.routeSteps === 3
                && botLearning.routeRevisits === 1
                && botLearning.routeTileVisits[`1:${startPosition.x},${startPosition.y}`] === 2,
            'Os passos, as revisitas e as frequências locais não foram acumulados.');
            assert(!Object.prototype.hasOwnProperty.call(botPersistentMemory, 'maps'),
                'A memória persistente voltou a guardar mapas específicos do layout.');
        } finally {
            botMode = previous.botMode;
            botLearning = previous.botLearning;
            currentFloor = previous.currentFloor;
            player.x = previous.playerX;
            player.y = previous.playerY;
        }
    });

    runTest('Os conselhos usam precisão, dano por andar e origem do dano da partida', () => {
        const advice = getBotAdvice({
            bowHits: 2,
            bowAttempts: 8,
            swordHits: 7,
            swordAttempts: 8,
            spearHits: 3,
            spearAttempts: 5,
            floorDamage: { 3: 12, 8: 47 },
            enemyDamageTaken: { spider: 18, throneGuardian: 31 }
        });
        const adviceChecks = [
            advice.includes('arco, 25% (2/8 acertos)'),
            advice.includes('andar 8 (47 de dano)'),
            advice.includes('Guardião do Trono (31 de dano)')
        ];
        assert(adviceChecks.every(Boolean),
            `Os conselhos não refletiram as métricas observadas na partida: ${advice}`);
    });

    runTest('Concluir o andar 20 grava a vitória e as estatísticas do chefe final', () => {
        const savedMemory = JSON.stringify(botPersistentMemory);
        const storedMemory = localStorage.getItem(botMemoryStorageKey);
        const previous = {
            botMode,
            botLearning,
            currentFloor,
            gameState,
            portalUnlocked,
            exitPosition: { ...exitPosition },
            playerX: player.x,
            playerY: player.y,
            updateBotStatus,
            createBotVictoryLetter,
            showBotVictoryLetter
        };
        const previousQuestText = questText.textContent;
        const previousInfoText = info.textContent;
        try {
            currentFloor = finalFloor;
            gameState = 'playing';
            botMode = true;
            portalUnlocked = true;
            player.x = startPosition.x * tileSize;
            player.y = startPosition.y * tileSize;
            exitPosition = {
                x: Math.floor((player.x + player.size / 2) / tileSize),
                y: Math.floor((player.y + player.size / 2) / tileSize)
            };
            botLearning = {
                runId: 123,
                saved: false,
                completed: false,
                bowHits: 0,
                swordHits: 0,
                spearHits: 0,
                bowAttempts: 0,
                bowMisses: 0,
                swordAttempts: 0,
                swordMisses: 0,
                spearAttempts: 0,
                spearMisses: 0,
                weaponDamage: { bow: 0, sword: 0, spear: 0 },
                arrowsFired: 0,
                arrowsCollected: 0,
                arrowsPurchased: 0,
                potionsUsed: 0,
                blockedHits: 0,
                shieldAbsorbed: 0,
                damageTaken: 0,
                floorDamage: {},
                floorDamageHealthRatio: {},
                enemyDamageTaken: {},
                enemyDefeats: 0,
                monsterDefeats: Object.fromEntries(
                    creatureData.map((creature) => [creature.creatureType, 0])
                ),
                bossDefeats: Object.fromEntries(
                    creatureData.map((creature) => [creature.creatureType, 0])
                ),
                bossDamageDealt: {
                    ...Object.fromEntries(creatureData.map((creature) => [creature.creatureType, 0]))
                },
                finalBossType: null,
                finalBossDamage: 0,
                coinsEarned: 0,
                coinsSpent: 0,
                lastObservedBalance: getOreCoinBalanceInCopper(),
                routeSteps: 0,
                routeRevisits: 0,
                routeUniqueTiles: new Set(),
                preferredRange: 22,
                flankSign: 1,
                currentFloorObservation: {
                    floor: finalFloor,
                    startedAt: performance.now(),
                    damageReceived: 0,
                    rooms: {},
                    finalized: false
                },
                enemyStrategyStats: Object.fromEntries(
                    creatureData.map((creature) => [
                        creature.creatureType,
                        createEmptyEnemyStrategy()
                    ])
                )
            };
            botLearning.blockedTarget = null;
            const finalBoss = {
                isBoss: true,
                bossType: 'throneGuardian',
                shieldDurability: 0
            };
            recordBotWeaponAttempt('sword', finalBoss);
            recordBotWeaponOutcome('sword', true, finalBoss);
            recordBotCombat('sword', 125, false, finalBoss);
            recordBotEnemyDefeat(finalBoss);
            updateBotStatus = () => {};
            createBotVictoryLetter = () => 'Vitória confirmada';
            showBotVictoryLetter = () => {};
            const previousVictories = botPersistentMemory.victories;
            const previousMatches = botPersistentMemory.matches;
            checkPlayerTile();
            const stored = JSON.parse(localStorage.getItem(botMemoryStorageKey));
            const run = stored.runs[stored.runs.length - 1];
            assert(gameState === 'won'
                && stored.version === 3
                && stored.victories === previousVictories + 1
                && stored.matches === previousMatches + 1
                && run.finalBossDefeated
                && run.bossDefeats.throneGuardian === 1
                && run.bossDamageDealt.throneGuardian === 125
                && run.monsterDefeats.throneGuardian === 1,
            'A vitória ou as estatísticas do chefe final não foram gravadas ao concluir.');
            assert(!Object.prototype.hasOwnProperty.call(stored, 'maps'),
                'A memória persistida voltou a conter mapas completos.');
        } finally {
            botMode = previous.botMode;
            botLearning = previous.botLearning;
            currentFloor = previous.currentFloor;
            gameState = previous.gameState;
            portalUnlocked = previous.portalUnlocked;
            exitPosition = previous.exitPosition;
            player.x = previous.playerX;
            player.y = previous.playerY;
            updateBotStatus = previous.updateBotStatus;
            createBotVictoryLetter = previous.createBotVictoryLetter;
            showBotVictoryLetter = previous.showBotVictoryLetter;
            questText.textContent = previousQuestText;
            info.textContent = previousInfoText;
            botPersistentMemory = JSON.parse(savedMemory);
            if (storedMemory === null) {
                localStorage.removeItem(botMemoryStorageKey);
            } else {
                localStorage.setItem(botMemoryStorageKey, storedMemory);
            }
        }
    });

    runTest('A nova HUD tem cargas individuais e remove o sistema especial antigo', () => {
        assert(Boolean(document.getElementById('swordSpecialTrack'))
            && Boolean(document.getElementById('conquestSpecialTrack')),
        'As barras individuais das duas habilidades não foram renderizadas.');
        assert(!document.getElementById('specialAttackTrack'),
            'A barra especial antiga continua no HUD.');
        assert(!('specialCharge' in player) && !('auraTier' in player)
            && !('fireSwordTimer' in player),
        'O estado antigo do especial ainda existe no jogador.');
    });

    runTest('Dano corpo a corpo carrega as habilidades individualmente e persiste entre andares', () => {
        const previousGameState = gameState;
        try {
            currentFloor = 1;
            botMode = false;
            shopOpen = false;
            resetGame();
            map = map.map((row) => row.map(() => '.'));
            gameState = 'playing';
            swordEquipped = true;
            player.damage = 10;
            player.counterAttackTimer = 0;
            player.dashActive = false;
            const target = createEnemy(4, 4, chooseOreDrop(), 'goblin');
            enemies = [target];
            target.x = player.x + 24;
            target.y = player.y;
            target.health = 100;
            target.armorDurability = 0;
            target.shieldDurability = 0;
            target.facingX = 0;
            target.facingY = 0;
            target.dying = false;
            scrollInventory.conquista = 1;
            player.specialAbilityCharges = { sword: 0, conquest: 0 };
            attackWithSword();
            assert(player.specialAbilityCharges.sword === 10
                && player.specialAbilityCharges.conquest === 10,
            'O dano corpo a corpo não carregou ambas as habilidades pela mesma quantidade.');
            chargeSpecialAbilities(95);
            assert(player.specialAbilityCharges.sword === 100
                && player.conquestAuraTier === 1
                && player.specialAbilityCharges.conquest === 5,
            'A espada não limitou a carga ou a Conquista não avançou ao completar a barra.');
            chargeSpecialAbilities(10000);
            assert(player.specialAbilityCharges.sword === 100
                && player.conquestAuraTier === finalConquestAuraTier
                && player.specialAbilityCharges.conquest === 100,
            'As cargas não foram limitadas ou a Conquista não parou cheia no estágio máximo.');
            resetGame(true);
            assert(player.specialAbilityCharges.sword === 100
                && player.specialAbilityCharges.conquest === 100
                && player.conquestAuraTier === finalConquestAuraTier,
            'As cargas não persistiram ao reiniciar sem avançar de andar.');
        } finally {
            gameState = previousGameState;
        }
    });

    runTest('O golpe especial consome a carga e atinge inimigos no raio configurado', () => {
        const previousGameState = gameState;
        const previousBarrels = barrels;
        const previousChests = chests;
        const previousDecorations = ambientDecorations;
        try {
            currentFloor = 1;
            botMode = false;
            shopOpen = false;
            resetGame();
            map = map.map((row) => row.map(() => '.'));
            barrels = [];
            chests = [];
            ambientDecorations = [];
            gameState = 'playing';
            swordEquipped = true;
            player.damage = 10;
            player.counterAttackTimer = 0;
            player.dashActive = false;
            player.specialAbilityCharges.sword = 100;
            player.specialAbilityCooldowns.sword = 0;
            const [near, far, outside] = [
                createEnemy(4, 4, chooseOreDrop(), 'goblin'),
                createEnemy(5, 4, chooseOreDrop(), 'goblin'),
                createEnemy(6, 4, chooseOreDrop(), 'goblin')
            ];
            enemies = [near, far, outside];
            for (const [enemy, offset] of [[near, 24], [far, 48], [outside, 96]]) {
                enemy.x = player.x + offset;
                enemy.y = player.y;
                enemy.health = 100;
                enemy.armorDurability = 0;
                enemy.shieldDurability = 0;
                enemy.facingX = 0;
                enemy.facingY = 0;
                enemy.dying = false;
            }
            activateSwordAreaSpecial();
            assert(near.health === 80 && far.health === 80,
                'O golpe não causou duas vezes o dano a todos os alvos próximos.');
            assert(outside.health === 100, 'O golpe atingiu um alvo além do raio de quatro quadrados.');
            assert(player.specialAbilityCharges.sword === 0,
                'O golpe não consumiu a carga total.');
            assert(player.specialAbilityCooldowns.sword === 3,
                'A recarga própria de três segundos não foi aplicada.');
        } finally {
            gameState = previousGameState;
            barrels = previousBarrels;
            chests = previousChests;
            ambientDecorations = previousDecorations;
        }
    });

    runTest('Conquista evolui a aura passivamente e reinicia ao avançar de andar', () => {
        const previousGameState = gameState;
        try {
            currentFloor = 1;
            botMode = false;
            shopOpen = false;
            resetGame();
            gameState = 'playing';
            assert(selectedSpecialAbility === 'sword',
                'A nova partida não selecionou a habilidade da espada por padrão.');
            scrollInventory.conquista = 0;
            document.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', bubbles: true }));
            assert(selectedSpecialAbility === 'conquest',
                'A tecla Z não alternou para a habilidade Conquista.');
            document.dispatchEvent(new KeyboardEvent('keydown', { key: 'f', bubbles: true }));
            assert(player.specialAbilityCharges.conquest === 0
                && getConquestAuraMultiplier() === 1,
            'Conquista progrediu ou concedeu bônus sem o pergaminho.');
            scrollInventory.conquista = 1;
            assert(getConquestAuraMultiplier() === 1,
                'A aura inicial concedeu bônus antes de a primeira etapa ser preenchida.');
            document.dispatchEvent(new KeyboardEvent('keydown', { key: 'f', bubbles: true }));
            assert(scrollInventory.conquista === 1
                && player.conquestAuraTier === 0
                && player.specialAbilityCharges.conquest === 0,
            'A tecla F ativou ou consumiu a Conquista passiva.');
            chargeSpecialAbilities(100);
            assert(player.conquestAuraTier === 1
                && player.specialAbilityCharges.conquest === 0
                && Math.abs(getConquestAuraMultiplier() - 1.125) < 0.001,
            'A barra cheia não avançou para a primeira aura de 12,5%.');
            const auraTarget = enemies[0];
            auraTarget.health = 100;
            auraTarget.isBoss = false;
            auraTarget.armorDurability = 0;
            auraTarget.shieldDurability = 0;
            auraTarget.facingX = 0;
            auraTarget.facingY = 0;
            player.counterAttackTimer = 0;
            const auraHit = damageEnemy(
                auraTarget,
                10,
                player.x + player.size / 2,
                player.y + player.size / 2
            );
            assert(auraHit.damage === 12,
                'O bônus de dano da aura não foi aplicado ao ataque do jogador.');
            chargeSpecialAbilities(700);
            assert(player.conquestAuraTier === finalConquestAuraTier
                && player.specialAbilityCharges.conquest === 100
                && getConquestAuraMultiplier() === 2,
            'A progressão não chegou ao máximo de +100% ou não manteve a barra cheia.');
            const scrollCount = scrollInventory.conquista;
            player.specialAbilityCooldowns.sword = 2;
            resetGame(true, true);
            assert(player.conquestAuraTier === 0
                && player.specialAbilityCharges.conquest === 0
                && player.specialAbilityCharges.sword === 0
                && player.specialAbilityCooldowns.sword === 0,
            'A aura, as cargas e a recarga não reiniciaram ao avançar de andar.');
            assert(scrollInventory.conquista === scrollCount
                && getConquestAuraMultiplier() === 1,
            'O pergaminho não permaneceu no inventário após reiniciar a progressão.');
            updateSpecialAbilitiesHud();
            assert(document.getElementById('activateSpecialAbilityButton').disabled,
                'A aura passiva habilitou incorretamente o botão de ativação.');
        } finally {
            gameState = previousGameState;
        }
    });

    runTest('Exportar e importar preserva a memória e rejeita dados inválidos', () => {
        const original = exportBotMemory();
        importBotMemory(original);
        assert(JSON.stringify(JSON.parse(exportBotMemory()))
            === JSON.stringify(JSON.parse(original)),
        'A memória mudou após a importação.');
        let rejectedInvalidMemory = false;
        try {
            importBotMemory('{"version":99}');
        } catch {
            rejectedInvalidMemory = true;
        }
        assert(rejectedInvalidMemory, 'Uma memória inválida foi importada.');
        assert(JSON.stringify(JSON.parse(exportBotMemory()))
            === JSON.stringify(JSON.parse(original)),
        'A memória válida foi alterada por uma importação inválida.');
    });

    runTest('A loja só compra a poção após confirmar no botão', () => {
        currentFloor = 1;
        botMode = false;
        devMode = false;
        resetGame();
        oreCoinBalance.copper = 500;
        setShopOpen(true);
        const balanceBeforeSelection = getOreCoinBalanceInCopper();
        const potionsBeforeSelection = healingPotions.length;
        shopItems.potion.click();
        assert(getOreCoinBalanceInCopper() === balanceBeforeSelection
            && healingPotions.length === potionsBeforeSelection,
        'Selecionar a poção alterou o saldo ou comprou o item.');
        assert(!shopItemPurchaseButton.disabled,
            'O botão de compra foi desabilitado apesar do saldo suficiente.');
        const potionCost = getUpgradeCost('potion');
        shopItemPurchaseButton.click();
        assert(healingPotions.length === potionsBeforeSelection + 1,
            'Confirmar a compra não adicionou a poção ao inventário.');
        assert(getOreCoinBalanceInCopper() === balanceBeforeSelection - potionCost,
            'Confirmar a compra não descontou o preço da poção.');
        setShopOpen(false);
    });

    runTest('A loja limita poções e encarece melhorias gradualmente', () => {
        currentFloor = 1;
        botMode = false;
        devMode = false;
        resetGame();
        oreCoinBalance.copper = 500;
        setShopOpen(true);
        assert(getUpgradeCost('sword') === 4
            && getUpgradeCost('potion') === 12,
        'Os custos iniciais de espada ou poção não usam o balanceamento configurado.');
        gearUpgrades.sword = 1;
        assert(getUpgradeCost('sword') === 5,
            'O custo da espada não cresceu conforme a fórmula exponencial.');
        assert(GAME_BALANCE.economy.upgradeCostGrowth === 1.32
            && GAME_BALANCE.economy.oreDropWeights.emerald < 0.2
            && GAME_BALANCE.economy.potionDropMultiplier < 1,
        'O crescimento dos custos ou os limites da economia não usam a configuração central.');
        const previousSwordLevel = gearUpgrades.sword;
        gearUpgrades.sword = 0;
        let swordToLevelEighteenCost = 0;
        for (let level = 0; level < 18; level += 1) {
            swordToLevelEighteenCost += getUpgradeCost('sword');
            gearUpgrades.sword += 1;
        }
        gearUpgrades.sword = previousSwordLevel;
        assert(swordToLevelEighteenCost > 1158,
            'A progressão permite atingir espada nível 18 com a economia observada.');
        healingPotions = Array.from(
            { length: GAME_BALANCE.economy.potionCapacity },
            () => ({ type: 'potion', rarity: itemRarities[0] })
        );
        selectedShopItemType = 'potion';
        updateShopPurchaseButton();
        assert(shopItemPurchaseButton.disabled,
            'A loja permitiu selecionar compra de poção acima do limite.');
        setShopOpen(false);
    });

    runTest('O arco tem munição limitada, reposição e recarga configuráveis', () => {
        currentFloor = 1;
        botMode = false;
        devMode = false;
        resetGame();
        playerProgress.level = GAME_BALANCE.shop.items.bow.nivelMinimo;
        oreCoinBalance.copper = GAME_BALANCE.economy.fixedCosts.bow
            + GAME_BALANCE.bow.ammoBundleCost;
        setShopOpen(true);
        purchaseUpgrade('bow');
        assert(bowOwned && arrowAmmo === GAME_BALANCE.bow.startingAmmo,
            'Comprar o arco não concedeu a aljava inicial configurada.');
        purchaseUpgrade('arrows');
        assert(arrowAmmo === GAME_BALANCE.bow.startingAmmo + GAME_BALANCE.bow.ammoBundleSize
            && getOreCoinBalanceInCopper() === 0,
        'O pacote de flechas não adicionou munição ou descontou o custo configurado.');
        assert(GAME_BALANCE.bow.cooldownSeconds > 0.55
            && GAME_BALANCE.bow.damage < 14,
        'O dano e a recarga do arco não foram rebalanceados.');
        setShopOpen(false);
    });

    runTest('Flechas podem ser coletadas sem arco, mas não permitem atirar', () => {
        const previousAmmo = arrowAmmo;
        const previousBowOwned = bowOwned;
        const previousSwordEquipped = swordEquipped;
        const previousGameState = gameState;
        const previousShopOpen = shopOpen;
        const previousBotMode = botMode;
        const previousCooldown = player.arrowCooldown;
        const previousDrops = itemDrops.slice();
        const previousArrows = arrows.slice();
        try {
            gameState = 'playing';
            shopOpen = false;
            botMode = false;
            bowOwned = false;
            swordEquipped = false;
            arrowAmmo = 0;
            player.arrowCooldown = 0;
            itemDrops = [{
                type: 'arrows',
                quantity: GAME_BALANCE.bow.ammoPickup,
                x: player.x + player.size / 2,
                y: player.y + player.size / 2,
                animTime: 0
            }];
            updateBowHud();
            collectItemDrops();
            assert(arrowAmmo === GAME_BALANCE.bow.ammoPickup
                && itemDrops.length === 0,
            'O drop de flechas não foi coletado sem possuir o arco.');
            assert(!bowSlot.hidden
                && bowSlot.disabled
                && bowInventoryIcon.src.endsWith('/assets/inventory-items/arrows.png')
                && bowSlot.querySelector('.inventory-item-name').textContent === 'Flechas'
                && bowSlot.getAttribute('aria-label').includes('não é possível atirar'),
            'O inventário não identifica as flechas armazenadas sem sugerir que o arco está disponível.');
            fireArrow(player.x + player.size + 20, player.y + player.size / 2);
            assert(arrowAmmo === GAME_BALANCE.bow.ammoPickup
                && arrows.length === previousArrows.length
                && player.arrowCooldown === 0,
            'Possuir flechas sem arco permitiu disparar ou consumiu munição.');
        } finally {
            itemDrops = previousDrops;
            arrows.splice(0, arrows.length, ...previousArrows);
            arrowAmmo = previousAmmo;
            bowOwned = previousBowOwned;
            swordEquipped = previousSwordEquipped;
            gameState = previousGameState;
            shopOpen = previousShopOpen;
            botMode = previousBotMode;
            player.arrowCooldown = previousCooldown;
            updateBowHud();
        }
    });

    runTest('Atirar sem flechas não consome munição, cria projéteis ou altera a recarga', () => {
        const previousAmmo = arrowAmmo;
        const previousBowOwned = bowOwned;
        const previousSwordEquipped = swordEquipped;
        const previousGameState = gameState;
        const previousShopOpen = shopOpen;
        const previousCooldown = player.arrowCooldown;
        const previousArrows = arrows.slice();
        try {
            gameState = 'playing';
            shopOpen = false;
            bowOwned = true;
            swordEquipped = false;
            arrowAmmo = 0;
            player.arrowCooldown = 0;
            fireArrow(player.x + player.size + 20, player.y + player.size / 2);
            assert(arrowAmmo === 0 && arrows.length === previousArrows.length,
                'Um disparo sem munição consumiu flechas ou criou um projétil.');
            assert(player.arrowCooldown === 0,
                'Um disparo sem munição iniciou a recarga do arco.');
            assert(info.textContent.includes('Sem flechas'),
                'O jogador não recebeu aviso de falta de munição.');
        } finally {
            arrows.splice(0, arrows.length, ...previousArrows);
            arrowAmmo = previousAmmo;
            bowOwned = previousBowOwned;
            swordEquipped = previousSwordEquipped;
            gameState = previousGameState;
            shopOpen = previousShopOpen;
            player.arrowCooldown = previousCooldown;
            updateBowHud();
        }
    });

    runTest('Metas e escala dos inimigos seguem as faixas de balanceamento', () => {
        const previousFloor = currentFloor;
        try {
            currentFloor = 15;
            const reaper = createBoss(5, 5, 'grimReaper');
            assert(Math.abs(reaper.damageMultiplier
                - 1.2 * GAME_BALANCE.bosses.standardPowerMultiplier
                    * GAME_BALANCE.bosses.reaperDamageMultiplier) < 0.001,
            'O dano do Ceifador não aplicou o ajuste decidido após revisar seus avisos visuais.');
        } finally {
            currentFloor = previousFloor;
        }
        assert(getFloorKillGoal(1) === 6
            && getFloorKillGoal(10) === 11
            && getFloorKillGoal(15) === 16
            && getFloorKillGoal(finalFloor) === 20,
        'As metas por faixa de cinco andares não foram aplicadas.');
        assert(getCreatureScaledStat('troll', 'health', 20)
            === Math.round(creatureDataByType.troll.stats.health * 2.7)
            && getCreatureScaledStat('troll', 'damage', 20)
            === Math.round(creatureDataByType.troll.stats.damage * 2.6),
        'A escala de vida ou dano dos inimigos não usa os valores centrais.');
    });

    runTest('O chefe final possui terceira fase sem alterar a sequência de fraqueza', () => {
        const boss = {
            isBoss: true,
            bossType: 'throneGuardian',
            finalBoss: true,
            phaseTwo: false,
            phaseThree: false,
            health: 0,
            maxHealth: 200,
            displayHealth: 0,
            attackCooldown: 2,
            veinPulseCooldown: 2,
            veinPulseWarning: 1,
            bossAttackCount: 0
        };
        assert(enterBossPhaseTwo(boss)
            && boss.phaseTwo
            && !boss.phaseThree
            && boss.health === boss.maxHealth,
        'A primeira transição do chefe final não entrou na fase dois.');
        boss.health = 0;
        assert(enterBossPhaseTwo(boss)
            && boss.phaseTwo
            && boss.phaseThree
            && boss.health === boss.maxHealth,
        'A segunda transição não abriu a terceira fase do chefe final.');
        boss.bossAttackCount = GAME_BALANCE.bosses.weaknessAttackThreshold - 1;
        recordBossAttack(boss);
        assert(Math.abs(boss.weaknessTimer - GAME_BALANCE.bosses.finalPhaseWeaknessSeconds) < 0.001,
            'A janela de vulnerabilidade da fase final não usou a configuração central.');
        assert(GAME_BALANCE.bosses.phaseOneWeaknessSeconds === 2.3
            && GAME_BALANCE.bosses.phaseTwoWeaknessSeconds === 1.7
            && GAME_BALANCE.bosses.weaknessAttackThreshold === 3
            && GAME_BALANCE.bosses.meleeBlockChance === 0.25
            && GAME_BALANCE.bosses.arrowBlockChance === 0.5
            && GAME_BALANCE.bosses.finalPowerMultiplier === 1.9,
        'A terceira fase alterou regras de chefe que deveriam permanecer intactas.');
    });

    runTest('A carta do Bot calcula desafios, percentuais e chefe final a partir da partida', () => {
        const previousBotLearning = botLearning;
        try {
            botLearning = {
                bowHits: 5,
                swordHits: 5,
                spearHits: 0,
                bowAttempts: 6,
                swordAttempts: 6,
                spearAttempts: 0,
                weaponDamage: { bow: 50, sword: 50, spear: 0 },
                floorDamage: { 1: 10 },
                floorDamageHealthRatio: { 1: 0.1 },
                bossDefeats: { throneGuardian: 1 },
                bossDamageDealt: { throneGuardian: 400 },
                enemyDefeats: 3,
                monsterDefeats: { spider: 2, troll: 1 },
                blockedHits: 0,
                shieldAbsorbed: 0,
                damageTaken: 10,
                routeSteps: 0,
                routeRevisits: 0,
                routeUniqueTiles: new Set(),
                performanceScore: 90,
                arrowsFired: 0,
                arrowsCollected: 0,
                arrowsPurchased: 0,
                potionsUsed: 0,
                coinsEarned: 0,
                coinsSpent: 0,
                previousRunSnapshot: {
                    floorsCleared: 10,
                    damageTaken: 100,
                    weaponDamage: { bow: 75, sword: 25, spear: 0 }
                },
                finalBossType: 'throneGuardian',
                finalBossDamage: 300
            };
            const letter = createBotVictoryLetter();
            assert(letter.includes('1 chefe derrotado')
                && letter.includes('Guardião do Trono: 1 vitória')
                && letter.includes('Chefe final (Guardião do Trono): 300 de dano causado'),
            'A carta omitiu o chefe final ou usou concordância/contagem incorreta.');
            assert(letter.includes('50% do total')
                && letter.includes('Comparativo com a partida anterior')
                && letter.includes('Andar 20')
                && letter.includes('A criatura Aranha das galerias foi derrotada 2 vezes')
                && letter.includes('A criatura Troll contaminado foi derrotada 1 vez'),
            'A carta não refletiu a partida, os desafios específicos ou o comparativo anterior.');
            assert(!letter.includes('derrotado(s)')
                && !letter.includes('Priorize reparar ou melhorar a armadura'),
            'A carta manteve pluralização artificial ou recomendação defensiva sem evidência.');
        } finally {
            botLearning = previousBotLearning;
        }
    });

    runTest('A loja compra um arco pelo saldo correto', () => {
        currentFloor = 1;
        botMode = false;
        devMode = false;
        resetGame();
        playerProgress.level = GAME_BALANCE.shop.items.bow.nivelMinimo;
        oreCoinBalance.copper = 12;
        setShopOpen(true);
        purchaseUpgrade('bow');
        assert(bowOwned, 'O arco não foi adquirido.');
        assert(getOreCoinBalanceInCopper() === 0, 'O saldo não foi descontado corretamente.');
        setShopOpen(false);
    });

    runTest('A loja valida nível antes de cobrar e mostra o requisito', () => {
        currentFloor = 1;
        botMode = false;
        devMode = false;
        resetGame();
        oreCoinBalance.copper = getUpgradeCost('spear');
        setShopOpen(true);
        shopAvailableOnlyFilter.checked = true;
        updateShopHud();
        assert(!shopItems.sword.hidden && shopItems.spear.hidden && shopItems.dash.hidden,
            'O filtro não separou itens disponíveis de itens bloqueados por nível.');
        shopAvailableOnlyFilter.checked = false;
        updateShopHud();
        showShopItemInformation('spear');
        assert(shopItems.spear.querySelector('[data-minimum-level]').textContent
            .includes(`Requer nível ${GAME_BALANCE.shop.items.spear.nivelMinimo}`),
        'O cartão não mostrou claramente o nível exigido.');
        const balanceBeforeBlockedPurchase = getOreCoinBalanceInCopper();
        purchaseUpgrade('spear');
        assert(!spearOwned
            && getOreCoinBalanceInCopper() === balanceBeforeBlockedPurchase,
        'A compra bloqueada entregou o item ou cobrou moedas.');
        assert(info.textContent.includes(`nível ${GAME_BALANCE.shop.items.spear.nivelMinimo}`)
            && shopItemDescription.textContent.includes('Requer nível'),
        'A mensagem de bloqueio ou o requisito não foi exibido.');
        assert(shopItemPurchaseButton.disabled
            && shopItemPurchaseButton.textContent.includes('Requer nível'),
        'O botão de compra não ficou indisponível pelo nível.');

        playerProgress.level = GAME_BALANCE.shop.items.spear.nivelMinimo;
        showShopItemInformation('spear');
        purchaseUpgrade('spear');
        assert(spearOwned
            && getOreCoinBalanceInCopper() === 0,
        'A compra válida não entregou o item ou cobrou o preço correto.');
        shopAvailableOnlyFilter.checked = false;
        setShopOpen(false);
    });

    runTest('A cada duas compras, o mesmo item exige mais um nível', () => {
        currentFloor = 1;
        botMode = false;
        devMode = false;
        resetGame();
        const baseLevel = GAME_BALANCE.shop.items.sword.nivelMinimo;
        playerProgress.level = baseLevel;
        oreCoinBalance.copper = 1000;
        setShopOpen(true);

        purchaseUpgrade('sword');
        assert(getShopMinimumLevel('sword') === baseLevel,
            'O requisito da espada aumentou antes de duas compras.');
        purchaseUpgrade('sword');
        assert(getShopMinimumLevel('sword') === baseLevel + 1,
            'O requisito da espada não aumentou após duas compras.');
        assert(getShopMinimumLevel('shield') === GAME_BALANCE.shop.items.shield.nivelMinimo,
            'As compras da espada alteraram o requisito de outro item.');
        assert(shopItems.sword.querySelector('[data-minimum-level]').textContent
            .includes(`Nível ${baseLevel + 1}`),
        'A loja não atualizou o requisito exibido após a segunda compra.');

        const balanceBeforeBlockedPurchase = getOreCoinBalanceInCopper();
        purchaseUpgrade('sword');
        assert(gearUpgrades.sword === 2
            && getOreCoinBalanceInCopper() === balanceBeforeBlockedPurchase,
        'A compra bloqueada alterou a melhoria ou cobrou moedas.');

        playerProgress.level = baseLevel + 1;
        purchaseUpgrade('sword');
        assert(gearUpgrades.sword === 3
            && getShopMinimumLevel('sword') === baseLevel + 1,
        'A compra não foi liberada ao atingir o novo nível exigido.');
        setShopOpen(false);
    });

    runTest('Os dados da loja e chances da IA respeitam faixas válidas', () => {
        assert(Object.keys(shopItems).every((type) => (
            Number.isInteger(GAME_BALANCE.shop.items[type]?.nivelMinimo)
            && GAME_BALANCE.shop.items[type].nivelMinimo >= 1
        )), 'Há item sem nivelMinimo inteiro válido.');
        const chances = [
            GAME_BALANCE.bot.retreat.baseChancePercent,
            GAME_BALANCE.bot.retreat.maximumChancePercent,
            ...Object.values(GAME_BALANCE.bot.objects.baseChancePercent)
        ];
        const retreat = GAME_BALANCE.bot.retreat;
        const objects = GAME_BALANCE.bot.objects;
        assert(chances.every((chance) => Number.isFinite(chance)
            && chance >= 0 && chance <= 100),
        'Uma chance configurável da IA está fora de 0 a 100%.');
        assert(retreat.lowHealthRatio >= 0 && retreat.lowHealthRatio <= 1
            && retreat.returnHealthRatio > retreat.lowHealthRatio
            && retreat.returnHealthRatio <= 1
            && retreat.cooldownSeconds >= 0
            && retreat.maximumConsecutiveRetreats >= 1
            && objects.perceptionDistance > 0
            && objects.immediateThreatDistance > 0
            && objects.attacksPerInterval >= 1,
        'Um limiar, alcance, cooldown ou limite da IA está fora da faixa válida.');
    });

    runTest('A decisão de recuar usa chance probabilística configurada', () => {
        const previousRetreatState = botRetreatState;
        const originalRandom = Math.random;
        try {
            botRetreatState = {
                active: false,
                enemy: null,
                elapsed: 0,
                cooldown: 0,
                consecutive: 0,
                lastAttemptKey: ''
            };
            Math.random = () => 0;
            assert(botTryStartRetreat([], null, 0.2),
                'A rolagem bem-sucedida não iniciou o recuo em vida crítica.');
            botRetreatState = {
                active: false,
                enemy: null,
                elapsed: 0,
                cooldown: 0,
                consecutive: 0,
                lastAttemptKey: ''
            };
            Math.random = () => 0.999;
            assert(!botTryStartRetreat([], null, 0.2),
                'A rolagem alta ignorou a chance probabilística de recuo.');
        } finally {
            Math.random = originalRandom;
            botRetreatState = previousRetreatState;
        }
    });

    runTest('O Bot não usa dash através de parede ao seguir uma rota alternativa', () => {
        const previousMap = map;
        const previousDoors = doors;
        const previousBarrels = barrels;
        const previousChests = chests;
        const previousDecorations = ambientDecorations;
        const previousPosition = { x: player.x, y: player.y };
        const previousDashState = {
            active: player.dashActive,
            cooldown: player.dashCooldown,
            distance: player.dashDistance,
            duration: player.dashDuration,
            timer: player.dashTimer,
            travelled: player.dashTravelled,
            target: player.dashTarget
        };
        const previousBotMode = botMode;
        const previousGameState = gameState;
        const previousKeys = { ...keys };
        const previousAlignmentTarget = botAlignmentTarget;
        const previousBotLearning = botLearning;
        try {
            map = Array.from({ length: rows }, () => Array(cols).fill('.'));
            for (let row = 4; row <= 6; row += 1) {
                map[row][10] = '#';
            }
            doors = [];
            barrels = [];
            chests = [];
            ambientDecorations = [];
            botMode = true;
            gameState = 'playing';
            botLearning = { routeTileVisits: {}, routeRiskTiles: {} };
            player.x = 5 * tileSize;
            player.y = 5 * tileSize;
            player.dashActive = false;
            player.dashCooldown = 0;
            botMoveTo(15.5 * tileSize, 5.5 * tileSize, 0, 7, true);
            assert(!player.dashActive
                && (keys.ArrowUp || keys.ArrowDown || keys.ArrowLeft || keys.ArrowRight),
            'O Bot iniciou um dash que ultrapassa a curva necessária para contornar a parede.');
        } finally {
            map = previousMap;
            doors = previousDoors;
            barrels = previousBarrels;
            chests = previousChests;
            ambientDecorations = previousDecorations;
            player.x = previousPosition.x;
            player.y = previousPosition.y;
            player.dashActive = previousDashState.active;
            player.dashCooldown = previousDashState.cooldown;
            player.dashDistance = previousDashState.distance;
            player.dashDuration = previousDashState.duration;
            player.dashTimer = previousDashState.timer;
            player.dashTravelled = previousDashState.travelled;
            player.dashTarget = previousDashState.target;
            botMode = previousBotMode;
            gameState = previousGameState;
            Object.assign(keys, previousKeys);
            botAlignmentTarget = previousAlignmentTarget;
            botLearning = previousBotLearning;
        }
    });

    runTest('O Bot busca uma posição de ataque quando um obstáculo bloqueia o golpe', () => {
        const previousMap = map;
        const previousDoors = doors;
        const previousBarrels = barrels;
        const previousChests = chests;
        const previousDecorations = ambientDecorations;
        const previousPosition = { x: player.x, y: player.y };
        const previousKeys = { ...keys };
        const previousAlignmentTarget = botAlignmentTarget;
        const previousBotLearning = botLearning;
        try {
            map = Array.from({ length: rows }, () => Array(cols).fill('.'));
            doors = [];
            barrels = [];
            chests = [{ x: 6, y: 5, health: 20 }];
            ambientDecorations = [];
            botLearning = { routeTileVisits: {}, routeRiskTiles: {} };
            player.x = 5 * tileSize;
            player.y = 5 * tileSize;
            const playerCenterX = player.x + player.size / 2;
            const playerCenterY = player.y + player.size / 2;
            const targetX = 7.5 * tileSize;
            const targetY = 5.5 * tileSize;

            assert(!hasClearMeleeAttackPath(
                playerCenterX,
                playerCenterY,
                targetX,
                targetY
            ), 'O baú de teste não bloqueou a trajetória do golpe.');
            const repositionTarget = botFindMeleeRepositionTarget(
                playerCenterX,
                playerCenterY,
                targetX,
                targetY,
                40
            );
            assert(repositionTarget
                && hasClearMeleeAttackPath(
                    repositionTarget.x,
                    repositionTarget.y,
                    targetX,
                    targetY
                )
                && Math.hypot(
                    repositionTarget.x - targetX,
                    repositionTarget.y - targetY
                ) <= 40,
            'O Bot não encontrou um ponto livre dentro do alcance de ataque.');

            botMoveTo(repositionTarget.x, repositionTarget.y, 0, 8);
            assert(keys.ArrowUp || keys.ArrowDown || keys.ArrowLeft || keys.ArrowRight,
                'O Bot não iniciou movimento para contornar o obstáculo.');
        } finally {
            map = previousMap;
            doors = previousDoors;
            barrels = previousBarrels;
            chests = previousChests;
            ambientDecorations = previousDecorations;
            player.x = previousPosition.x;
            player.y = previousPosition.y;
            Object.assign(keys, previousKeys);
            botAlignmentTarget = previousAlignmentTarget;
            botLearning = previousBotLearning;
        }
    });

    runTest('Visitas antigas não desviam repetidamente a rota até um objetivo', () => {
        const previousMap = map;
        const previousDoors = doors;
        const previousBarrels = barrels;
        const previousChests = chests;
        const previousDecorations = ambientDecorations;
        const previousPosition = { x: player.x, y: player.y };
        const previousBotLearning = botLearning;
        const previousAlignmentTarget = botAlignmentTarget;
        try {
            map = Array.from({ length: rows }, () => Array(cols).fill('.'));
            doors = [];
            barrels = [];
            chests = [];
            ambientDecorations = [];
            botLearning = { routeTileVisits: {}, routeRiskTiles: {} };
            for (let col = 6; col < 15; col += 1) {
                botLearning.routeTileVisits[`${currentFloor}:${col},5`] = 50;
            }
            player.x = 5 * tileSize;
            player.y = 5 * tileSize;
            const direction = botFindPathDirection(
                15.5 * tileSize,
                5.5 * tileSize,
                0,
                7
            );
            assert(direction.x > 0,
                'O histórico de visitas desviou o Bot de um corredor livre até o objetivo.');
        } finally {
            map = previousMap;
            doors = previousDoors;
            barrels = previousBarrels;
            chests = previousChests;
            ambientDecorations = previousDecorations;
            player.x = previousPosition.x;
            player.y = previousPosition.y;
            botLearning = previousBotLearning;
            botAlignmentTarget = previousAlignmentTarget;
        }
    });

    runTest('O Bot identifica objetos no caminho e respeita a prioridade de inimigos', () => {
        const previousBarrels = barrels;
        const previousChests = chests;
        const previousQuietTime = botObjectQuietTime;
        const previousAttackCount = botObjectsAttackedInInterval;
        const previousAttemptKey = botObjectLastAttemptKey;
        const previousEnemies = enemies;
        const previousDecorations = ambientDecorations;
        const previousGameState = gameState;
        const previousShopOpen = shopOpen;
        const previousSwordEquipped = swordEquipped;
        const previousAttackCooldown = player.attackCooldown;
        const originalRandom = Math.random;
        try {
            const playerX = player.x + player.size / 2;
            const playerY = player.y + player.size / 2;
            const objectCol = Math.max(1, Math.min(cols - 2,
                Math.floor(playerX / tileSize) + (playerX < gridWidth / 2 ? 1 : -1)));
            const objectRow = Math.max(1, Math.min(rows - 2, Math.floor(playerY / tileSize)));
            const objectX = (objectCol + 0.5) * tileSize;
            barrels = [{ x: objectCol, y: objectRow, health: 20 }];
            chests = [];
            botObjectQuietTime = GAME_BALANCE.bot.objects.quietTimeSeconds + 1;
            botObjectsAttackedInInterval = 0;
            botObjectLastAttemptKey = '';
            Math.random = () => 0;
            const target = botGetObjectTarget(
                playerX,
                playerY,
                objectX + (objectX > playerX ? 3 : -3) * tileSize,
                playerY,
                false,
                []
            );
            assert(target && target.reason === 'blocked',
                'O Bot não selecionou o barril bloqueando a rota.');
            enemies = [];
            ambientDecorations = [];
            gameState = 'playing';
            shopOpen = false;
            swordEquipped = true;
            player.attackCooldown = 0;
            botActOnObject(target, playerX, playerY);
            assert(barrels[0].health === 10,
                'O Bot não aplicou dano ao barril selecionado.');
            botObjectLastAttemptKey = '';
            assert(botGetObjectTarget(
                playerX,
                playerY,
                objectX + (objectX > playerX ? 3 : -3) * tileSize,
                playerY,
                true,
                []
            ) === null, 'O Bot selecionou um objeto apesar da ameaça imediata.');
            barrels = [
                { x: objectCol, y: objectRow, health: 20, indestructible: true },
                { x: objectCol, y: objectRow, health: 20, isMissionObject: true },
                { x: objectCol, y: objectRow, health: 20, explosive: true }
            ];
            chests = [{ x: objectCol, y: objectRow, health: 20, isMimic: true }];
            assert(botGetObjectTarget(
                playerX,
                playerY,
                objectX + (objectX > playerX ? 3 : -3) * tileSize,
                playerY,
                false,
                []
            ) === null, 'O Bot selecionou objeto indestrutível, de missão, explosivo ou mimic.');
        } finally {
            Math.random = originalRandom;
            barrels = previousBarrels;
            chests = previousChests;
            botObjectQuietTime = previousQuietTime;
            botObjectsAttackedInInterval = previousAttackCount;
            botObjectLastAttemptKey = previousAttemptKey;
            enemies = previousEnemies;
            ambientDecorations = previousDecorations;
            gameState = previousGameState;
            shopOpen = previousShopOpen;
            swordEquipped = previousSwordEquipped;
            player.attackCooldown = previousAttackCooldown;
        }
    });

    runTest('Os sprites de moedas aparecem nas quedas e no inventário', () => {
        for (const ore of oreTypes) {
            const dropSprite = oreDropSprites[ore.id];
            assert(dropSprite.complete && dropSprite.naturalWidth > 0,
                `O sprite de queda para ${ore.name} não carregou.`);
            const icon = document.querySelector(
                `.ore-currency[data-ore="${ore.id}"] .ore-currency-icon`
            );
            assert(getComputedStyle(icon).backgroundImage.includes(
                `ore-${ore.spriteRow}-inventory.png`
            ), `O ícone de inventário para ${ore.name} está incorreto.`);
        }
    });

    runTest('A loja preserva moedas não usadas e dá troco em moedas menores', () => {
        currentFloor = 1;
        botMode = false;
        devMode = false;
        resetGame();
        oreCoinBalance.copper = 3;
        oreCoinBalance.gold = 1;
        oreCoinBalance.ruby = 1;
        setShopOpen(true);
        purchaseUpgrade('sword');
        assert(gearUpgrades.sword === 1,
            'A compra da melhoria de espada não foi concluída.');
        assert(oreCoinBalance.copper === 1
            && oreCoinBalance.silver === 4
            && oreCoinBalance.gold === 0
            && oreCoinBalance.ruby === 1,
        'A loja não deu o troco esperado ou alterou moedas não usadas.');
        assert(getOreCoinBalanceInCopper() === 109,
            'O valor total após a compra não corresponde ao saldo menos o preço.');
        assert(info.textContent.includes('Troco: 4 pratas e 1 cobre.'),
            'A mensagem da loja não informou o troco recebido.');
        setShopOpen(false);
    });

    runTest('Partículas e flechas reutilizam objetos em vez de alocar continuamente', () => {
        const previousParticles = visualParticles.slice();
        const previousParticlePool = visualParticlePool.slice();
        const previousArrows = arrows.slice();
        const previousArrowPool = arrowPool.slice();
        const previousReducedEffects = reducedVisualEffects;
        const previousArrowAmmo = arrowAmmo;
        const previousCombatState = {
            gameState,
            bowOwned,
            swordEquipped,
            arrowCooldown: player.arrowCooldown
        };
        try {
            visualParticles.length = 0;
            visualParticlePool.length = 0;
            reducedVisualEffects = false;
            spawnImpactParticles(10, 20, '#fff');
            const particle = visualParticles[0];
            assert(visualParticles.length === 6,
                'O impacto não gerou o conjunto esperado de partículas.');
            updateImpactParticles(1);
            assert(visualParticles.length === 0 && visualParticlePool.length === 6,
                'Partículas expiradas não retornaram ao pool.');
            spawnImpactParticles(30, 40, '#f00');
            assert(visualParticles.includes(particle),
                'A geração seguinte não reutilizou uma partícula expirada.');

            arrows.length = 0;
            arrowPool.length = 0;
            arrowPool.push({});
            gameState = 'playing';
            bowOwned = true;
            swordEquipped = false;
            arrowAmmo = 1;
            player.arrowCooldown = 0;
            fireArrow(player.x + player.size + 100, player.y + player.size / 2);
            const arrow = arrows[0];
            assert(arrow && arrowPool.length === 0,
                'A flecha disponível no pool não foi reutilizada.');
            clearPlayerArrows();
            assert(arrows.length === 0 && arrowPool.includes(arrow),
                'A flecha encerrada não retornou ao pool.');
        } finally {
            visualParticles.length = 0;
            visualParticles.push(...previousParticles);
            visualParticlePool.length = 0;
            visualParticlePool.push(...previousParticlePool);
            arrows.length = 0;
            arrows.push(...previousArrows);
            arrowPool.length = 0;
            arrowPool.push(...previousArrowPool);
            arrowAmmo = previousArrowAmmo;
            reducedVisualEffects = previousReducedEffects;
            gameState = previousCombatState.gameState;
            bowOwned = previousCombatState.bowOwned;
            swordEquipped = previousCombatState.swordEquipped;
            player.arrowCooldown = previousCombatState.arrowCooldown;
        }
    });

    runTest('As células do inventário não se sobrepõem quando o painel tem pouca altura', () => {
        const previousScreen = document.body.dataset.gameScreen;
        const previousPanelHidden = inventoryPanel.hidden;
        const previousPanelStyle = inventoryPanel.getAttribute('style');
        const previousGridStyle = inventoryItems.getAttribute('style');
        try {
            document.body.dataset.gameScreen = 'playing';
            inventoryPanel.hidden = false;
            inventoryPanel.style.position = 'fixed';
            inventoryPanel.style.top = '12px';
            inventoryPanel.style.width = '670px';
            inventoryPanel.style.height = '286px';
            const cells = Array.from(inventoryItems.querySelectorAll(
                '.inventory-slot:not([hidden]), .inventory-scroll-slot:not([hidden]), .inventory-empty-slot'
            ));
            const firstRow = cells.slice(0, 8).map((cell) => cell.getBoundingClientRect());
            const secondRow = cells.slice(8, 16).map((cell) => cell.getBoundingClientRect());
            assert(firstRow.every((cell) => cell.height >= 48)
                && secondRow.every((cell, index) => cell.top >= firstRow[index].bottom),
            'As linhas de espaços do inventário colidiram com altura limitada.');
            assert(inventoryItems.scrollHeight > inventoryItems.clientHeight,
                'O inventário não permite rolar os itens quando a grade não cabe no painel.');
        } finally {
            document.body.dataset.gameScreen = previousScreen;
            inventoryPanel.hidden = previousPanelHidden;
            if (previousPanelStyle === null) {
                inventoryPanel.removeAttribute('style');
            } else {
                inventoryPanel.setAttribute('style', previousPanelStyle);
            }
            if (previousGridStyle === null) {
                inventoryItems.removeAttribute('style');
            } else {
                inventoryItems.setAttribute('style', previousGridStyle);
            }
        }
    });

    runTest('Portas automáticas começam a abrir antes de bloquear a aproximação', () => {
        const previousPlayerPosition = { x: player.x, y: player.y };
        const previousEnemies = enemies;
        const previousDoors = doors;
        try {
            enemies = [];
            player.x = tileSize * 11 - player.size / 2;
            player.y = tileSize * 11.5 - player.size / 2;
            doors = [{
                x: 13,
                y: 10,
                orientation: 'vertical',
                span: 3,
                progress: 0
            }];
            updateAutomaticDoors(0.1);
            assert(doors[0].progress > 0,
                'Uma porta a duas células e meia do jogador não começou a abrir.');
        } finally {
            player.x = previousPlayerPosition.x;
            player.y = previousPlayerPosition.y;
            enemies = previousEnemies;
            doors = previousDoors;
        }
    });

    runTest('As telas de vitória e derrota cobrem e centralizam na área visível', () => {
        const previousGameState = gameState;
        const previousPlayerPosition = { x: player.x, y: player.y };
        const previousEnemies = enemies.slice();
        const previousCamera = {
            x: cameraX,
            y: cameraY,
            renderX: renderCameraX,
            renderY: renderCameraY
        };
        const drawingFunctionNames = [
            'drawMap',
            'drawSewerDetails',
            'drawBarrels',
            'drawChests',
            'drawLighting',
            'drawAmbientDust',
            'drawCastleColumns',
            'drawBossHazards',
            'drawOreDrops',
            'drawItemDrops',
            'drawPlayer',
            'drawAttachedMimics',
            'drawPlayerArrows',
            'drawSpiderWebEffects',
            'drawImpactParticles',
            'drawSwordAttack',
            'drawSpearAttack',
            'drawVignette'
        ];
        const originalDrawingFunctions = new Map(
            drawingFunctionNames.map((name) => [name, window[name]])
        );
        const originalFillRect = ctx.fillRect;
        const originalFillText = ctx.fillText;
        const overlayRects = [];
        const overlayTexts = [];

        ctx.save();
        try {
            for (const name of drawingFunctionNames) {
                window[name] = () => {};
            }
            ctx.fillRect = (x, y, width, height) => {
                if (ctx.fillStyle === 'rgba(15, 23, 42, 0.65)') {
                    overlayRects.push({
                        x,
                        y,
                        width,
                        height,
                        transform: ctx.getTransform()
                    });
                }
            };
            ctx.fillText = (text, x, y) => {
                overlayTexts.push({
                    text,
                    x,
                    y,
                    width: ctx.measureText(text).width,
                    transform: ctx.getTransform()
                });
            };
            enemies.length = 0;
            player.x = tileSize * 15;
            player.y = tileSize * 12;

            gameState = 'lost';
            draw();
            gameState = 'won';
            draw();

            assert(overlayRects.length === 2
                && overlayRects.every((rect) => rect.x === 0
                    && rect.y === 0
                    && rect.width === cameraViewportWidth
                    && rect.height === cameraViewportHeight
                    && rect.transform.a === renderPixelScale
                    && rect.transform.d === renderPixelScale
                    && rect.transform.e === 0
                    && rect.transform.f === 0),
            'As telas finais não cobriram a viewport sem o deslocamento da câmera.');
            assert(overlayTexts.length === 2
                && overlayTexts[0].text === 'Game Over'
                && overlayTexts[1].text === 'Você venceu!'
                && overlayTexts.every((entry) => entry.x >= 0
                    && entry.x + entry.width <= cameraViewportWidth
                    && entry.transform.e === 0
                    && entry.transform.f === 0),
            'As mensagens finais não foram centralizadas dentro da viewport.');
        } finally {
            ctx.restore();
            ctx.fillRect = originalFillRect;
            ctx.fillText = originalFillText;
            for (const [name, drawingFunction] of originalDrawingFunctions) {
                window[name] = drawingFunction;
            }
            enemies.splice(0, enemies.length, ...previousEnemies);
            player.x = previousPlayerPosition.x;
            player.y = previousPlayerPosition.y;
            gameState = previousGameState;
            cameraX = previousCamera.x;
            cameraY = previousCamera.y;
            renderCameraX = previousCamera.renderX;
            renderCameraY = previousCamera.renderY;
        }
    });

    runTest('A simulação mantém subetapas físicas e a cadência temporal do Bot', () => {
        const originalUpdate = window.update;
        const updates = [];
        try {
            window.update = (delta, botDelta) => updates.push([delta, botDelta]);
            updateSimulationFrame(0.016, 10);
            assert(updates.length === 10
                && updates.every(([delta]) => delta === 0.016),
            'A aceleração removeu ou alterou subetapas de simulação.');
            assert(updates.every(([, botDelta]) => botDelta === 0.016),
                'A aceleração alterou a cadência de decisão baseada no tempo simulado do Bot.');
        } finally {
            window.update = originalUpdate;
        }
    });

    runTest('A limpeza de inimigos preserva a lista e a ordem sem recriá-la', () => {
        const previousEnemies = enemies.slice();
        const enemyList = enemies;
        const originalUpdateFloorCombatProgress = window.updateFloorCombatProgress;
        let progressUpdates = 0;
        const activeEnemy = { dying: false };
        const fadingEnemy = { dying: true, deathTimer: 0.1 };
        const expiredEnemy = { dying: true, deathTimer: 0 };

        try {
            enemies.splice(0, enemies.length, activeEnemy, expiredEnemy, fadingEnemy);
            window.updateFloorCombatProgress = () => {
                progressUpdates++;
            };
            cleanupDefeatedEnemies();
            assert(enemies === enemyList
                && enemies.length === 2
                && enemies[0] === activeEnemy
                && enemies[1] === fadingEnemy,
            'A limpeza recriou a lista, removeu um efeito de morte ativo ou alterou a ordem.');
            assert(progressUpdates === 1,
                'A limpeza não atualizou o progresso do andar após remover um inimigo.');
            cleanupDefeatedEnemies();
            assert(progressUpdates === 1,
                'A lista foi processada como removida mesmo sem inimigos expirados.');
        } finally {
            window.updateFloorCombatProgress = originalUpdateFloorCombatProgress;
            enemies.splice(0, enemies.length, ...previousEnemies);
        }
    });

    runTest('Paredes de caverna variam blocos, limitam veios e aquecem nos andares profundos', () => {
        const previousFloor = currentFloor;
        const previousDrawOreVein = window.drawOreVein;
        const previousDrawCaveMoss = window.drawCaveMoss;
        const previousFillRect = ctx.fillRect;
        let tileVeins = 0;
        let tileMoss = 0;
        let largeWallVeins = 0;
        let largeWallMoss = 0;
        let heatedPixels = 0;

        try {
            currentFloor = 3;
            window.drawOreVein = () => {
                tileVeins++;
            };
            window.drawCaveMoss = () => {
                tileMoss++;
            };
            for (let row = 20; row < 100; row++) {
                for (let col = 20; col < 100; col++) {
                    drawOldWallTile(col, row);
                }
            }
            const tileVeinRate = tileVeins / (80 * 80);
            assert(tileVeinRate >= 0.27 && tileVeinRate <= 0.33,
                `Os veios das paredes simples ocupam ${(tileVeinRate * 100).toFixed(1)}% dos tiles.`);
            const tileMossRate = tileMoss / (80 * 80);
            assert(tileMossRate >= 0.17 && tileMossRate <= 0.23,
                `O musgo das paredes simples ocupa ${(tileMossRate * 100).toFixed(1)}% dos tiles.`);

            tileVeins = 0;
            tileMoss = 0;
            for (let row = 20; row < 60; row++) {
                for (let col = 20; col < 60; col++) {
                    drawOldLargeWallTile(col, row);
                }
            }
            const largeWallVeinRate = tileVeins / (40 * 40);
            assert(largeWallVeinRate >= 0.87 && largeWallVeinRate <= 0.93,
                `Os veios das paredes 32x32 aparecem em ${(largeWallVeinRate * 100).toFixed(1)}% dos grupos.`);
            largeWallMoss = tileMoss / (40 * 40);
            assert(largeWallMoss >= 0.32 && largeWallMoss <= 0.38,
                `O musgo das paredes 32x32 aparece em ${(largeWallMoss * 100).toFixed(1)}% dos grupos.`);

            assert(new Set(Object.values(caveWallPalette)).size <= 16,
                'A paleta das paredes de caverna ultrapassa 16 cores.');
            assert(new Set(Object.values(caveOreTypes).map((ore) => (
                ore.pattern.join('')
            ))).size === 5,
            'Os veios minerais voltaram a compartilhar a mesma forma.');

            const previousFillRectForSize = ctx.fillRect;
            const drawnRects = [];
            ctx.fillRect = (x, y, width, height) => {
                drawnRects.push({ x, y, width, height });
            };
            const boundsOfDrawnRects = () => ({
                width: Math.max(...drawnRects.map((rect) => rect.x + rect.width))
                    - Math.min(...drawnRects.map((rect) => rect.x)),
                height: Math.max(...drawnRects.map((rect) => rect.y + rect.height))
                    - Math.min(...drawnRects.map((rect) => rect.y))
            });
            previousDrawOreVein(10, 10, caveOreTypes.copper);
            const oreBounds = boundsOfDrawnRects();
            assert(oreBounds.width === 6 && oreBounds.height === 6,
                `O veio não aumentou 10% em pixels inteiros (${oreBounds.width}x${oreBounds.height}).`);
            drawnRects.length = 0;
            previousDrawCaveMoss(10, 10, 1);
            const smallMossBounds = boundsOfDrawnRects();
            assert(smallMossBounds.width === 6 && smallMossBounds.height === 6,
                `A mancha de musgo pequena não aumentou 10% em pixels inteiros (${smallMossBounds.width}x${smallMossBounds.height}).`);
            drawnRects.length = 0;
            previousDrawCaveMoss(10, 10, 2);
            const largeMossBounds = boundsOfDrawnRects();
            assert(largeMossBounds.width === 11 && largeMossBounds.height === 11,
                `A mancha de musgo grande não aumentou 10% (${largeMossBounds.width}x${largeMossBounds.height}).`);
            ctx.fillRect = previousFillRectForSize;

            currentFloor = 9;
            ctx.fillRect = (...rectangle) => {
                if (ctx.fillStyle === caveWallPalette.emberLight) heatedPixels++;
                previousFillRect.apply(ctx, rectangle);
            };
            for (let row = 20; row < 40; row++) {
                for (let col = 20; col < 40; col++) {
                    drawOldLargeWallTile(col, row);
                }
            }
            assert(heatedPixels > 0,
                'As paredes dos andares 7 a 9 não exibem rachaduras com brilho quente.');
        } finally {
            currentFloor = previousFloor;
            window.drawOreVein = previousDrawOreVein;
            window.drawCaveMoss = previousDrawCaveMoss;
            ctx.fillRect = previousFillRect;
        }
    });

    runTest('A renderização alinha pixels, recorta entidades fora da câmera e preserva avisos ativos', () => {
        const previousGameState = gameState;
        const previousPlayerPosition = { x: player.x, y: player.y };
        const previousEnemies = enemies.slice();
        const previousCamera = {
            x: cameraX,
            y: cameraY,
            renderX: renderCameraX,
            renderY: renderCameraY
        };
        const drawingFunctionNames = [
            'drawMap',
            'drawSewerDetails',
            'drawBarrels',
            'drawChests',
            'drawLighting',
            'drawAmbientDust',
            'drawCastleColumns',
            'drawBossHazards',
            'drawOreDrops',
            'drawItemDrops',
            'drawPlayer',
            'drawAttachedMimics',
            'drawPlayerArrows',
            'drawSpiderWebEffects',
            'drawSwordAttack',
            'drawSpearAttack',
            'drawVignette',
            'drawOverlay'
        ];
        const originalDrawingFunctions = new Map(
            drawingFunctionNames.map((name) => [name, window[name]])
        );
        const originalDrawImage = ctx.drawImage;
        const renderedEnemies = [];
        const isPixelAligned = (value) => Math.abs(value - Math.round(value)) < 1e-4;
        const visibleEnemy = { x: 260.13, y: 200.17, size: 16, heightBlocks: 1 };
        const hiddenEnemy = { x: 800, y: 800, size: 16, heightBlocks: 1 };
        const warningEnemy = {
            x: 800,
            y: 800,
            size: 16,
            heightBlocks: 1,
            sentinelBeamWarning: 0.5
        };
        const offscreenEnemies = Array.from({ length: 6 }, (_, index) => ({
            ...hiddenEnemy,
            x: 800 + index * tileSize,
            y: 800 + index * tileSize
        }));

        try {
            for (const name of drawingFunctionNames) {
                window[name] = () => {};
            }
            window.drawEnemy = (enemy) => {
                const transform = ctx.getTransform();
                renderedEnemies.push({
                    enemy,
                    pixelX: transform.e + enemy.x * renderPixelScale,
                    pixelY: transform.f + enemy.y * renderPixelScale
                });
            };
            player.x = 260.13;
            player.y = 200.17;
            enemies.splice(
                0,
                enemies.length,
                ...offscreenEnemies,
                visibleEnemy,
                warningEnemy
            );
            gameState = 'playing';
            draw();

            assert(isPixelAligned(renderCameraX * renderPixelScale)
                && isPixelAligned(renderCameraY * renderPixelScale),
            'A câmera não foi alinhada à grade de pixels.');
            assert(renderedEnemies.length === 2
                && renderedEnemies[0].enemy === visibleEnemy
                && renderedEnemies[1].enemy === warningEnemy,
            'O recorte ocultou um aviso ativo ou desenhou um inimigo fora da câmera.');
            assert(renderEntityOrder.length === 3,
                'Inimigos fora da câmera sem avisos entraram na lista ordenada de desenho.');
            assert(isPixelAligned(renderedEnemies[0].pixelX)
                && isPixelAligned(renderedEnemies[0].pixelY),
            'O desenho do inimigo não foi alinhado à grade de pixels.');

            let cacheDrawArguments = null;
            const fakeCache = {
                width: gridWidth * renderPixelScale,
                height: gridHeight * renderPixelScale
            };
            ctx.drawImage = (...args) => {
                cacheDrawArguments = args;
            };
            try {
                drawCachedViewportCanvas(fakeCache);
            } finally {
                ctx.drawImage = originalDrawImage;
            }
            assert(cacheDrawArguments
                && cacheDrawArguments[0] === fakeCache
                && cacheDrawArguments[3] < fakeCache.width
                && cacheDrawArguments[4] < fakeCache.height,
            'O cache estático não foi recortado ao viewport.');
        } finally {
            ctx.drawImage = originalDrawImage;
            for (const [name, originalFunction] of originalDrawingFunctions) {
                window[name] = originalFunction;
            }
            player.x = previousPlayerPosition.x;
            player.y = previousPlayerPosition.y;
            enemies.splice(0, enemies.length, ...previousEnemies);
            gameState = previousGameState;
            cameraX = previousCamera.x;
            cameraY = previousCamera.y;
            renderCameraX = previousCamera.renderX;
            renderCameraY = previousCamera.renderY;
            draw();
        }
    });

    runTest('Caches fora da tela liberam memória e são reconstruídos sob demanda', () => {
        ensureMapBaseCanvas();
        ensureWallCornerCobwebCache();
        const previousMapCanvas = mapBaseCanvas;
        const previousCobwebCanvas = wallCornerCobwebCanvas;

        releaseHiddenRenderCaches();

        assert(mapBaseCanvas === null && wallCornerCobwebCanvas === null,
            'Os caches fora da tela continuaram referenciados após a liberação.');
        assert(previousMapCanvas.width === 0 && previousMapCanvas.height === 0
            && previousCobwebCanvas.width === 0 && previousCobwebCanvas.height === 0,
        'Os buffers dos canvases antigos não foram liberados.');

        ensureMapBaseCanvas();
        ensureWallCornerCobwebCache();
        assert(mapBaseCanvas !== previousMapCanvas
            && wallCornerCobwebCanvas !== previousCobwebCanvas
            && mapBaseCanvas.width === gridWidth * renderPixelScale
            && mapBaseCanvas.height === gridHeight * renderPixelScale
            && wallCornerCobwebCanvas.width === gridWidth * renderPixelScale
            && wallCornerCobwebCanvas.height === gridHeight * renderPixelScale,
        'Os caches liberados não foram reconstruídos com as dimensões corretas.');
    });

    runTest('Personagens recebem sombras e são desenhados por profundidade com vinheta final', () => {
        const previousGameState = gameState;
        const previousPlayerPosition = { x: player.x, y: player.y };
        const previousEnemies = enemies.slice();
        const drawingFunctionNames = [
            'drawMap',
            'drawSewerDetails',
            'drawBarrels',
            'drawChests',
            'drawLighting',
            'drawAmbientDust',
            'drawCastleColumns',
            'drawBossHazards',
            'drawOreDrops',
            'drawItemDrops',
            'drawPlayer',
            'drawEnemy',
            'drawAttachedMimics',
            'drawPlayerArrows',
            'drawSpiderWebEffects',
            'drawSwordAttack',
            'drawSpearAttack',
            'drawVignette',
            'drawOverlay'
        ];
        const originalDrawingFunctions = new Map(
            drawingFunctionNames.map((name) => [name, window[name]])
        );
        const originalFillRect = ctx.fillRect;
        const order = [];
        const earlyEnemy = { x: 120, y: 70, size: 20, heightBlocks: 1, creatureType: 'early' };
        const lateEnemy = { x: 120, y: 120, size: 20, heightBlocks: 1, creatureType: 'late' };
        const shadowRows = [];

        try {
            for (const name of drawingFunctionNames) {
                window[name] = () => {};
            }
            window.drawPlayer = () => order.push('player');
            window.drawEnemy = (enemy) => order.push(enemy.creatureType);
            window.drawVignette = () => order.push('vignette');
            player.x = 120;
            player.y = 100;
            enemies.splice(0, enemies.length, lateEnemy, earlyEnemy);
            gameState = 'playing';
            draw();

            assert(order.join(',') === 'early,player,late,vignette',
                'Jogador e inimigos não foram ordenados pela posição vertical ou a vinheta não ficou no topo.');

            ctx.fillRect = (...rectangle) => {
                shadowRows.push(rectangle);
            };
            drawEntityShadow(40.13, 52.17, 18, 0.3);
            assert(shadowRows.length === 4 && shadowRows.every((rectangle) => (
                rectangle.every((value) => (
                    Math.abs(value * renderPixelScale - Math.round(value * renderPixelScale)) < 1e-4
                ))
            )),
                'A sombra pixelada não desenhou suas quatro faixas de contato.');
        } finally {
            ctx.fillRect = originalFillRect;
            for (const [name, originalFunction] of originalDrawingFunctions) {
                window[name] = originalFunction;
            }
            player.x = previousPlayerPosition.x;
            player.y = previousPlayerPosition.y;
            enemies.splice(0, enemies.length, ...previousEnemies);
            gameState = previousGameState;
            draw();
        }
    });

    runTest('Poças de lava ativas iluminam o piso ao redor', () => {
        const previousEnemies = enemies.slice();
        const originalFillRect = ctx.fillRect;
        const captureLighting = () => {
            const samples = [];
            ctx.fillRect = (x, y) => {
                const match = String(ctx.fillStyle).match(/^rgba\(\d+, \d+, \d+, ([\d.]+)\)$/);
                if (match) {
                    samples.push({ x, y, darkness: Number(match[1]) });
                }
            };
            try {
                drawLighting();
            } finally {
                ctx.fillRect = originalFillRect;
            }
            return samples;
        };

        try {
            const baseline = captureLighting();
            const target = baseline
                .filter((sample) => sample.darkness > 0.2)
                .reduce((darkest, sample) => (
                    !darkest || sample.darkness > darkest.darkness ? sample : darkest
                ), null);
            assert(target, 'Não foi encontrado um tile escuro visível para validar a luz de lava.');

            const poolX = target.x + tileSize / 2;
            const poolY = target.y + tileSize / 2;
            enemies.push({
                bossType: 'lavaGolem',
                lavaPools: [{ x: poolX, y: poolY, warning: 0 }]
            });
            const illuminated = captureLighting().find((sample) => sample.x === target.x
                && sample.y === target.y);
            assert(illuminated && illuminated.darkness < target.darkness - 0.1,
                'Uma poça ativa não reduziu a escuridão do piso em seu entorno.');
        } finally {
            ctx.fillRect = originalFillRect;
            enemies.splice(0, enemies.length, ...previousEnemies);
        }
    });

    runTest('Efeitos de impacto têm limite e respeitam a redução de movimento', () => {
        const previousReducedEffects = reducedVisualEffects;
        const previousStoredSetting = localStorage.getItem(reducedEffectsStorageKey);
        const originalFillRect = ctx.fillRect;
        let renderedParticles = 0;

        try {
            setReducedVisualEffects(false);
            visualParticles.length = 0;
            for (let index = 0; index < 60; index++) {
                spawnImpactParticles(40, 50, '#f2d18a');
            }
            assert(visualParticles.length === visualParticleLimit,
                'As partículas ultrapassaram o limite de segurança.');

            ctx.fillRect = () => {
                renderedParticles += 1;
            };
            drawImpactParticles();
            assert(renderedParticles === visualParticleLimit,
                'As partículas de impacto não foram desenhadas durante a configuração normal.');

            setReducedVisualEffects(true);
            spawnImpactParticles(40, 50, '#f2d18a');
            drawImpactParticles();
            assert(visualParticles.length === 0 && renderedParticles === visualParticleLimit,
                'A opção de movimento reduzido não desativou e limpou as partículas.');
            assert(!isVisualHitFlashActive(0.16),
                'A opção de movimento reduzido ainda exibe flashes de dano.');
            reducedEffectsToggle.checked = false;
            reducedEffectsToggle.dispatchEvent(new Event('change'));
            assert(reducedVisualEffects === false
                && localStorage.getItem(reducedEffectsStorageKey) === 'false',
            'A opção de acessibilidade não foi persistida ao alterná-la.');
        } finally {
            ctx.fillRect = originalFillRect;
            visualParticles.length = 0;
            setReducedVisualEffects(previousReducedEffects);
            if (previousStoredSetting === null) {
                localStorage.removeItem(reducedEffectsStorageKey);
            } else {
                localStorage.setItem(reducedEffectsStorageKey, previousStoredSetting);
            }
        }
    });

    runTest('HUD, inventário e loja preservam tipografia legível e alvos de toque', () => {
        const journalText = Number.parseFloat(getComputedStyle(questText.parentElement).fontSize);
        const experienceText = Number.parseFloat(getComputedStyle(document.querySelector('.xp-status')).fontSize);
        const inventoryCloseTarget = Number.parseFloat(
            getComputedStyle(document.querySelector('.inventory-close')).minHeight
        );
        const purchaseTarget = Number.parseFloat(
            getComputedStyle(shopItemPurchaseButton).minHeight
        );
        assert(journalText >= 14 && experienceText >= 12,
            'Os textos principais do HUD ficaram abaixo dos tamanhos legíveis definidos.');
        assert(inventoryCloseTarget >= 40 && purchaseTarget >= 42,
            'Os botões de fechar ou comprar não mantêm alvos adequados para toque.');
    });

    runTest('O portal encerra a aventura manual no andar final', () => {
        currentFloor = finalFloor;
        botMode = false;
        botLearning = null;
        resetGame();
        portalUnlocked = true;
        player.x = exitPosition.x * tileSize + (tileSize - player.size) / 2;
        player.y = exitPosition.y * tileSize + (tileSize - player.size) / 2;
        checkPlayerTile();
        assert(gameState === 'won', 'A partida manual não terminou em vitória.');
        assert(questText.textContent === `Você concluiu os ${finalFloor} andares`,
            'A mensagem de conclusão está incorreta.');
    });

    currentFloor = 1;
    botMode = false;
    botLearning = null;
    devMode = false;
    resetGame();
    gameState = 'menu';
    discoveredCreatureIds = originalBestiaryDiscoveries;
    if (originalBestiaryStorage === null) {
        localStorage.removeItem(bestiaryDiscoveryStorageKey);
    } else {
        localStorage.setItem(bestiaryDiscoveryStorageKey, originalBestiaryStorage);
    }
    bestiaryDiscoveryStatus.hidden = originalBestiaryStatus.hidden;
    bestiaryDiscoveryStatus.textContent = originalBestiaryStatus.text;
    renderBestiary();
    startScreen.hidden = false;
    document.body.dataset.gameScreen = 'menu';
    pageHeading.textContent = 'Testes do jogo';
    gameHud.hidden = true;
    inventoryPanel.hidden = true;
    gameActions.hidden = true;
    info.hidden = true;
    startButton.hidden = true;
    const report = document.createElement('pre');
    const failedTests = results.filter((result) => !result.passed && !result.skipped);
    report.className = 'game-test-report';
    report.setAttribute('role', failedTests.length > 0 ? 'alert' : 'status');
    report.textContent = results.map((result) => (
        `${result.skipped ? 'PULOU' : result.passed ? 'PASSOU' : 'FALHOU'} · ${result.name}${result.error ? ` · ${result.error}` : ''}`
    )).join('\n');
    startScreen.querySelector('.start-card').append(report);
    startButton.focus();
})();
